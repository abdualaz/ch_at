/**
 * =============================================================
 *  Chat Server  —  متوافق 100% مع appraad.js
 * =============================================================
 *
 *  الفروقات الرئيسية عن x3_final.js التي تم إصلاحها:
 *
 *  1. أسماء الأحداث المُصحَّحة:
 *     - 'online+' / 'online-'  → 'u+' / 'u-'  (appraad.js يستمع لـ u+ وu-)
 *     - ترتيب joinRoom: rc → ulist/rlist/... → u+ → r^ → rcd
 *     - ترتيب rc2:      server → rlist → rc → ulist → rcd → ok → login
 *
 *  2. أوامر الكلاينت:
 *     - 'g'      → زائر  { username, fp, refr, r }
 *     - 'login'  → عضو   { username, password, stealth, fp, refr, r }
 *     - 'reg'    → تسجيل { username, password, fp }
 *     - 'mic'    → index | -1
 *     - 'upro'   → uid (string)
 *
 *  3. تدفق تسجيل الدخول الصحيح:
 *     Client → send('online')
 *     Server → server, rlist, emos, dro3, sico, powers, settings
 *     Client → send('g'|'login'|'reg')
 *     Server → ok, login{msg:ok,id,k,ttoken,r}
 *     Server → rc
 *     Server → rcd([[rlist,...],[emos,...],[ulist,...],[ur,[id,roomId]],[mic,...],[rops,...],[power,...]])
 *     Server → u+ (للأعضاء الآخرين), r^ (لجميع)
 *
 *  4. لماذا rcd يحمل كل البيانات (وليس إرسالها بين rc و rcd؟)
 *     appraad.js case 'rcd': systemCommandQueue = [];  ← تُمسح القائمة!
 *     combinedQueueData = commandPayload.concat([]); = commandPayload فقط
 *     → الأوامر المُرسَلة بين rc و rcd تضيع تماماً
 *     → الحل الوحيد: payload الـ rcd نفسه = [[cmd,data],...]
 *
 *  5. ترتيب العناصر داخل rcd مهم:
 *     rlist → ulist → ur (يضبط myroom) → mic (ur تُفرّغها) → rops → power
 *
 *  البروتوكول:
 *    - كل رسالة socket.io تنتقل تحت الحدث "msg"
 *      الصيغة:  { cmd: decodeCmd(commandName), data: payload }
 *    - تشفير الأوامر: XOR بسيط (نفس decryptCommand في appraad.js)
 *    - rc2 يُرسَل مباشرة كحدث منفصل (بدون تشفير)
 * =============================================================
 */

'use strict';

require('dotenv').config();

const path       = require('path');
const express    = require('express');
const http       = require('http');
const https      = require('https');
const { Server } = require('socket.io');
const { v4: uuidv4 } = require('uuid');
const bcrypt     = require('bcryptjs');
const fs         = require('fs');

// ─── إعدادات السيرفر ───────────────────────────────────────────────────────────
const PORT          = process.env.PORT          || 8000;
const HOST          = process.env.HOST          || '0.0.0.0';
const USE_HTTPS     = process.env.USE_HTTPS     === 'true';
const ADMIN_KEY     = process.env.ADMIN_KEY     || 'admin123';
const MAX_MIC_SLOTS = parseInt(process.env.MAX_MIC_SLOTS)  || 5;
const MAX_WALL      = parseInt(process.env.MAX_WALL_MSGS)  || 200;
const SALT_ROUNDS   = 8;

const HTTPS_OPTIONS = (() => {
  if (!USE_HTTPS) return null;
  const keyPath = path.join(__dirname, 'key.pem');
  const certPath = path.join(__dirname, 'cert.pem');
  if (!fs.existsSync(keyPath) || !fs.existsSync(certPath)) {
    console.warn('[server] USE_HTTPS=true ولكن key.pem أو cert.pem غير موجودين، سيتم استخدام HTTP العادي.');
    return null;
  }
  return {
    key: fs.readFileSync(keyPath),
    cert: fs.readFileSync(certPath)
  };
})();

// ─── تشفير الأوامر — نفس decryptCommand في appraad.js ────────────────────────
// appraad.js: charCode XOR 0x2  ،  skip pattern: i += i<20?1 : i<200?4 : 16
function decodeCmd(str) {
  const chars = (str || '').split('');
  const len   = chars.length;
  for (let i = 0; i < len; i++) {
    chars[i] = String.fromCharCode(str.charCodeAt(i) ^ 2);
    i += i < 20 ? 1 : i < 200 ? 4 : 16;
  }
  return chars.join('');
}

// ─── تهيئة Express + Socket.IO ────────────────────────────────────────────────
const app    = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');
const server = HTTPS_OPTIONS ? https.createServer(HTTPS_OPTIONS, app) : http.createServer(app);
const io     = new Server(server, {
  pingTimeout:  25000,
  pingInterval: 10000,
  transports:   ['websocket', 'polling']
});

// ▲ إصلاح: index:false يمنع express.static من تقديم index.html تلقائياً
//   عند GET / — لإفساح المجال لمسار GET / المخصص أدناه الذي يحقن اسم/عنوان/
//   وصف/كلمات دلالية/سكربت/لون الموقع ديناميكياً من الإعدادات المحفوظة.
//   بقية الملفات الساكنة (js/css/صور) تبقى تُقدَّم بشكل طبيعي كالمعتاد.
app.use(express.static('public', { index: false }));
app.use(express.json());

// ▲ إضافة جوهرية: مساري رفع الملفات /upload و/pic لم يكونا موجودين إطلاقاً
//   في السيرفر بأي شكل من الأشكال — اكتشاف جوهري أثناء هذا الفحص. appraad2.js
//   يرفع الملفات عبر XMLHttpRequest POST خام (الجسم = بيانات الملف الثنائية
//   نفسها، وليس multipart/form-data) لهذين المسارين تحديداً:
//     POST /pic?secid=u&fn=<امتداد>&t=<وقت>     → الصورة الشخصية (setpic)
//     POST /upload?secid=u&fn=<امتداد>&t=<وقت>  → كل شيء آخر (صور/ملفات
//       الحائط، مشاركة ملف بالخاص، رفع أيقونات/إيموجيات/زخارف لوحة التحكم،
//       شعار الموقع favicon.ico/prv1.png)
//   ويتوقع كلاهما استجابة نصية عادية (وليست JSON) تحمل رابط الملف المرفوع
//   مباشرة. بما أن هذين المسارين لم يكونا موجودين، كان أي رفع ملف بالموقع
//   بأكمله يفشل بخطأ 404 دائماً — نظام الرفع كله كان معطّلاً من الأساس.
const UPLOAD_DIR = path.join(__dirname, 'public', 'uploads');
const DATA_DIR = path.join(__dirname, 'data');
const ACCOUNTS_FILE = path.join(DATA_DIR, 'accounts.json');
const ROOM_ASSETS_FILE = path.join(DATA_DIR, 'room-assets.json');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

function cleanAssetName(value) {
  return String(value || '')
    .replace(/^\/+/, '')
    .replace(/^uploads\//i, '')
    .replace(/^(sico|dro3|emo)\//i, '')
    .replace(/^\/+/, '');
}

function readJsonFile(filePath, fallback) {
  try {
    if (!fs.existsSync(filePath)) return fallback;
    const raw = fs.readFileSync(filePath, 'utf8');
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) {
    return fallback;
  }
}

function writeJsonFile(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, JSON.stringify(value, null, 2), 'utf8');
}

function saveRoomAssets() {
  const payload = {};
  for (const [id, room] of rooms.entries()) {
    payload[id] = {
      sicos: Array.isArray(room.sicos) ? room.sicos : [],
      colors: Array.isArray(room.colors) ? room.colors : [],
      emos: Array.isArray(room.emos) ? room.emos : []
    };
  }
  writeJsonFile(ROOM_ASSETS_FILE, payload);
}

function loadRoomAssets() {
  const saved = readJsonFile(ROOM_ASSETS_FILE, {});
  if (!saved || typeof saved !== 'object') return {};
  return saved;
}
// ▲ إصلاح جوهري لخطأ "Cannot GET /sico/xxx.jpg" (وبنفس الشكل /dro3, /emo):
//   كل رفع (أيقونة صلاحية/هدية/إيموجي) يُحفظ فعلياً بمجلد واحد فقط هو
//   public/uploads (المسار أعلاه)، بينما appraad2.js يبني رابط العرض دائماً
//   بافتراض مجلد منفصل حسب النوع: "sico/"+file أو "dro3/"+file أو "emo/"+file
//   — وهذه المجلدات غير موجودة أصلاً على القرص، فيفشل التحميل دوماً. بما أن
//   اسم كل ملف مُولَّد عشوائياً وفريد (Date.now + Math.random)، لا خطر تصادم
//   إطلاقاً من تقديم نفس مجلد uploads الفعلي تحت الأسماء الثلاث معاً — أياً
//   كان "المجلد المنطقي" الذي يطلبه المتصفح، يُعثر على الملف الصحيح دوماً.
// ▲ إصلاح إضافي (Cannot GET /sico/uploads/xxx.gif): بعض العناصر المخزَّنة
//   فعلياً بقاعدة البيانات تحمل القيمة كاملة "uploads/xxx.gif" (بدل اسم
//   الملف المجرد) لأن addico كان يحفظ ما يصله دون تنظيف — فيصبح رابط العرض
//   "sico/uploads/xxx.gif" (مجلد uploads متداخل داخل مجلد وهمي آخر). معالج
//   مخصص هنا (بدل express.static البسيطة) يزيل أي بادئة "uploads/" من
//   المسار المطلوب قبل البحث عن الملف — فيعمل مع القيم القديمة المخزَّنة
//   بالخطأ (توافقية رجعية بلا حاجة لأي ترحيل بيانات) والجديدة النظيفة معاً.
function serveFromUploadDir(req, res) {
  // ▲ تصحيح: req.path يتضمن /sico أو /dro3 أو /emo نفسها كجزء من النص —
  //   req.params[0] (التقاط الحرف البدل *) يعطي فقط ما بعدها مباشرة، وهو
  //   المطلوب فعلياً لإزالة بادئة uploads/ بشكل صحيح.
  let requested = decodeURIComponent(req.params[0] || '');
  requested = requested.replace(/^\/+/, '').replace(/^(uploads\/)+/, ''); // يزيل أي تكرار uploads/
  const filePath = path.join(UPLOAD_DIR, requested);
  if (!filePath.startsWith(UPLOAD_DIR)) return res.status(400).end(); // حماية من path traversal
  res.sendFile(filePath, (err) => { if (err) res.status(404).end(); });
}
app.get('/sico/*', serveFromUploadDir);
app.get('/dro3/*', serveFromUploadDir);
app.get('/emo/*',  serveFromUploadDir);

function handleFileUpload(req, res) {
  try {
    if (!req.body || !req.body.length) return res.status(400).send('');
    const extRaw = String(req.query.fn || 'bin').toLowerCase().replace(/[^a-z0-9]/g, '');
    const ext = extRaw.slice(0, 10) || 'bin';
    const filename = Date.now().toString(36) + Math.random().toString(36).slice(2, 8) + '.' + ext;
    fs.writeFileSync(path.join(UPLOAD_DIR, filename), req.body);
    res.status(200).send(filename);
  } catch (e) {
    console.error('[upload] فشل الرفع:', e.message);
    res.status(500).send('');
  }
}
// raw() تلتقط جسم الطلب الثنائي الخام كما يرسله appraad2.js تماماً
const rawUploadParser = express.raw({ limit: '25mb', type: () => true });
app.post('/upload', rawUploadParser, handleFileUpload);
app.post('/pic',    rawUploadParser, handleFileUpload);

// ─── الصفحة الرئيسية: حقن إعدادات الموقع ديناميكياً ────────────────────────────
// appraad2.js/index.html لا يملكان أي آلية لتطبيق اسم/عنوان/وصف/لون الموقع
// المحفوظة عبر لوحة التحكم (sitesave) على الصفحة الفعلية — كانت تُحفظ في
// السيرفر وتُعرض فقط داخل لوحة التحكم نفسها. نحقنها هنا في كل مرة تُطلب
// فيها الصفحة الرئيسية.
// ⚠️ ملاحظة صريحة: تحققتُ من index.html وملف الأنماط بالكامل — حقلا لون
//   المحتوى (sbackground) ولون الأزرار (sbuttons) لا يملكان أي قاعدة CSS
//   أو استخدام آخر في الصفحة كلها تربطهما بأي عنصر مرئي فعلي (لا صنف
//   ".background"/".buttons" مُستخدَم لأي تنسيق حقيقي) — هما حقلان يُحفظان
//   فقط لكن لا "مكان" موجود لربطهما به حالياً. لذا حقنتُ فقط ما له هدف
//   مؤكد وموجود فعلياً في الصفحة: العنوان <title>، الوصف/الكلمات الدلالية،
//   السكربت المخصص، ولون خلفية الصفحة (bg، مرتبط مباشرة بـ body.bg الموجود
//   فعلياً في index.html). لتفعيل لون المحتوى/الأزرار فعلياً، يلزم أولاً
//   إضافة قواعد CSS حقيقية تستخدمها في index.html (وليست موجودة حالياً).
app.get('/', (req, res) => {
  const indexPath = path.join(__dirname, 'public', 'index.html');
  let html;
  try { html = require('fs').readFileSync(indexPath, 'utf8'); }
  catch (e) { return res.sendFile(indexPath); }

  const s = global.siteSettings || {};

  if (s.title) {
    html = html.replace(/<title>[\s\S]*?<\/title>/, `<title>${sanitize(s.title, 200)}</title>`);
  }
  if (s.description) {
    const descEsc = sanitize(s.description, 1000).replace(/"/g, '&quot;');
    html = html.replace(/<meta name="description" content="[\s\S]*?">/, `<meta name="description" content="${descEsc}">`);
  }
  if (s.keywords) {
    const kwEsc = sanitize(s.keywords, 1000).replace(/"/g, '&quot;');
    html = html.replace(/<meta content="[\s\S]*?" name="keywords">/, `<meta content="${kwEsc}" name="keywords">`);
  }
  // ▲ إصلاح: اسم الموقع (name) كان يُحقَن فقط كوسم <title> عبر sett_title
  //   (حقل منفصل)، بينما حقل "اسم الموقع" (name/sett_name) نفسه لا يظهر في
  //   أي مكان بالصفحة الفعلية إطلاقاً. تحققتُ من index.html: اسم العلامة
  //   التجارية الثابت "شات السعودية للجوال" مكرر حرفياً 14 مرة في أماكن
  //   مختلفة من الصفحة (شعار الترويسة، عناوين شاشة الدخول...). استبدال كل
  //   نسخة منها باسم الموقع المحفوظ يجعله ينعكس أينما ظهر بالفعل بالصفحة.
  const DEFAULT_SITE_NAME = 'شات السعودية للجوال';
  if (s.name) {
    const nameEsc = sanitize(s.name, 100);
    html = html.split(DEFAULT_SITE_NAME).join(nameEsc);
  }
  // ▲ تراجع كامل بطلب صريح (مقارنة فعلية بلقطات شاشة مع نشر مرجعي لنفس
  //   القالب على ksa-3.net): كان هنا استبدال لوسم viewport الأصلي
  //   (width=400 ثابت → device-width) + كتلة <style> تفرض
  //   max-width:100%/width:100%!important على .center-block.dad و
  //   .d2/#rooms/#users/#lonline/.uzr/.room — استناداً لافتراض أن العرض
  //   الثابت 400px كان "خللاً قديماً". المقارنة أثبتت العكس: الموقع
  //   المرجعي يُصرِّح فعلياً width=400 وbody محسوبها 400px بالضبط،
  //   و.center-block.bg.dad محسوبها max-width:394px (+هامش 3px كل جانب) —
  //   هذا هو التصميم الثابت المقصود أصلاً لكل قياسات القالب (حشوات/هوامش/
  //   أحجام الصور...)، وليس خللاً. فرض device-width/100% كان يُخرِج الصفحة
  //   عن هذا التصميم الثابت (504px بدل 400px على هذا الجهاز تحديداً — أي
  //   الفرق نفسه نسبياً 968 مقابل 768 بالارتفاع). حُذف الاستبدال والكتلة
  //   بالكامل — يعمل الآن index.html كما هو دون أي تدخل بالعرض/الحجم.
  //   استُثنيت عمداً: أي كود لون (bg/content/buttons) — لم يُمَس، منفصل
  //   تماماً أدناه.

  // ═══════════════════════════════════════════════════════════════════════
  // نظام الألوان — إعادة بناء نظيفة من الصفر، ثلاث قواعد فقط بلا أي تداخل
  // فيما بينها أو مع إصلاحات التخطيط أعلاه. كل قاعدة تستهدف فقط ما اتفقنا
  // عليه حرفياً، ولا شيء غيره:
  //
  //   • لون القالب (bg)      → .bg  فيما عدا body وأزرار شريط المايكات.
  //   • لون المحتوى (background) → خلفية #d2 فقط (حاوية الرسائل)، دون أي
  //     عنصر بداخلها — طلب صريح.
  //   • لون الأزرار (buttons)     → أزرار .btn-primary/.label-primary فقط —
  //     كلاس bg-* (مثل bg-primary) مستقل تماماً، لا يظهر هنا إطلاقاً.
  // ═══════════════════════════════════════════════════════════════════════
  const hexOf = (v) => {
    const raw = String(v || '').trim().replace(/^#/, '');
    return /^[0-9a-fA-F]{6}$|^[0-9a-fA-F]{3}$/.test(raw) ? '#' + raw : null;
  };
  const templateColor = hexOf(s.bg);
  const contentColor  = hexOf(s.background);
  const buttonsColor  = hexOf(s.buttons);
  const colorRules = [];
  // ▲ إضافة (طلب صريح: ".pmsgc/.ppmsgc — احذف منها التعليق والليكات، اقصد
  //   كل الاعلانات"): appraad2.js يبني زرَّي .blike/.breply لأي صف يحمل bid
  //   (تشمل pmsg/ppmsg لأنهما يُرسَلان بـbid أيضاً — راجع case
  //   'pmsg'/'ppmsg' بالسيرفر)، فتظهران حسب bclikes/bcreply تماماً كمنشور
  //   حائط حقيقي رغم أن pmsg/ppmsg إعلانات إدارية فقط. إخفاء بصري صرف هنا
  //   (لا يمس .bdel، فتبقى إمكانية حذف الإعلان نفسها كما هي)؛ لم أضِف تحققاً
  //   خلفياً موازياً لأن bid الخاص بهما غير مُتتبَّع أصلاً بأي مكان (لا
  //   globalWall ولا recentMessages)، فالسيرفر لا يملك طريقة لتمييزه عن bid
  //   منشور حائط حقيقي دون بنية تتبّع جديدة كاملة — أخبرني إن كنت تريدها.
  //   قاعدة غير مشروطة بأي لون (تعمل دائماً بصرف النظر عن s.background).
  colorRules.push(`.uzr.pmsgc .blike,.uzr.pmsgc .breply,.uzr.ppmsgc .blike,.uzr.ppmsgc .breply{display:none !important;}`);
  if (templateColor) {
    colorRules.push(`.bg:not(body):not(#mic *){background-color:${templateColor} !important;}`);
  }
  if (contentColor) {
    // ▲ تبسيط جذري بطلب صريح ("احذف كامل، اجعله يغيّر لون id=2 فقط دون
    //   تغيير أي شيء من ألوان الأقسام التي بداخله"): الإصدارات السابقة
    //   استهدفت .d2/#rooms/#users/#lonline/.uzr/.room معاً، ثم دخلنا في
    //   صراع خصوصية CSS متكرر مع .pmsgc/.ppmsgc/.hmsg (التي تحمل .uzr على
    //   نفس عنصرها). الحل الجذري: تلوين #d2 نفسها فقط (الحاوية)، لا أي
    //   عنصر بداخلها. بما أن background-color خاصية لا تُورَّث في CSS
    //   إطلاقاً (بعكس color مثلاً)، فلا يوجد أي مسار تقني يجعل هذا يؤثر
    //   على .uzr أو .pmsgc/.ppmsgc/.hmsg أو أي صف رسالة بداخله مهما كان
    //   لونه الخاص — بلا حاجة لأي استثناء أو قاعدة مضادة إطلاقاً.
    //   #rooms/#users/#lonline/.room لم تعد مشمولة (لم تُطلَب صراحة الآن)،
    //   تبقى بخلفيتها الافتراضية من القالب.
    colorRules.push(`#d2{background-color:${contentColor} !important;}`);
  }
  if (buttonsColor) {
    colorRules.push(`.label-primary,.btn-primary,.label-primary:hover,.btn-primary:hover,.btn-primary:focus{background-color:${buttonsColor} !important;background-image:none !important;}`);
  }
  if (colorRules.length) {
    const styleTag = `<style>${colorRules.join('')}</style>`;
    html = html.includes('</head>')
      ? html.replace('</head>', styleTag + '</head>')
      : styleTag + html;
  }

  // ▲ إعادة تنفيذ ميزة "محظوري الغرفة" (البند 53/54 السابقين) دون أي تعديل
  //   على ملف index.html نفسه إطلاقاً — بناءً على طلب صريح. بدل تحرير الملف
  //   على القرص، يُحقن نفس العنصرين (الحاوية + السكربت) بالسلسلة النصية هنا
  //   وقت خدمة كل طلب، فيبقى index.html الفعلي كما هو تماماً بلا أي تغيير،
  //   والنتيجة التي يستلمها المتصفح مطابقة 100% لما كانت عليه بالنسخة
  //   المُعدَّلة يدوياً سابقاً.
  const opsAnchor = '<div class="break border corner" id="ops" style="width:100%;padding:2px;">\n              </div>';
  if (html.includes(opsAnchor)) {
    const rbansBlock = opsAnchor
      + '\n              <label style="width:100%;display:block;font-size:11px;color:#888;margin:4px 0 0 2px;">محظورين من الغرفة مؤقتاً</label>'
      + '\n              <div class="break border corner" id="rbans" style="width:100%;padding:2px;">\n              </div>';
    html = html.replace(opsAnchor, rbansBlock);
  }
  const rbansScript = `<script>
(function () {
  var lastList = null;
  function renderRoomBans(list) {
    lastList = list;
    var c = $('#rbans');
    if (!c.length) return;
    c.children().remove();
    if (!list || !list.length) {
      c.append('<div style="padding:4px;color:#aaa;font-size:12px;">لا يوجد محظورين حالياً</div>');
      return;
    }
    list.forEach(function (item) {
      var row = $($('#uhead').html()).css('background-color', 'white');
      row.find('.u-pic').css('width', '24px').css('height', '24px').css('background-image', 'url("' + item.pic + '")');
      var mins = Math.max(0, Math.round((item.until - Date.now()) / 60000));
      row.find('.u-topic').html(item.topic + ' <small style="color:#c00;">(يتبقى ' + mins + ' د)</small>');
      row.css('width', '98%');
      row.prepend('<button onclick="send(\\'rban-\\',{lid:\\'' + item.lid + '\\'});" class="btn-danger fa fa-times"></button>');
      c.append(row);
    });
  }
  // ▲ تحديث فوري حقيقي (بنفس اللحظة) عبر EventSource بدل استطلاع دوري متأخر
  //   حتى 4 ثوانٍ. EventSource مدعومة أصلاً بكل متصفح وتُعيد الاتصال تلقائياً
  //   عند أي انقطاع دون أي كود إضافي — مستقلة تماماً عن appraad2.js.
  var es = null, esRoom = null;
  function connect() {
    if (typeof myroom === 'undefined' || !myroom || myroom === esRoom) return;
    if (es) { es.close(); }
    esRoom = myroom;
    es = new EventSource('/api/roombans-stream?room=' + encodeURIComponent(myroom));
    es.onmessage = function (e) {
      try { renderRoomBans(JSON.parse(e.data)); } catch (err) {}
    };
  }
  setInterval(connect, 1000); // يتحقق فقط من تغيّر الغرفة (بلا أي طلب شبكة) ليعيد الاتصال بالغرفة الصحيحة عند التنقل بين الغرف
  connect();
  setInterval(function () { if (lastList) renderRoomBans(lastList); }, 30000); // إعادة رسم دورية خفيفة (بلا شبكة) لتحديث نص "يتبقى X د" فقط
})();
</script>`;
  const closeBodyTagRbans = '</body>';
  html = html.includes(closeBodyTagRbans)
    ? html.replace(closeBodyTagRbans, rbansScript + closeBodyTagRbans)
    : html + rbansScript;

  // ▲ إصلاح جوهري (اكتُشف عبر رسالة خطأ فعلية بالمتصفح: "ReferenceError:
  //   nopm is not defined" / "nonot is not defined"): زرا "تعطيل المحادثات
  //   الخاصة" و"تعطيل التنبيهات" بـindex.html يقرآن المتغيّرين nopm/nonot
  //   مباشرة (`if (nopm) {...}`) قبل أي تعريف لهما بأي مكان بالصفحة كلها —
  //   لا appraad2.js ولا أي سكربت آخر يُعرِّفهما. قراءة متغيّر غير مُعرَّف
  //   إطلاقاً (بخلاف متغيّر مُعرَّف بقيمة undefined) تُطلق ReferenceError
  //   فوراً عند نقطة `if`، فلا يُنفَّذ أي من الفرعين (لا then ولا else) —
  //   هذا سبب توقّف العلامة ✓ عن الاستجابة كلياً من أول ضغطة، لا علاقة له
  //   بمنطق nonotScript أدناه (الذي يعمل بشكل صحيح لو وصل لمرحلة التنفيذ
  //   أصلاً). typeof آمن هنا تحديداً (بخلاف القراءة المباشرة) لأنه لا يُطلق
  //   استثناءً على متغيّر غير مُعرَّف.
  const globalsInitScript = '<script>'
    + 'if (typeof nopm  === "undefined") { window.nopm  = false; }'
    + 'if (typeof nonot === "undefined") { window.nonot = false; }'
    + '</script>';
  html = html.includes(closeBodyTagRbans)
    ? html.replace(closeBodyTagRbans, globalsInitScript + closeBodyTagRbans)
    : html + globalsInitScript;

  // ▲ إضافة: appraad2.js زر "تعطيل التنبيهات" يبدّل متغيّر nonot المحلي
  //   ويحدّث علامة ✓ بصرياً فقط، ولا يرسل أي شيء للسيرفر إطلاقاً (بخلاف زر
  //   "تعطيل المحادثات الخاصة" المجاور له الذي يرسل busy فعلياً) — البند
  //   الثاني عشر بالمستند. سكربت مستقل تماماً (لا يلمس الزر الأصلي ولا
  //   onclick الحالي، فقط يضيف مستمعاً إضافياً على نفس العنصر) يرسل الحالة
  //   الفعلية فور الضغط، بعد أن يكون onclick الأصلي (المُسجَّل أولاً كسمة
  //   inline) قد بدّل قيمة nonot بالفعل.
  const nonotScript = `<script>
(function () {
  function bind() {
    var el = $('label:contains("تعطيل التنبيهات")').first();
    if (!el.length || el.data('nonotBound')) return;
    el.data('nonotBound', true);
    el.on('click', function () {
      setTimeout(function () {
        if (typeof nonot !== 'undefined' && typeof send === 'function') send('nonot', { nonot: nonot });
      }, 0);
    });
  }
  setInterval(bind, 1000); // العنصر داخل نافذة تُبنى ديناميكياً، فقد يظهر متأخراً
  bind();
})();
</script>`;
  html = html.includes(closeBodyTagRbans)
    ? html.replace(closeBodyTagRbans, nonotScript + closeBodyTagRbans)
    : html + nonotScript;

  if (s.script) {
    // ▲ إصلاح جوهري: إذا احتوى السكربت المخصص المحفوظ على أي تسلسل حرفي
    //   يشبه "</script" (حتى عرضاً، كتعليق أو نص داخل سلسلة نصية بالسكربت
    //   نفسه)، كان يُغلق وسم <script> المُحقَن مبكراً، فيتحوّل باقي محتوى
    //   السكربت (كل ما بعد ذلك التسلسل) إلى نص HTML خام ظاهر مباشرة في
    //   الصفحة، وقد يُربك مُحلِّل HTML بالمتصفح (خصوصاً لو تضمّن وسوماً غير
    //   مكتملة) فيُعيد بناء الصفحة بشكل غير متوقع — وهذا التفسير الأرجح
    //   لتضخّم/ازدواج محتوى الصفحة الذي ظهر فعلياً في اختبارك، وليس له أي
    //   علاقة بلون الخلفية إطلاقاً (تغيير background-color لا يمكنه
    //   فيزيائياً التأثير على أبعاد/ارتفاع أي عنصر في CSS). الحل: تفكيك أي
    //   تسلسل "</script" داخل محتوى السكربت المحفوظ قبل الحقن.
    const safeScript = String(s.script).replace(/<\/script/gi, '<\\/script');
    // سكربت المبرمج المخصص — يُحقن قبل نهاية body (بعد appraad2.js) كما في نمط /cp
    const closeBodyTag = '</body>';
    const customScript = '<script>' + safeScript + '</script>';
    html = html.includes(closeBodyTag)
      ? html.replace(closeBodyTag, customScript + closeBodyTag)
      : html + customScript;
  }

  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.send(html);
});

// ─── مسار لوحة التحكم ─────────────────────────────────────────────────────────
// appraad2.js: $("#settings .cp").attr("href","cp?cp="+myid) → target="_blank" rel="opener"
// → المتصفح يطلب GET /cp?cp=MYID → يُعاد index.html
// المصادقة الأولية: سيرفر يتحقق من وجود المستخدم وصلاحية cp
// المصادقة الكاملة داخل العميل: window.opener.myid == _0x51f8c1
app.get('/cp', (req, res) => {
  const cpId = req.query.cp;
  if (!cpId) return res.redirect('/');

  const cpUser = byUID(cpId);
  if (!cpUser) return res.redirect('/');

  const indexPath = path.join(__dirname, 'public', 'index.html');
  let html;
  try { html = require('fs').readFileSync(indexPath, 'utf8'); }
  catch (e) { return res.sendFile(indexPath); }

  // ▲ إصلاح جوهري: كان السكربت يُحقَن قبل </body> (متأخر جداً). الحاسم في
  //   تنفيذ مستمعي "message" المُسجَّلين على نفس الـ target (window) هو
  //   ترتيب التسجيل فقط — وليس علم useCapture كما افتُرض سابقاً (فرق
  //   capture/bubble لا معنى له إلا عبر مسار انتشار بين عناصر أب/ابن
  //   مختلفة، وwindow هو نفسه الهدف هنا). لذا كان مستمع appraad2.js
  //   (يُسجَّل مبكراً جداً ضمن التهيئة الأساسية) يسبق مستمعنا دائماً مهما
  //   وضعنا useCapture=true، فتصل stopImmediatePropagation متأخرة جداً —
  //   بعد أن يكون appraad2.js قد نفّذ close بالفعل (window.close() + علم
  //   داخلي يُجمِّد كل معالجة لاحقة نهائياً). وهذا بالضبط سبب "التجمد" عند
  //   الفتح حين يرفض المتصفح إغلاق النافذة فعلياً فتبقى ظاهرة لكن مُجمَّدة.
  //   الحل: الحقن الآن أول شيء داخل <head> لضمان تسجيل مستمعنا قبل أي
  //   سكربت آخر بالصفحة، بصرف النظر عن مكان appraad2.js بالملف الأصلي.
  //
  // كذلك أُضيفت الخطوة الثانية (إظهار #cp وإخفاء #room بعد con) التي كانت
  // موصوفة فقط بالتعليق القديم وغير مُنفَّذة إطلاقاً في الكود الفعلي.
  const scriptLines = [
    '(function(){',
    '  if(location.pathname!=="/cp")return;',
    '  var done=false,t0=Date.now();',
    '  window.addEventListener("message",function(e){',
    '    if(!Array.isArray(e.data))return;',
    '    if(e.data[0]==="con"){',
    '      done=true;',
    // إظهار #cp وإخفاء #room فعلياً بعد اكتمال المصافحة
    '      setTimeout(function(){',
    '        try{ if(window.jQuery){ jQuery("#cp").show(); jQuery("#room").hide(); } }catch(err){}',
    '      },120);',
    // حجب close المبكر فقط قبل اكتمال con، وضمن سقف أمان 5 ثوانٍ
    // (لتفادي حجب رسائل إغلاق مشروعة لاحقة إذا تأخرت con لأي سبب)
    '    }else if(e.data[0]==="close"&&!done&&(Date.now()-t0)<5000){',
    '      e.stopImmediatePropagation();',
    '    }',
    '  });',
    '})();'
  ];
  const fixScript = '<script>' + scriptLines.join('') + '<' + '/script>';

  // مطابقة <head> بأي خصائص (مثل <head lang="ar">)، مع fallback على <html>
  // ثم بداية الملف كحل أخير
  const headTagMatch = html.match(/<head[^>]*>/i);
  if (headTagMatch) {
    html = html.replace(headTagMatch[0], headTagMatch[0] + fixScript);
  } else if (/<html[^>]*>/i.test(html)) {
    html = html.replace(/<html[^>]*>/i, m => m + fixScript);
  } else {
    html = fixScript + html;
  }

  // ▲ إصلاح: نفس تعريف nopm/nonot الناقص المُصلَح بمسار / أعلاه — /cp يخدم
  //   نفس index.html (فيه نفس الزرين فعلياً)، فنفس ReferenceError ممكن هنا
  //   أيضاً لو ضُغط عليهما داخل نافذة CP لأي سبب.
  const cpGlobalsInitScript = '<script>'
    + 'if (typeof nopm  === "undefined") { window.nopm  = false; }'
    + 'if (typeof nonot === "undefined") { window.nonot = false; }'
    + '</script>';
  html = html.includes('</body>')
    ? html.replace('</body>', cpGlobalsInitScript + '</body>')
    : html + cpGlobalsInitScript;

  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.send(html);
});

// ─── قواعد البيانات في الذاكرة ────────────────────────────────────────────────
/** socketId → User   */  const users    = new Map();
/** roomId   → Room   */  const rooms    = new Map();
/** nameKey  → AccObj */  const accounts = new Map();
const loadedAccounts = readJsonFile(ACCOUNTS_FILE, []);
for (const acc of Array.isArray(loadedAccounts) ? loadedAccounts : []) {
  const nameKey = String(acc.lid || acc.name || acc.id || '').trim();
  if (nameKey) accounts.set(nameKey, acc);
}
/** token → session   */  const sessions = new Map();  // للحفاظ على الجلسة بعد قطع الاتصال
/** آخر 30 مستخدم سجّلوا دخولاً (للقائمة قبل تسجيل الدخول #lonline) */
const recentLogins = [];
const MAX_RECENT   = 30;

/** حائط عالمي مشترك بين جميع الغرف والمتصلين */
const globalWall = [];

// ▲ إضافة: appraad.js يرسل likem/reply بمعرّف الرسالة (mi) فقط دون أي بيانات
//   عن صاحبها — ولا يوجد أي تخزين للرسائل العامة إطلاقاً (بخلاف الحائط
//   المخزَّن فعلياً في globalWall أعلاه). دون هذا التخزين يستحيل معرفة من
//   يجب إشعاره عند إعجاب/رد على رسالته، أو حتى معرفة عدد اللايكات الحقيقي.
//   محدودة الحجم عمداً (تُبقي آخر MAX_RECENT_MSGS فقط) لتفادي أي تسرّب ذاكرة.
const recentMessages = new Map(); // mi -> {uid, lid, topic, pic, likes, roomid}
const MAX_RECENT_MSGS = 300;
function trackMessage(mi, payload, roomid) {
  recentMessages.set(mi, { uid: payload.uid, lid: payload.lid, topic: payload.topic, pic: payload.pic, likes: 0, roomid });
  if (recentMessages.size > MAX_RECENT_MSGS) {
    recentMessages.delete(recentMessages.keys().next().value); // إزالة الأقدم (ترتيب الإدراج بالـMap مضمون بمعيار JS)
  }
}
// ▲ إضافة: منع تكرار الإعجاب لنفس العنصر خلال دقيقة واحدة (طلب صريح) — يشمل
//   لايكات الرسائل العامة/الحائط/الإعجاب الشخصي UPRO معاً بنفس الآلية.
const lastLikeAt = new Map(); // `${likerUid}:${targetKey}` -> timestamp
function likeCooldownRemaining(likerUid, targetKey) {
  const last = lastLikeAt.get(`${likerUid}:${targetKey}`);
  if (!last) return 0;
  const elapsed = Date.now() - last;
  return elapsed < 60000 ? Math.ceil((60000 - elapsed) / 1000) : 0;
}
function markLiked(likerUid, targetKey) {
  lastLikeAt.set(`${likerUid}:${targetKey}`, Date.now());
  if (lastLikeAt.size > 5000) {
    lastLikeAt.delete(lastLikeAt.keys().next().value);
  }
}


// ▲ إصلاح/إضافة: case 'actions' (تبويب "الحالات" في لوحة التحكم) كان مجرد
//   stub يُرجع دائماً قائمة فارغة، رغم أن واجهة العميل (cp_actions مع دعم
//   بحث q وترقيم صفحات i) مبنية بالكامل لعرض سجل فعلي — تماماً كما هو
//   الحال في fps/logins. أضفنا سجلاً حقيقياً في الذاكرة (actionsLog).
// ▲ إصلاح إضافي (مهم جداً): appraad2.js يقرأ من كل عنصر تحديداً الحقول:
//   type, u1, u2, room, ip, created (راجع case "cp_actions" في العميل) —
//   المحاولة الأولى استخدمت أسماء حقول مختلفة كلياً (action, by, byLid, t,
//   details) فكان الجدول بأكمله يظهر "undefined" كما في الصورة المرفقة.
//   الأسماء الآن مطابقة حرفياً لما يقرأه العميل.
const actionsLog = [];
const MAX_ACTIONS_LOG = 5000;
/** تسمية عربية مقروءة لكل نوع إجراء، تُعرض بعمود "الحاله" في تبويب الحالات بدل اسم الأمر البرمجي */
function actionTypeLabel(type) {
  const labels = {
    kick: 'طرد عضو', ban: 'حظر عضو', aban: 'رفع حظر', unban: 'رفع حظر',
    delu: 'حذف عضوية', setpower: 'تغيير صلاحية', pwd: 'تغيير كلمة مرور',
    delpic: 'حذف صورة', roomkick: 'طرد من الغرفة',
    'op+': 'تعيين مشرف', 'op-': 'إزالة مشرف',
    'r+': 'إنشاء غرفة', 'r^': 'تعديل غرفة', 'r-': 'حذف غرفة',
    v: 'تفعيل/تعطيل مايك الغرفة',
    dmsg: 'حذف رسالة', delbc: 'حذف منشور حائط', cleanbc: 'تنظيف منشورات عضو',
    unick: 'تغيير اسم عضو', rinvite: 'نقل عضو لغرفة',
    bnr: 'تعيين بنر', 'bnr-': 'إزالة بنر',
    setLikes: 'تعديل إعجابات', likes: 'تعديل إعجابات',
    uml: 'سحب من المايك', umm: 'قفل مايك عضو', uma: 'تفعيل مايك عضو',
    micstat: 'تعديل حالة مقعد مايك',
    addico: 'إضافة أيقونة', delico: 'حذف أيقونة',
    bot_save: 'حفظ إعدادات البوتات', 'bot-new': 'إنشاء بوت',
    'bot-edit': 'تعديل بوت', 'bot-del': 'حذف بوت',
    msgsit: 'إضافة رسالة جاهزة', msgsdel: 'حذف رسالة جاهزة',
    shrtdel: 'حذف اختصار', fltrit: 'إضافة كلمة فلتر', fltrdel: 'حذف كلمة فلتر',
    gift: 'إرسال هدية', emo_order: 'ترتيب الإيموجيات',
    powers_save: 'حفظ صلاحية', powers_del: 'حذف صلاحية',
    sitesave: 'حفظ إعدادات الموقع', owner_save: 'حفظ إعدادات المالك',
    domainsave: 'حفظ نطاق', domaindel: 'حذف نطاق',
    favicon: 'تغيير أيقونة الموقع', prv1: 'تغيير صورة الموقع',
    pic: 'تغيير الصورة الافتراضية للعضو', room: 'تغيير الصورة الافتراضية للغرفة',
    report: 'بلاغ عن عضو'
  };
  return labels[type] || type;
}

function logAction(actor, type, target = null, extra = '') {
  const targetLabel = typeof target === 'string'
    ? target
    : (target?.topic || target?.lid || '');
  actionsLog.push({
    type,                                     // appraad: "الحاله" — يُترجَم للعربية عند العرض (راجع actionTypeLabel)
    u1:      actor?.topic || actor?.lid || '', // appraad: "العضو" (من قام بالإجراء)
    u2:      targetLabel + (extra ? ` — ${extra}` : ''), // appraad: "العضو الثاني" (الهدف)
    room:    (actor?.roomid && rooms.get(actor.roomid)?.name) || '',
    ip:      actor?._ip || '',
    created: Date.now()                       // appraad: يُستخدم لحساب "الوقت"
  });
  if (actionsLog.length > MAX_ACTIONS_LOG) actionsLog.shift();
}

// ▲ إضافة (البند الثالث بمستند "المرحلة الثالثة"): سجل تسجيل الدخول —
//   منفصل تماماً عن actionsLog أعلاه عمداً (المستند صريح: "ليس سجلاً عاماً
//   لجميع العمليات الإدارية"). يُسجَّل فيه حصراً 4 حالات (وليس 5 كما يبدو
//   ظاهرياً بالمستند: "دخول زائر" ناجح و"تسجيل عضو جديد" ناجح لا حالة فشل
//   موازية لهما مذكورة، فلا تُسجَّل حالات فشل الزائر/التسجيل الأخرى):
//   عضو جديد (نجاح reg) / تسجيل دخول (نجاح login) / زائر (نجاح g) /
//   كلمة سر خاطئة (فشل login بسبب كلمة المرور تحديداً) / مستخدم محظور
//   (فشل g أو login بسبب حظر — pickJoinableRoom لم يجد غرفة متاحة).
const loginLog = [];
const MAX_LOGIN_LOG = 1000;
function logLogin(username, status, ip) {
  loginLog.push({ u: username || '', status, ip: ip || '', created: Date.now() });
  if (loginLog.length > MAX_LOGIN_LOG) loginLog.shift();
}

const SESSION_TTL = 5 * 60 * 1000; // 5 دقائق

// ▲ إضافة: عتبتا أيقونة الحضور (.ustat في appraad2.js — راجع computeStat()
//   وتعليق pub() أدناه لتفاصيل كل قيمة). لا مدة محددة صراحةً بطلب مهلة
//   الانتظار بعد قطع الاتصال — القيمة الحالية قابلة للتعديل بهذا السطر فقط.
const IDLE_MS             = 3 * 60 * 1000; // 3 دقائق بلا أي نشاط ⇒ stat=1
const DISCONNECT_GRACE_MS = 30 * 1000;      // 30 ثانية انتظار بعد قطع الاتصال ⇒ stat=3

// ─── هيكل المستخدم ────────────────────────────────────────────────────────────
class User {
  constructor(socketId, fields = {}) {
    this.socketId = socketId;   // ← يُحدَّث عند كل rc2
    this.id       = fields.id    || genId();
    this.lid      = fields.lid   || this.id;  // الزائر: lid = id
    this.topic    = fields.topic || 'زائر';
    this.msg      = fields.msg   || '(غير مسجل)';
    this.pic      = fields.pic   || 'pic.png';
    this.ico      = fields.ico   || '';
    this.co       = fields.co    || '--';
    this.bg       = fields.bg    || '';
    this.ucol     = fields.ucol  || '';
    this.mcol     = fields.mcol  || '';
    this.rep      = fields.rep   || 0;
    this.power    = fields.power || '';
    this.rank     = fields.rank  || 0;
    this.roomid   = null;
    this.token    = genId();
    this._fp      = fields._fp   || '';
    this._ip      = fields._ip   || '';
    this.s        = fields.s     || false;
    this.nopm     = false;
    this.nonot    = false;
    this.b        = fields.b     || '';   // أيقونة خاصة مباشرة (sico override)
    this.bnr      = fields.bnr   || '';   // بنر ترحيبي خاص بالعضو
    this.giftIco  = fields.giftIco || ''; // ▲ إضافة: اسم ملف الهدية الحالية (مجلد dro3) دون أي بادئة
    this.nopm     = fields.nopm  || false; // ▲ إضافة: تعطيل استقبال الرسائل الخاصة
    this.nonot    = fields.nonot || false; // ▲ إضافة: تعطيل استقبال التنبيهات
    this.refr     = fields.refr  || '';
    this.created  = Date.now();
    // ▲ إضافة: تاريخ إنشاء الحساب الفعلي (يُستخدم لشرط wall_minutes) —
    //   افتراضياً يساوي created (وقت بدء الجلسة، أي للزوار)، ويُستبدَل
    //   بتاريخ الحساب الحقيقي acc.created عند تسجيل الدخول كعضو.
    this.accCreated = this.created;
    this.last     = Date.now();
    // ▲ إضافة: حالة أيقونة الحضور (.ustat) — راجع computeStat()/refreshUserStat().
    this._stat      = null;   // آخر قيمة stat بُثَّت فعلياً (لتفادي بث مكرر بلا تغيير)
    this._discGrace = false;  // true أثناء مهلة انتظار إعادة الاتصال (stat=3)
    this._discTimer = null;   // مؤقت الطرد الفعلي بعد انتهاء DISCONNECT_GRACE_MS
  }

  /**
   * ما يُرسَل للعملاء الآخرين
   * appraad.js يستخدم:
   *   userObj.id, userObj.lid, userObj.topic, userObj.username
   *   userObj.msg, userObj.pic, userObj.ico, userObj.co
   *   userObj.bg, userObj.ucol, userObj.mcol
   *   userObj.rep, userObj.power, userObj.rank
   *   userObj.roomid, userObj.s
   *   userObj.h (يولده appraad.js من username)
   */
  pub() {
    return {
      id:       this.id,
      lid:      this.lid,
      username: this.lid,    // appraad.js: executeHashAlgorithm([userObj.username||'ff'])
      topic:    this.topic,
      msg:      this.msg,
      pic:      this.pic,
      ico:      this.ico,
      co:       this.co,
      bg:       this.bg,
      ucol:     this.ucol,
      mcol:     this.mcol || '',
      rep:      this.rep,
      power:    this.power,
      rank:     this.rank,
      roomid:   this.roomid,
      b:        this.b    || null,   // أيقونة خاصة — appraad.js: if(userObj.b) return "sico/"+userObj.b
      bnr:      this.bnr  || '',
      s:        this.s || null,   // appraad.js: logItem.s == null → غير متخفٍ
      // ▲ إصلاح: appraad2.js يبني "imgs/s"+stat+".png" لأيقونة الحالة (.ustat)
      //   ويحدّثها فوراً عند استقبال أي u^ يتضمّن حقل stat (دالة تحديث الواجهة
      //   حول السطر 3226/3257/3292/3304 من appraad2.js). هذا الحقل لم يكن
      //   موجوداً إطلاقاً فكانت تظهر "sundefined.png" دائماً. المخطط الكامل
      //   (طلب صريح لاحق): 0=نشط، 1=خامل 3 دقائق، 2=قفل الخاص(nopm)،
      //   3=بانتظار إعادة الاتصال. المصدر الموحَّد لكل هذه القيم: computeStat().
      stat:     computeStat(this)
    };
  }
}

// ─── صلاحية الإدارة الافتراضية ────────────────────────────────────────────────
// الحقول مرتبة حسب مصفوفة appraad2.js السطر 5425 مطابقةً 100%
const DEFAULT_ADMIN_POWER = {
  rank:       9999,
  name:       'adminster',
  ico:        '',
  kick:       100,        // عدد — الطرد
  delbc:      true,       // حذف الحائط
  alert:      true,       // التنبيهات
  mynick:     true,       // تغيير نك نفسه
  unick:      true,       // تغيير نكات الآخرين
  ban:        true,       // الباند
  publicmsg:  true,       // الإعلانات
  ppmsg:      true,       // إعلانات السوابر
  forcepm:    true,       // فتح الخاص
  roomowner:  true,       // إدارة الغرف
  createroom: true,       // إنشاء الغرف
  rooms:      10,         // عدد — أقصى حد للغرف الثابتة
  edituser:   true,       // إدارة العضويات
  setpower:   true,       // تعديل الصلاحيات
  upgrades:   true,       // الهدايا
  history:    true,       // كشف النكات
  cp:         true,       // لوحة التحكم
  rjoin:      true,       // دخول الغرف المغلقة
  stealth:    true,       // مخفي
  setLikes:   true,       // لايكات
  dmsg:       true,       // مسح الرسائل
  rinvite:    true,       // نقل الزوار
  mic:        true,       // سحب المايك
  cmic:       true,       // تفعيل المايك
  owner:      true        // إدارة الموقع
};

// ─── مصفوفة الصلاحيات العامة للموقع (مشتركة بين كل الغرف) ───────────────────────
// appraad2.js يستخدم _0x5a3802 كمصفوفة واحدة مشتركة — نفس المنطق هنا
const globalPowers = [{ ...DEFAULT_ADMIN_POWER }];

// ─── هيكل الغرفة ──────────────────────────────────────────────────────────────
class Room {
  constructor(id, name, pass = '') {
    this.id       = id;
    this.name     = name;
    this.pass     = pass ? bcrypt.hashSync(pass, SALT_ROUNDS) : '';
    this.needpass = pass !== '';
    this.pic      = 'room.png';
    this.bg       = '';
    this.ucol     = '';
    this.c        = '#000000';
    this.about    = '';
    this.welcome  = '';
    this.max      = 20;
    this.l        = 0;           // appraad.js .rl  → أقل مستوى/مطلوب للدخول
    this.vl       = 0;           // appraad.js .rvl → أقل مستوى VIP مطلوب للدخول
    this.owner    = null;
    this.botsConfig = { active: false, minStay: 0, maxStay: 0, minLeave: 0, maxLeave: 0 };
    // ▲ إصلاح: كانت هذه القيم ثابتة دائماً بغض النظر عمّا حفظه المشرف فعلياً
    //   بـ"خيارات الموقع" (sitesave) — أي غرفة جديدة تُنشأ كانت تتجاهل ذلك
    //   الإعداد تماماً وتبدأ بالقيم الافتراضية الثابتة أدناه دوماً. الآن ترث
    //   القيمة الحالية المحفوظة فعلياً إن وُجدت، وإلا تستخدم نفس الافتراضي
    //   السابق كما هو (لا تغيير لأي غرفة/سلوك موجود مسبقاً).
    const _gs = global.siteSettings || {};
    this.settings = {
      mic:      _gs.mic      ?? true,
      setpower: true,
      ban:      true,
      owner:    true,
      calls:    _gs.calls    ?? true,
      mlikes:   _gs.mlikes   ?? true,
      bclikes:  _gs.bclikes  ?? true,
      mreply:   _gs.mreply   ?? true,
      bcreply:  _gs.bcreply  ?? true
    };
    this.ops      = [];          // lid[] المشرفون
    this.sicos    = [];
    this.emos     = [];
    this.colors   = [];          // dro3
    // *** appraad.js يقرأ mic كمصفوفة: mic[index] = userId|0|false
    // mic[i]=0 → فارغ، mic[i]=false → مقفول، mic[i]=string → يتحدث
    this.mic      = new Array(MAX_MIC_SLOTS).fill(0);
    this.members  = new Map();   // socketId → User
    // ▲ حذف: this.wall كانت خاصية ميتة تماماً (تُنشأ فارغة ولا يملؤها أي
    //   كود إطلاقاً) — الحائط عالمي فعلياً ويُخزَّن بالكامل في globalWall
    //   (متغيّر عام مشترك بين كل الغرف، راجع case 'bc'/'likebc'/'delbc'/
    //   'cleanbc')، فلا داعي لأي خاصية wall خاصة بكل غرفة على حدة.
    this.bots     = new Map();
    // ▲ إصلاح معماري: this.bans (حظر عام) أصبحت globalBans (متغيّر عام
    //   على مستوى الموقع بأكمله، وليس لكل غرفة على حدة — راجع isBanned).
    // ▲ إضافة: this.roomBans — حظر مؤقت خاص بهذه الغرفة فقط (٢٠ دقيقة بعد
    //   الطرد منها تحديداً عبر roomkick)، منفصل تماماً عن الحظر العام أعلاه
    //   ولا يُضاف لقائمة الحظر بلوحة التحكم. lid → { until, byLid, byName, reason }
    this.roomBans = new Map();
  }
}

// ─── مساعدات ──────────────────────────────────────────────────────────────────
function genId() {
  return uuidv4().replace(/-/g, '').slice(0, 16);
}

// ▲ إضافة: تحويل الأرقام العربية (١٢٣...) والفارسية الممتدة (۱۲۳...) إلى
//   إنجليزية قبل أي إرسال/حفظ. أُضيفت داخل sanitize نفسها (نقطة التنظيف
//   الموحَّدة المستخدمة بكل مكان: عام/خاص/حائط/إعلانات عامة وخاصة/تنبيهات/
//   ترحيب/تلقائية) فتغطي كل الحالات المطلوبة بتعديل واحد فقط دون تكرار.
const ARABIC_DIGITS = '٠١٢٣٤٥٦٧٨٩';
const PERSIAN_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
function convertDigits(str) {
  return str.replace(/[٠-٩۰-۹]/g, (d) => {
    const ai = ARABIC_DIGITS.indexOf(d);
    if (ai !== -1) return String(ai);
    const pi = PERSIAN_DIGITS.indexOf(d);
    return pi !== -1 ? String(pi) : d;
  });
}
function sanitize(str, maxLen = 2000) {
  if (typeof str !== 'string') return '';
  return convertDigits(str).replace(/</g, '&lt;').replace(/>/g, '&gt;').slice(0, maxLen);
}

// ▲ إصلاح جوهري (سبب ظهور الصور بيضاء/فارغة عند الإرسال بالخاص أو الحائط):
//   appraad2.js لا يقرأ أي حقل "link" منفصل من الرسالة الواردة إطلاقاً —
//   تحققتُ من الملف بالكامل ولا يوجد أي "‎.link"‎ أو ‎["link"]‎ في أي مكان.
//   الآلية الحقيقية: دالة عرض الرسائل تفحص نص الرسالة (msg) نفسه بحثاً عن
//   وسم <a class="uplink" href="..."> ثم تُحوِّله تلقائياً لصورة/فيديو/صوت
//   فعلي حسب امتداد الملف في href (راجع "a.uplink" في appraad2.js). كان
//   كودي يُرسل الرابط في حقل payload.link منفصل تماماً — لا يُقرأ أبداً،
//   فتظهر فقاعة الرسالة فارغة/بيضاء دائماً. الحل: تضمين الرابط داخل نص
//   الرسالة نفسه بهذا الوسم بدل إرساله كحقل مستقل.
function wrapUplink(link) {
  const safeLink = sanitize(String(link || ''), 500);
  if (!safeLink) return '';
  return `<a class="uplink" href="${safeLink}">${safeLink}</a>`;
}

// ▲ إصلاح/إضافة: نظام فلتر الكلمات (global.filters) كان قابلاً للإدارة
//   بالكامل من لوحة التحكم (إضافة/حذف كلمات عبر fltrit/fltrdel) لكنه لم
//   يكن مُطبَّقاً إطلاقاً — لا شيء كان يتحقق من أي رسالة أو منشور أو خاص
//   مقابل هذه القائمة، فكانت كل الكلمات المُضافة بلا أي أثر فعلي. كذلك
//   global.filtersTemp (سجل الرسائل المحظورة المعروض في تبويب الفلتر) لم
//   يكن يُملأ أبداً، وحتى زر حذفه (fltrdelx) كان stub فارغاً تماماً.
// ▲ إعادة تصميم كاملة لنظام الفلتر:
//   1) كان global.filters كائناً يُخزَّن فيه كل عنصر بمفتاح = data.path
//      المُرسل من العميل مباشرة؛ إذا أرسلت الواجهة نفس path لكل إضافة (كما
//      يبدو من الشكوى) كانت كل إضافة جديدة تستبدل السابقة عند نفس المفتاح —
//      أي "كلمة واحدة فقط لكل تصنيف تُحفظ فعلياً". الحل: مصفوفة، وكل إضافة
//      تحصل على معرّف فريد يُولَّد في السيرفر نفسه (بصرف النظر عمّا يرسله
//      العميل في path)، فتُضاف دوماً كعنصر جديد مستقل بلا حد أقصى للعدد.
//   2) ثلاث تصنيفات حقيقية الآن بدل تصنيف واحد ("ممنوع" فقط سابقاً):
//      - allow (مسموح): كلمات مستثناة صراحة؛ لها الأولوية على كل شيء آخر.
//      - watch (مراقبة): يُسمح بإرسال الرسالة لكنها تُسجَّل في سجل الفلتر.
//      - ban   (ممنوع):  يُمنع الإرسال فوراً مع تنبيه للمرسل.
//      يُستنتج التصنيف من بادئة path (قبل أول '/') إن كانت إحدى القيم
//      الثلاث أعلاه، أو من حقل type مباشرة إن أُرسل، وإلا فالافتراضي "ban"
//      (الأكثر أماناً، ومطابق للسلوك القديم الذي كان يُعامل كل شيء كحظر).
let _filtersTempSeq = 1;
/** قراءة إعداد عام من إعدادات الموقع (global.siteSettings) بقيمة افتراضية */
function siteSetting(key, def) {
  const v = (global.siteSettings || {})[key];
  return v === undefined || v === null ? def : v;
}

function getFiltersArr() {
  if (!Array.isArray(global.filters)) global.filters = [];
  return global.filters;
}
/** تسمية عربية مقروءة لعرضها في عمود "التصنيف" بلوحة التحكم (index.html يعرض type كما هو حرفياً) */
function filterTypeLabel(type) {
  return { allow: 'مسموحة', ban: 'ممنوعة', watch: 'مراقبة' }[type] || type;
}
/** بناء قائمة الفلتر الجاهزة للإرسال عبر cp_fltr.a */
function buildFilterList() {
  return getFiltersArr().map(f => ({
    id: f.id, path: `${f.type}/${f.id}`, v: f.v, type: filterTypeLabel(f.type)
  }));
}
// ▲ إضافة: الاختصارات (global.shortcuts) كانت قابلة للإدارة بالكامل من لوحة
//   التحكم (إضافة/حذف عبر shrtadd/shrtdel) لكن غير مُطبَّقة إطلاقاً على أي
//   رسالة — لا appraad2.js نفسه يملك أي منطق استبدال محلي عند الكتابة
//   (تحققتُ من ذلك، لا وجود لكلمة "shortcut" في كامل الملف)، ولا كان
//   السيرفر يستبدلها أبداً. المنطق الأبسط والأكثر أماناً: إذا كان نص
//   الرسالة (بعد إزالة المسافات) يطابق تماماً اسم اختصار مُسجَّل (بغض النظر
//   عن حالة الأحرف)، يُستبدَل النص بالكامل بقيمة الاختصار قبل الإرسال.
function expandShortcut(text) {
  if (!text || !global.shortcuts) return text;
  const key = String(text).trim();
  if (!key) return text;
  const lowerKey = key.toLowerCase();
  for (const [name, value] of Object.entries(global.shortcuts)) {
    if (String(name).trim().toLowerCase() === lowerKey) return value;
  }
  return text;
}

function checkFilters(text) {
  if (!text) return null;
  const arr = getFiltersArr();
  const lower = String(text).toLowerCase();
  // "مسموح" لها الأولوية المطلقة — تُعفي النص من أي فحص لاحق
  for (const f of arr) {
    if (f.type === 'allow' && f.v && lower.includes(String(f.v).toLowerCase())) return null;
  }
  // "ممنوع" — يمنع الإرسال فوراً
  for (const f of arr) {
    if (f.type === 'ban' && f.v && lower.includes(String(f.v).toLowerCase())) {
      return { action: 'ban', v: f.v };
    }
  }
  // "مراقبة" — يُسمح بالإرسال لكن يُسجَّل
  for (const f of arr) {
    if (f.type === 'watch' && f.v && lower.includes(String(f.v).toLowerCase())) {
      return { action: 'watch', v: f.v };
    }
  }
  return null;
}
function logFilteredMessage(sender, matchedWord, fullMsg, action = 'ban') {
  if (!global.filtersTemp) global.filtersTemp = [];
  global.filtersTemp.push({
    id: _filtersTempSeq++,
    v:  matchedWord,
    action,
    msg: sanitize(String(fullMsg || ''), 500),
    topic: sender?.topic || '',
    ip: sender?._ip || ''
  });
  if (global.filtersTemp.length > 500) global.filtersTemp.shift();
}

function makeBid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 5) + '00';
}

/** سياق cpi: يُعيَّن أثناء dispatchCP لتوجيه الردود لنافذة لوحة التحكم */
let _cpiContext = null;

/** إرسال أمر مشفر لمقبس واحد */
function send(socket, cmd, data) {
  let payload = data;
  if (_cpiContext && socket.id === _cpiContext.socketId) {
    payload = { cpi: _cpiContext.cpiId, data };
  }
  socket.emit('msg', { cmd: decodeCmd(cmd), data: payload });
}

/** إرسال لجميع أعضاء الغرفة (مع استثناء اختياري) */
function toRoom(roomId, cmd, data, exceptSid = null) {
  const room = rooms.get(roomId);
  if (!room) return;
  room.members.forEach((_, sid) => {
    if (sid === exceptSid) return;
    const s = io.sockets.sockets.get(sid);
    if (s) send(s, cmd, data);
  });
}

/**
 * بث قائمة الصلاحيات لأعضاء الغرفة مع تضمين DEFAULT_ADMIN_POWER للأدمن.
 *
 * لماذا؟
 *   appraad2.js — case 'powers' يُنفِّذ:
 *     _0x41c3fc = _0x3e8a07(user.power)   ← يبحث باسم الصلاحية في مصفوفة _0x5a3802
 *   إذا لم يجد اسم الصلاحية (_0x35b969.power='adminster') في المصفوفة،
 *   يُعيد كائناً فارغاً (كل القيم صفر/false) → _0x41c3fc.cp = false
 *   → _0x515435() تُرسل ['close',{}] لجميع نوافذ CP المفتوحة → تُغلقها فوراً!
 *
 * الحل: أدرج DEFAULT_ADMIN_POWER في المصفوفة المُرسَلة لمن صلاحيته الاسمية تطابقها فقط
 * حتى يجدها _0x3e8a07 ويبقى _0x41c3fc.cp = true.
 */
// ▲ إصلاح جوهري: كانت تُرسل التحديث فقط لأعضاء غرفة واحدة (غرفة المشرف
//   وقت الحفظ)، رغم أن globalPowers قائمة عامة على مستوى الموقع بالكامل لا
//   علاقة لها بأي غرفة تحديداً. النتيجة: أي عضو متصل في غرفة أخرى (أو خارج
//   أي غرفة) لا يستلم التحديث إطلاقاً إلا عند انضمامه/تبديله لغرفة لاحقاً
//   (حيث تُرسَل powers الحديثة ضمن rcd من جديد) — وهذا يُفسِّر عدم "تعرّف
//   الموقع" على صلاحية أو فلتر مُضاف حتى تغيير الغرفة. الحل: البث لكل
//   المتصلين بالموقع دون استثناء.
function broadcastPowers() {
  users.forEach((memberUser, sid) => {
    const s = io.sockets.sockets.get(sid);
    if (!s) return;
    // من اسم صلاحيته يطابق DEFAULT_ADMIN_POWER: أضفه إذا غاب عن المصفوفة (بدون أي تحقق بالرنك)
    const powersArr = memberUser.power === DEFAULT_ADMIN_POWER.name
      ? globalPowers.some(p => p.name === DEFAULT_ADMIN_POWER.name)
        ? globalPowers
        : [...globalPowers, DEFAULT_ADMIN_POWER]
      : globalPowers;
    send(s, 'powers', powersArr);
    // ▲ إضافة: بث كائن الصلاحية المحسوبة الخاص بكل عضو أيضاً (وليس فقط
    //   القائمة الخام)، حتى تنعكس الأزرار/الصلاحيات الفعلية في واجهته فوراً
    //   دون انتظار أي حدث آخر (مثل تبديل الغرفة الذي كان يُعيد حسابها).
    const memberRoom = memberUser.roomid ? rooms.get(memberUser.roomid) : null;
    send(s, 'power', buildPower(memberUser, memberRoom));
  });
}

/** بث لجميع المتصلين */
function toAll(cmd, data) {
  io.emit('msg', { cmd: decodeCmd(cmd), data });
}

// ▲ إضافة: مصدر موحَّد لحالة أيقونة الحضور (.ustat في appraad2.js — راجع
//   تعليق pub() أعلاه). تُستخدَم من pub() نفسها (اللقطة الكاملة) ومن
//   refreshUserStat() أدناه (تحديثات u^ الجزئية عند تغيّر النشاط/الاتصال).
//   الأولوية: قطع الاتصال > قفل الخاص > الخمول > نشط.
function computeStat(user) {
  if (user._discGrace) return 3;                              // بانتظار إعادة الاتصال
  if (user.nopm)        return 2;                              // قفل الخاص
  if (Date.now() - (user.last || 0) >= IDLE_MS) return 1;      // خامل
  return 0;                                                    // نشط
}

/** يعيد حساب stat الحالي، ويبثّه عبر u^ (نفس حدث appraad2.js الموجود) فقط
 *  إذا تغيّر فعلياً عن آخر قيمة بُثَّت — لتفادي بث متكرر بلا فائدة. */
function refreshUserStat(user) {
  const next = computeStat(user);
  if (next === user._stat) return;
  user._stat = next;
  if (user.roomid) toRoom(user.roomid, 'u^', { id: user.id, stat: next });
}

/** إيجاد مستخدم بـ id */
function byUID(uid) {
  for (const u of users.values()) if (u.id === uid) return u;
  return null;
}

/** إيجاد مستخدم بـ lid */
function byLID(lid) {
  for (const u of users.values()) if (u.lid === lid) return u;
  return null;
}

/** حظر عام على مستوى الموقع بالكامل (وليس غرفة واحدة) */
// ▲ إصلاح معماري جوهري: كان الحظر مُخزَّناً في room.bans (خاصية على كل
//   غرفة على حدة)، فيستطيع العضو المحظور من غرفة أن يدخل بقية الغرف دون
//   أي عائق — يتناقض هذا كلياً مع الوصف الصريح للميزة ("حظر من دخول
//   الشات" أي الموقع كاملاً وليس غرفة بعينها). الحظر الآن قائمة واحدة
//   عامة على مستوى الموقع بأكمله.
const globalBans = [];

/** هل المستخدم محظور؟ ترجع القيد المطابق نفسه (وليس true/false فقط) حتى
 *  يتمكن المستدعي من عرض الوقت المتبقي (expires) في رسالة الرفض. */
// ▲ إصلاح: أُضيف دعم الحظر بالبصمة (fp) بمستويات "عمق" مختلفة، مطابقةً لقوائم
//   appraad2.js (حظر / حظر عميق 1-4) القادمة عبر cp_fps و uh (كشف النكات).
//   كلما زاد العمق (depth) قصرت البادئة المطلوب تطابقها من الـ fp → حظر أوسع
//   يشمل بصمات أكثر تشابهاً جزئياً (نفس الجهاز/الشبكة تقريباً).
// ▲ إضافة: دعم انتهاء الصلاحية التلقائي (expires) — الحظر المؤقت (20 دقيقة،
//   من زر "حظر" في نافذة الملف الشخصي upro) يُصبح غير فعّال تلقائياً بعد
//   انقضاء مدته، مع تنظيف ذاتي كسول (active=false) بمجرد اكتشاف الانتهاء
//   عند أي تحقق لاحق — فيختفي تلقائياً من قائمة الحظر بلوحة التحكم أيضاً.
const BAN_DEPTH_PREFIX_LEN = [Infinity, 24, 16, 10, 6]; // [0]=مطابقة كاملة
function isBanned(user) {
  for (const b of globalBans) {
    if (!b.active) continue;
    if (b.expires && Date.now() > b.expires) { b.active = false; continue; }
    let matched = false;
    if (b.lid && b.lid === user.lid) matched = true;
    else if (b.ip && b.ip === user._ip) matched = true;
    // ▲ إصلاح: أُعيدت تسمية حقل الدولة الداخلي إلى "country" (بدل "co")
    //   لتفادي تعارض مع حقل "co" الذي يقرأه appraad2.js فعلياً لعمود
    //   "الحالات" (عدد مرات تفعيل الحظر) في جدول cp_bans — تسمية مختلفة
    //   تماماً استخدمها المطوّر الأصلي لغرض آخر بالمصادفة.
    else if (b.country && b.country === user.co && user.co !== '--') matched = true;
    else if (b.fp) {
      const depth = Math.min(b.depth || 0, BAN_DEPTH_PREFIX_LEN.length - 1);
      const len   = BAN_DEPTH_PREFIX_LEN[depth];
      const bfp   = len === Infinity ? b.fp     : b.fp.slice(0, len);
      const ufp   = len === Infinity ? user._fp : (user._fp || '').slice(0, len);
      if (bfp && ufp && bfp === ufp) matched = true;
    }
    if (matched) {
      // ▲ إضافة: تتبع فعلي لعدد مرات تفعيل الحظر ووقت آخر مرة (عمودا
      //   "الحالات"/"آخر حالة" في جدول لوحة التحكم — كانا يعرضان قيماً
      //   ثابتة دائماً من قبل).
      b.count = (b.count || 0) + 1;
      b.last  = Date.now();
      return b;
    }
  }
  return null;
}

/** نص عربي لطيف يصف المدة المتبقية لحظر مؤقت */
function remainingTimeText(expires) {
  const ms = expires - Date.now();
  if (ms <= 0) return '';
  const mins = Math.ceil(ms / 60000);
  return mins <= 1 ? 'دقيقة واحدة' : `${mins} دقيقة`;
}

/** تحويل قائمة الحظر الداخلية لتنسيق السلك الذي يقرأه appraad2.js فعلياً
 *  في جدول "الحظر" بلوحة التحكم: user, type, date, co, lc (تحققتُ من هذه
 *  الأسماء حرفياً من appraad2.js — لا علاقة لها بأسماء الحقول الداخلية) */
function buildBanList() {
  return globalBans.filter(b => b.active).map(b => ({
    id:   b.id || b.type || b.ip || b.country || b.fp,
    user: b.name || b.lid || b.ip || b.country || (b.fp ? `بصمة: ${b.fp}` : ''),
    type: b.type || b.ip || b.country || b.fp || '',
    date: b.expires ? remainingTimeText(b.expires) || 'منتهي' : 'دائم',
    co:   b.count || 0,
    lc:   b.last ? new Date(b.last).toLocaleString('ar') : ''
  }));
}

/** هل مشرف؟ — عبر صلاحية owner المُستخرجة بالاسم (buildPower)، بدون أي تحقق بالرنك */
function isAdmin(user, room = null) {
  if (buildPower(user, room).owner) return true;
  if (room && room.ops.includes(user.lid)) return true;
  return false;
}

/** هل مشرف أو مود؟ */
function isMod(user, room = null) {
  if (isAdmin(user, room)) return true;
  // ▲ إصلاح: كانت تشترط room (نفس علة buildPower أعلاه) فتفقد أي عضو صفة
  //   "مود" بمجرد خروجه من أي غرفة رغم امتلاكه صلاحية مسماة فعلية.
  if (user.power && globalPowers.some(p => p.name === user.power)) return true;
  return false;
}

// ▲ إضافة: فرض تسلسل الرتب على كل إجراء إداري بين عضوين (طرد/حظر/حذف
//   عضوية/تعديل بيانات/تغيير صلاحية) — لم يكن هذا التحقق موجوداً إطلاقاً،
//   فكان أي عضو له أي صلاحية إدارية (adminOk) يستطيع اتخاذ إجراء على عضو
//   آخر بصرف النظر عن رتبته، حتى لو كانت رتبة الهدف أعلى أو مساوية له.
//   القاعدة: يُمنع الإجراء إذا كانت رتبة الهدف >= رتبة الفاعل، إلا إذا كان
//   الفاعل مالكاً حقيقياً للموقع (buildPower(...).owner)، فهو يتجاوز الرتب.
function canActOnRank(actor, target, room = null) {
  if (!target) return true;               // لا يوجد هدف فعلي (مثلاً حظر بصمة بلا حساب متصل)
  if (buildPower(actor, room).owner) return true;
  const actorRank  = actor.rank  || 0;
  const targetRank = target.rank || 0;
  return actorRank > targetRank;
}

/** رتبة اسم صلاحية مُعيَّن من globalPowers (0 إذا كان الاسم فارغاً أو غير موجود) */
function rankOfPowerName(name) {
  if (!name) return 0;
  const def = globalPowers.find(p => p.name === name);
  return (def && typeof def.rank === 'number') ? def.rank : 0;
}

/** هل لدى المستخدم صلاحية محددة في power definition؟ — بالكامل عبر buildPower (بدون رنك) */
function hasPower(user, room, perm) {
  return !!buildPower(user, room)[perm];
}

/**
 * بناء payload الصلاحيات لمستخدم
 * appraad.js يقرأ: power.mic, power.setpower, power.ban,
 *   power.owner, power.cp, power.calls, power.publicmsg,
 *   power.roomowner, power.name, power.rank
 */
function buildPower(user, room) {
  // القيمة الصفرية — عضو عادي بدون أي صلاحية
  const EMPTY = {
    rank: 0, name: '', ico: '',
    kick: 0, delbc: false, alert: false, mynick: false, unick: false,
    ban: false, publicmsg: false, ppmsg: false, forcepm: false,
    roomowner: false, createroom: false, rooms: 0,
    edituser: false, setpower: false, upgrades: false, history: false,
    cp: false, rjoin: false, stealth: false, setLikes: false,
    dmsg: false, rinvite: false, mic: false, cmic: false, owner: false
  };

  // ▲ إصلاح جوهري: كان الشرط (room && user.power) يمنع العثور على تعريف
  //   صلاحية العضو كلياً بمجرد عدم وجوده داخل أي غرفة (مثلاً بعد 'rleave')
  //   رغم أن globalPowers قائمة عامة على مستوى الموقع لا علاقة لها بغرفة
  //   معينة إطلاقاً! النتيجة: أي عضو يخرج من الغرفة تنهار كل صلاحياته فوراً
  //   (upgrades, mic, cmic, setLikes, ban, kick, dmsg...) وتتعطل كل الأوامر
  //   المبنية عليها (إعلانات pmsg/ppmsg, تنبيه not, إلخ) — البحث عن الصلاحية
  //   يجب أن يعتمد على user.power فقط. أما "مالك الغرفة" (roomowner/owner
  //   عبر room.owner) فهذا وحده يبقى مرتبطاً بوجود غرفة فعلياً (منطقي).
  const def = user.power
    ? globalPowers.find(p => p.name === user.power)
    : null;

  if (!def) {
    // مالك الغرفة بدون صلاحية مسماة
    if (room && room.owner === user.lid) {
      return { ...EMPTY, name: user.power || '', rank: user.rank || 0, roomowner: true, owner: true };
    }
    return { ...EMPTY, name: user.power || '', rank: user.rank || 0 };
  }

  // أعد الكائن الكامل مع ضمان أن جميع الحقول موجودة
  return {
    rank:       typeof def.rank       === 'number'  ? def.rank       : 0,
    name:       def.name       ?? '',
    ico:        def.ico        ?? '',
    kick:       typeof def.kick       === 'number'  ? def.kick       : 0,
    delbc:      !!def.delbc,
    alert:      !!def.alert,
    mynick:     !!def.mynick,
    unick:      !!def.unick,
    ban:        !!def.ban,
    publicmsg:  !!def.publicmsg,
    ppmsg:      !!def.ppmsg,
    forcepm:    !!def.forcepm,
    roomowner:  !!(def.roomowner || (room && room.owner === user.lid)),
    createroom: !!def.createroom,
    rooms:      typeof def.rooms      === 'number'  ? def.rooms      : 0,
    edituser:   !!def.edituser,
    setpower:   !!def.setpower,
    upgrades:   !!def.upgrades,
    history:    !!def.history,
    cp:         !!def.cp,
    rjoin:      !!def.rjoin,
    stealth:    !!def.stealth,
    setLikes:   !!def.setLikes,
    dmsg:       !!def.dmsg,
    rinvite:    !!def.rinvite,
    mic:        !!def.mic,
    cmic:       !!def.cmic,
    owner:      !!def.owner
  };
}

// ────────────────────────────────────────────────────────────────────────────
// ▲ إضافة: حساب/مزامنة الأيقونة المعروضة بجانب اسم المستخدم (user.ico)
//
// appraad2.js (لا يجوز تعديله) يحسب الأيقونة بدالته الداخلية بهذا الترتيب
// بالضبط (تم تتبعه من الكود المُبهم حرفياً):
//   1) user.b غير فارغ            → "sico/" + user.b            (أعلى أولوية)
//   2) رتبة user.power لها ico    → "sico/" + رتبة.ico           (تُحسب حياً)
//   3) غير ذلك: user.ico كما هو   → "dro3/" + user.ico (بعد إزالة أي "dro3/" سابقة)
// المشكلة: هذا الحساب الذكي (٣ خطوات) يحدث فقط في بعض أماكن العرض؛ أماكن
// أخرى (~15 موضع رصدتها في u-ico) تقرأ user.ico مباشرة بلا أي حساب رتبة —
// فتظهر الأيقونة فارغة لأي عضو صاحب رتبة لم يُحفظ له ico مطابق يدوياً.
// الحل هنا لا يلمس appraad2.js إطلاقاً: بدلاً من ذلك، نُخزّن في user.ico
// نفسه المسار الكامل الجاهز (بادئة sico/ أو dro3/ مطابقة تماماً لما تحسبه
// الدالة الذكية) — فتتطابق كل الأماكن تلقائياً سواء استخدمت الحساب الذكي أو
// قرأت user.ico مباشرة، دون أي تعديل على appraad2.js.
//
// الأولوية هنا: صلاحية المستخدم (رتبته) > هدية مُهداة له (giftIco) > فارغ.
// أي عضو يملك أي صلاحية من قائمة الصلاحيات لا يجوز إهداؤه أصلاً (يُطبَّق في
// case 'gift' أدناه)، فلا تعارض بين الحالتين، لكن العضو الذي يملك هدية ثم
// يُرقَّى لاحقاً لرتبة: تظهر أيقونة رتبته (وتُخفى الهدية تلقائياً دون حذفها)،
// وإن أُزيلت رتبته لاحقاً تظهر هديته المحفوظة تلقائياً من جديد.
// ────────────────────────────────────────────────────────────────────────────
function computeUserIco(user) {
  const def = user.power ? globalPowers.find(p => p.name === user.power) : null;
  if (def && def.ico) return 'sico/' + def.ico;
  if (user.giftIco) return 'dro3/' + user.giftIco;
  return '';
}

function syncIco(user) {
  const wanted = computeUserIco(user);
  if ((user.ico || '') === wanted) return false;
  user.ico = wanted;
  saveAccount(user, { ico: user.ico, giftIco: user.giftIco || '' });
  if (user.roomid) toRoom(user.roomid, 'u^', user.pub());
  // ▲ إصلاح: recentLogins (تُغذّي قائمة "المتواجدين في الدردشة" 'online')
  //   تُخزّن نسخة (snapshot) من pub() وقت الدخول فقط، ولا تتحدّث تلقائياً
  //   بعدها أبداً — فتبقى الأيقونة القديمة (أو الفارغة) ظاهرة في هذه
  //   القائمة تحديداً حتى لو تغيّرت رتبة/هدية العضو لاحقاً وتحدّثت بكل مكان
  //   آخر بشكل صحيح. نحدّث نفس النسخة المخزّنة هنا مباشرة لتبقى متطابقة.
  const idx = recentLogins.findIndex(u => u.id === user.id);
  if (idx !== -1) recentLogins[idx] = user.pub();
  return true;
}

/** نفس منطق computeUserIco لكن لحساب/تحديث حساب غير متصل حالياً (acc خام) */
function syncIcoOffline(acc) {
  const def = acc.power ? globalPowers.find(p => p.name === acc.power) : null;
  const wanted = (def && def.ico) ? ('sico/' + def.ico) : (acc.giftIco ? ('dro3/' + acc.giftIco) : '');
  acc.ico = wanted;
}

// ▲ إصلاح جذري وشامل: appraad2.js يقرر إظهار/إخفاء أزرار اللايك/الرد اعتماداً
//   حصرياً على آخر حدث 'settings' وصله (لا علاقة له بأي تحديث لاحق بعده) —
//   وكان هناك أكثر من نقطة بث settings بالسيرفر، بعضها يرسل من room.settings
//   (قد يتأخر تزامنه مع الإعداد الحقيقي لحظياً حسب ترتيب الأحداث) وبعضها
//   كان يرسل قيماً ثابتة يدوياً بالكامل (السبب الجذري المُصلَح قبل قليل).
//   بدل الاعتماد على تزامن room.settings الصحيح في كل نقطة بث على حدة، هذه
//   الدالة تفرض القيم الحقيقية الحالية من global.siteSettings مباشرة —
//   المصدر الوحيد الذي يكتبه sitesave فعلياً — فوق أي إعداد غرفة، في كل بث
//   settings بلا استثناء. يقضي هذا نهائياً على أي احتمال تعارض/تأخر مستقبلي.
const SHARED_TOGGLE_KEYS = ['bclikes', 'mlikes', 'mreply', 'bcreply', 'calls', 'mic'];
function liveSettings(base) {
  const gs = global.siteSettings || {};
  const merged = Object.assign({}, base || {});
  for (const k of SHARED_TOGGLE_KEYS) {
    if (gs[k] !== undefined) merged[k] = !!gs[k];
  }
  return merged;
}

// ▲ إضافة: دالة إشعار موحّدة — تحترم تعطيل التنبيهات (nonot) لدى المستلم،
//   مع استثناء صريح لمن يملك صلاحية "alert" ("التنبيهات" بمحرر الرتب) —
//   طلب صريح بالبند الثاني عشر. تُستخدم من كل نقاط إرسال 'not' بدل تكرار
//   نفس منطق الفحص/البحث عن socket المستلم بكل حالة على حدة.
// ▲ إضافة: تُرجِع Boolean (وصلت أم حُجبت) — لا تُرسل رسالة "هذا المستخدم
//   عطّل التنبيهات" للمُرسِل تلقائياً من هنا (لأن 4 من نقاط الاستدعاء الـ6
//   إشعارات جانبية تلقائية لإعجاب/رد، لا محاولة إرسال تنبيه متعمَّدة — إخبار
//   المُعجِب أن صاحب المنشور "عطّل التنبيهات" كل مرة يضغط فيها لايك إزعاج لا
//   داعي له). القرار متروك للمُستدعي عبر القيمة المُرجَعة؛ نقطتا زر "تنبيه"
//   (.unot) تحديداً تستخدمانها لتطبيق نص الطلب الصريح بالبند 12.
function notifyUser(fromUser, toUser, msg, extra = {}) {
  if (!toUser) return false;
  if (toUser.nonot && !hasPower(fromUser, null, 'alert')) return false;
  const ts = io.sockets.sockets.get(toUser.socketId);
  if (!ts) return false;
  send(ts, 'not', Object.assign({
    user: fromUser.id, uid: fromUser.id, topic: fromUser.topic, pic: fromUser.pic, t: Date.now()
  }, { msg }, extra));
  return true;
}

// ▲ إصلاح (كشف بصمة الجهاز يعرض JSON خام): كان يُخزَّن navigator.n الخام
//   كنص JSON مباشرة فيظهر للمشرف حرفياً {"a":"...","pri":...} بدل بصمة
//   مختصرة مقروءة. الدالة هنا حتمية بالكامل (نفس الجهاز ⇐ نفس الناتج دائماً،
//   ضروري لبقاء صحة المطابقة بالحظر بالبصمة كما هي) بلا أي مكتبة خارجية:
//   نظام التشغيل من الـUser-Agent (مصدر أوثق من محاولة تخمينه من fp نفسها)،
//   ثم عدة أجزاء قصيرة (هاش بسيط) من مجموعات مختلفة من بيانات الجهاز
//   (الشاشة/المنطقة الزمنية/الإضافات..)، بنفس شكل المثال المطلوب.
function simpleHash(v) {
  const str = String(v ?? '');
  let hash = 0;
  for (let i = 0; i < str.length; i++) { hash = ((hash << 5) - hash + str.charCodeAt(i)) | 0; }
  return Math.abs(hash).toString(36).padStart(3, '0').slice(0, 4);
}
function shortFingerprint(fp, userAgent) {
  fp = fp || {};
  const ua = userAgent || '';
  const os = /android/i.test(ua) ? 'Android'
    : /iphone|ipad|ipod/i.test(ua) ? 'iOS'
    : /windows/i.test(ua) ? 'Windows'
    : /mac os/i.test(ua) ? 'Mac'
    : /linux/i.test(ua) ? 'Linux'
    : 'Unknown';
  const scr = fp.screen || {};
  const parts = [
    simpleHash(fp.devicePixelRatio),
    simpleHash(scr.width) + simpleHash(scr.height) + '.' + simpleHash(scr.colorDepth) + '.' + simpleHash(scr.pixelDepth),
    simpleHash(fp.tz) + '.' + simpleHash(fp.pri),
    simpleHash((fp.pl || []).join(',')) + '.' + simpleHash((fp.mt || []).join(',')),
    simpleHash(fp.mdl) + '.' + simpleHash((fp.prl || []).join(',')),
  ];
  return `${os} | ${parts.join(' | ')}`;
}

/** بناء رسالة موحدة */
function buildMsg(sender, text, extra = {}) {
  return Object.assign({
    uid:   sender.id,
    lid:   sender.lid,
    pic:   sender.pic,
    ico:   sender.ico   || '',
    ucol:  sender.ucol  || '',
    mcol:  sender.mcol  || '',
    topic: sender.topic,
    t:     Date.now(),
    msg:   sanitize(text || '')
  }, extra);
}

/** بناء رسالة نظام (بدون تهريب HTML — للرسائل المولودة من السيرفر فقط) */
function buildSysMsg(sender, htmlText, extra = {}) {
  return Object.assign({
    uid:   sender.id,
    lid:   sender.lid,
    pic:   sender.pic,
    ico:   '',
    ucol:  sender.ucol  || '',
    // ▲ إصلاح: كانت مُجمَّدة على '' دائماً، بعكس ucol بنفس الدالة تماماً
    //   وبعكس buildMsg (تُطبَّق فعلياً على .u-msg نفسها في appraad2.js —
    //   السطر ~3673 — وهي عنصر "محتوى" الرسالة الفعلي). كل رسائل النظام
    //   (دخول الغرفة/مغادرتها/طرد/حظر/نقل/خروج/قطع اتصال) تمر من هنا فقط
    //   (بحث hmsg الشامل بكل الملف يثبت ذلك)، فكانت جميعها تفقد لون محتواها
    //   بينما اسم/خلفية العضو (ucol/الخلفية اللونية) يعملان بشكل صحيح.
    mcol:  sender.mcol  || '',
    topic: sender.topic,
    t:     Date.now(),
    msg:   htmlText
  }, extra);
}

/**
 * قائمة غرفة مُشكَّلة لـ rlist / r+ / r^
 * appraad.js يقرأ:
 *   roomPayloadObj.id, .name, .topic, .pic, .needpass
 *   .about, .c, .v (mic enabled), .max, .uco, .online
 *   .m (mic array) — في r^ فقط
 *   .ops — في r^ فقط
 */
function roomListItem(room) {
  return {
    id:       room.id,
    name:     room.name,
    topic:    room.name,           // appraad.js يقرأ .topic للغرفة
    pic:      room.pic,
    needpass: room.needpass,
    about:    room.about   || '',
    welcome:  room.welcome || '',  // appraad.js redit() يقرأها من rcach[id].welcome
    c:        room.c       || '#000000',
    v:        !!(room.settings?.mic),  // appraad.js: destRoomObj.v == true → إظهار #mic
    max:      room.max     || 20,
    l:        room.l       || 0,   // appraad.js redit() يقرأها من rcach[id].l
    vl:       room.vl      || 0,   // appraad.js redit() يقرأها من rcach[id].vl
    online:   room.members.size,
    uco:      room.members.size        // appraad.js: roomPayloadObj.uco
  };
}

/** إضافة مستخدم لقائمة recentLogins وإبلاغ الجميع */
function addRecentLogin(user) {
  // أزل النسخة القديمة إن وجدت
  const idx = recentLogins.findIndex(u => u.id === user.id);
  if (idx !== -1) recentLogins.splice(idx, 1);
  recentLogins.push(user.pub());
  if (recentLogins.length > MAX_RECENT) recentLogins.shift();
  toAll('online+', user.pub());
}

/** إزالة مستخدم من recentLogins وإبلاغ الجميع */
function removeRecentLogin(userId) {
  const idx = recentLogins.findIndex(u => u.id === userId);
  if (idx !== -1) recentLogins.splice(idx, 1);
  toAll('online-', userId);
}

/** تحديث الغرفة لجميع المتصلين (r^) */
function broadcastRoomUpdate(room) {
  const payload = Object.assign(roomListItem(room), {
    m:   room.mic,    // appraad.js case 'r^': commandPayload.m → تحديث مصفوفة المايك
    ops: room.ops
  });
  toAll('r^', payload);
}

/** قائمة المشرفين المتصلين في الغرفة */
function buildRops(room) {
  return room.ops
    .map(lid => {
      for (const u of room.members.values()) {
        // ▲ إصلاح: كان يُرسل الحقل باسم "name"، بينما يقرأ appraad2.js
        //   حرفياً ".topic" عند بناء قائمة المشرفين في نافذة إعدادات الغرفة
        //   (راجع: uhead.find(".u-topic").html(entry.topic))، فكان الاسم
        //   يظهر فارغاً دائماً رغم ظهور الصورة بشكل صحيح (pic كانت مطابقة).
        if (u.lid === lid) return { id: u.id, lid: u.lid, topic: u.topic, pic: u.pic };
      }
      return null;
    })
    .filter(Boolean);
}

/** بناء قائمة المحظورين من غرفة معينة (حظر مؤقت ٢٠ دقيقة عبر roomkick) —
 *  بنفس تنسيق buildRops بالضبط (id/lid/topic/pic) زائداً until (وقت
 *  انتهاء الحظر)، تمهيداً لعرضها بنفس طريقة قائمة المشرفين تماماً. تُنظَّف
 *  الحظورات المنتهية تلقائياً هنا (تنظيف كسول). يبحث في الحسابات المسجّلة
 *  أيضاً (وليس المتصلين فقط) لأن الحظر المؤقت غالباً يستمر بعد خروج الشخص. */
function buildRoomBans(room) {
  const now = Date.now();
  for (const [lid, rb] of room.roomBans) {
    if (rb.until <= now) room.roomBans.delete(lid);
  }
  return [...room.roomBans.entries()].map(([lid, rb]) => {
    let topic = lid, pic = 'pic.png';
    const live = [...room.members.values()].find(u => u.lid === lid) || [...users.values()].find(u => u.lid === lid);
    if (live) { topic = live.topic; pic = live.pic; }
    else {
      for (const [, acc] of accounts) {
        if (acc.lid === lid) { topic = acc.topic || acc.name || lid; pic = acc.pic || 'pic.png'; break; }
      }
    }
    return { id: lid, lid, topic, pic, until: rb.until };
  });
}

/** حفظ بيانات في حساب العضو */
function saveAccount(user, fields) {
  let saved = false;
  for (const [, acc] of accounts) {
    if (acc.lid === user.lid) {
      Object.assign(acc, fields);
      saved = true;
    }
  }
  if (saved) {
    writeJsonFile(ACCOUNTS_FILE, Array.from(accounts.values()));
  }
}

// ─── إنشاء غرف افتراضية ───────────────────────────────────────────────────────
// نفس الحقول التي يستخدمها أمر إنشاء الغرفة 'r+' (topic/pass/pic/about/welcome/max/c)
function seedRooms() {
  const savedAssets = loadRoomAssets();
  [
    {
      id:      'main',
      name:    '( 1 ) الغرفة الرئيسية',
      pass:    '',
      pic:     'room.png',
      bg:      '',           // خلفية الغرفة (URL أو لون)
      c:       '#000000',    // لون النص
      max:     30,           // أقصى عدد أعضاء
      l:       0,            // أقل رتبة للدخول (appraad: .rl)
      vl:      0,            // أقل رتبة VIP للدخول (appraad: .rvl)
      about:   'الغرفة الرئيسية للموقع — مرحباً بجميع الأعضاء والزوار',
      welcome: 'أهلاً وسهلاً بك في الغرفة الرئيسية 🌹',
      settings: {
        mic: true, setpower: true, ban: true, owner: true,
        calls: true, mlikes: true, bclikes: true, mreply: true, bcreply: true
      }
    },
    {
      id:      'games',
      name:    '( 2 ) العاب',
      pass:    '',
      pic:     'room.png',
      bg:      '',
      c:       '#000000',
      max:     20,
      l:       0,
      vl:      0,
      about:   'غرفة مخصصة لمحبي الألعاب والتسلية',
      welcome: 'أهلاً بك في غرفة الألعاب 🎮',
      settings: {
        mic: true, setpower: true, ban: true, owner: true,
        calls: true, mlikes: true, bclikes: true, mreply: true, bcreply: true
      }
    },
    {
      id:      'music',
      name:    '( 3 ) موسيقى',
      pass:    '',
      pic:     'room.png',
      bg:      '',
      c:       '#000000',
      max:     20,
      l:       0,
      vl:      0,
      about:   'غرفة مخصصة لعشاق الموسيقى والطرب',
      welcome: 'أهلاً بك في غرفة الموسيقى 🎵',
      settings: {
        mic: true, setpower: true, ban: true, owner: true,
        calls: true, mlikes: true, bclikes: true, mreply: true, bcreply: true
      }
    }
  ].forEach(d => {
    const r      = new Room(d.id, d.name, d.pass || '');
    r.pic        = d.pic            || 'room.png';
    r.bg         = d.bg             || '';
    r.c          = d.c              || '#000000';
    r.max        = parseInt(d.max)  || 20;
    r.l          = d.l              || 0;
    r.vl         = d.vl             || 0;
    r.about      = sanitize(d.about   || '', 300);
    r.welcome    = sanitize(d.welcome || '', 300);
    r.settings   = Object.assign(r.settings, d.settings || {});
    const savedRoom = savedAssets[r.id] || {};
    r.sicos      = Array.isArray(savedRoom.sicos) ? savedRoom.sicos : [];
    r.colors     = Array.isArray(savedRoom.colors) ? savedRoom.colors : [];
    r.emos       = Array.isArray(savedRoom.emos) ? savedRoom.emos : [];
    // powers تبقى كما أنشأها Room constructor (DEFAULT_ADMIN_POWER)
    rooms.set(r.id, r);
  });
  console.log('[Server] الغرف جاهزة:', [...rooms.keys()].join(', '));
}

// ─── إنشاء حساب الأدمن الافتراضي ─────────────────────────────────────────────
function seedAdmin() {
  const adminName = process.env.ADMIN_NAME || 'admin';
  const adminPass = process.env.ADMIN_PASS || 'admin123';
  const nameKey   = adminName.toLowerCase();

  // إعادة البناء دائماً — يحافظ على lid إذا كان الحساب موجوداً
  const existing  = accounts.get(nameKey);
  const lid       = existing?.lid || genId();

  accounts.set(nameKey, {
    lid,
    name:    adminName,
    pass:    bcrypt.hashSync(adminPass, SALT_ROUNDS),
    // الصلاحية الفعلية (cp/ban/owner/...) تُستخرَج بالاسم عبر buildPower وليس بالرنك
    power:   'adminster',
    // rank يُستخدم الآن فقط لاستثناء البوتات (يطابق شرط appraad2.js: rank > 0x2326 && owner)
    rank:    9999,
    pic:     existing?.pic  || 'pic.png',
    ico:     existing?.ico  || '',
    rep:     existing?.rep  || 0,
    co:      existing?.co   || '--',
    bg:      existing?.bg   || '',
    ucol:    existing?.ucol || '',
    mcol:    existing?.mcol || '',
    msg:     existing?.msg  || '(صاحب الموقع)',
    b:       existing?.b    || '',
    created: existing?.created || Date.now(),
    last:    Date.now()
  });

  console.log('');
  console.log('  ╔══════════════════════════════════════╗');
  console.log('  ║       حساب الأدمن الافتراضي          ║');
  console.log(`  ║  اسم المستخدم : ${adminName.padEnd(20)}║`);
  console.log(`  ║  كلمة المرور  : ${adminPass.padEnd(20)}║`);
  console.log('  ║  الرتبة       : 9999 (الادارة)       ║');
  console.log('  ║  غيّر كلمة المرور فور تسجيل الدخول  ║');
  console.log('  ╚══════════════════════════════════════╝');
  console.log('');
}

// ─── الانضمام لغرفة ───────────────────────────────────────────────────────────
// ▲ إصلاح: appraad2.js لا يملك أي حالة (case) لـ login.msg بقيمة
//   'needpass' أو 'wrong' أو 'banned' داخل مُستقبِل تسجيل الدخول
//   (الحالات المدعومة فقط: ok, noname, badname, usedname, badpass, wrong, reg)
//   — تحديداً 'needpass' و'banned' غير مدعومتين إطلاقاً، فكان رفض الانضمام
//   لغرفة محمية بكلمة مرور أو محظور منها لا يُظهر للعضو أي رسالة على الإطلاق.
//   الحل: استخراج التحقق في دالة منفصلة (checkJoinable) تُستخدم *قبل*
//   مغادرة الغرفة الحالية (في حالة 'rjoin')، مع إرسال إشعار 'not' (الذي
//   يفهمه العميل فعلياً) بدل الاعتماد فقط على 'login' غير المفهومة هنا.
function checkJoinable(room, user, pwd = '', force = false) {
  if (force) return { ok: true };
  if (room.needpass && room.pass) {
    if (!pwd) return { ok: false, reason: 'needpass', msg: 'هذه الغرفة تتطلب كلمة مرور' };
    if (!bcrypt.compareSync(pwd, room.pass)) {
      return { ok: false, reason: 'wrong', msg: 'كلمة المرور غير صحيحة' };
    }
  }
  // ▲ إصلاح: الحظر أصبح عالمياً (globalBans، راجع isBanned أعلاه) بدل حظر
  //   مقتصر على غرفة واحدة، مع رسالة تتضمن الوقت المتبقي للحظورات المؤقتة.
  const ban = isBanned(user);
  if (ban) {
    const remain = ban.expires ? remainingTimeText(ban.expires) : '';
    return {
      ok: false, reason: 'banned',
      msg: remain ? `أنت محظور، الوقت المتبقي: ${remain}` : 'أنت محظور'
    };
  }
  // ▲ إضافة: حظر مؤقت خاص بغرفة واحدة فقط (٢٠ دقيقة) بعد الطرد منها
  //   تحديداً (roomkick) — منفصل تماماً عن الحظر العام أعلاه، ولا يُضاف
  //   لقائمة الحظر بلوحة التحكم (راجع room.roomBans في case 'roomkick').
  if (!force && room.roomBans && room.roomBans.has(user.lid)) {
    const rb = room.roomBans.get(user.lid);
    if (rb.until > Date.now()) {
      const remain = remainingTimeText(rb.until);
      return { ok: false, reason: 'wrong', msg: `تم طردك من هذه الغرفة، يمكنك العودة بعد: ${remain}` };
    }
    room.roomBans.delete(user.lid); // انتهت المدة — تنظيف ذاتي كسول
  }
  // ▲ إضافة: شرطا l (الحد الأدنى من الإعجابات) وvl (الحد الأدنى من رتبة
  //   الصلاحية VIP) لدخول الغرفة — كانا محفوظين مع بيانات الغرفة (يُضبطان
  //   عبر r+/r^ ويُعرَضان في نافذة تعديل الغرفة بالعميل) لكن غير مُطبَّقين
  //   إطلاقاً عند الانضمام الفعلي. المالك/المشرفون يتجاوزون الشرطين دائماً.
  if (!isAdmin(user, room)) {
    if (room.l  > 0 && (user.rep  || 0) < room.l)  {
      return { ok: false, reason: 'wrong', msg: `تحتاج ${room.l} إعجاب على الأقل لدخول هذه الغرفة` };
    }
    if (room.vl > 0 && (user.rank || 0) < room.vl) {
      return { ok: false, reason: 'wrong', msg: 'هذه الغرفة مخصصة لأعضاء VIP فقط' };
    }
  }
  return { ok: true };
}

// اختيار أول غرفة يمكن للعضو دخولها فعلياً (تُستخدم عند تسجيل الدخول 'g'/'login')
// ▲ إصلاح: الكود القديم كان يختار الغرفة المطلوبة (r) أو أول غرفة بالقائمة
//   دون أي تحقق من كلمة المرور أو الحظر، فيرسل السيرفر 'ok'+'login:msg=ok'
//   (أي "تم الدخول بنجاح") ثم تفشل joinRoom بصمت داخلياً — فيدخل العضو
//   فعلياً لواجهة التطبيق الرئيسية دون أن يكون في أي غرفة إطلاقاً.
function pickJoinableRoom(user, requestedId) {
  // ▲ إصلاح: الحظر أصبح عالمياً (globalBans) وليس مقتصراً على غرفة واحدة —
  //   فحص واحد خارج الحلقة يكفي (نفس النتيجة لكل الغرف).
  if (isBanned(user)) return null;
  const seen = new Set();
  const candidates = [];
  if (requestedId && rooms.has(requestedId)) candidates.push(rooms.get(requestedId));
  candidates.push(...rooms.values());
  for (const r of candidates) {
    if (seen.has(r.id)) continue;
    seen.add(r.id);
    if (r.needpass && r.pass) continue; // لا نملك كلمة مرور لتجربتها تلقائياً
    // ▲ إضافة: تخطّي أي غرفة لدى العضو فيها حظر مؤقت لم تنتهِ مدته (roomkick)
    if (r.roomBans && r.roomBans.has(user.lid) && r.roomBans.get(user.lid).until > Date.now()) continue;
    // ▲ إضافة: تخطّي أي غرفة لا يستوفي العضو شرط l/vl فيها (نفس منطق
    //   checkJoinable)، إلا إذا كان مشرفاً/مالكاً يتجاوز الشرط دائماً.
    if (!isAdmin(user, r)) {
      if (r.l  > 0 && (user.rep  || 0) < r.l)  continue;
      if (r.vl > 0 && (user.rank || 0) < r.vl) continue;
    }
    return r;
  }
  return null;
}

function joinRoom(socket, user, room, pwd = '', force = false) {

  const check = checkJoinable(room, user, pwd, force);
  if (!check.ok) {
    send(socket, 'login', { msg: check.reason });
    send(socket, 'not', { user: 'srv', msg: check.msg });
    return false;
  }

  user.roomid = room.id;
  user.last   = Date.now();
  room.members.set(socket.id, user);

  // ─── ① rc — يُقفل systemCommandQueue في appraad.js ──────────────────────
  send(socket, 'rc', null);

  // ─── ② rcd — يحمل كل البيانات مباشرةً في الـ payload ────────────────────
  //
  // ملاحظة: rlist لا تُضمَّن هنا — العميل يحصل عليها من online/rc2
  // تضمين rlist داخل rcd يُكرّر الغرف في appraad2.js (append بدون clear)
  //
  // الترتيب الصحيح:
  //   ulist  → يملأ allUsersList (مطلوب قبل ur و rops)
  //   ur     → يضبط myroom في appraad.js (مطلوب قبل rops)
  //   mic    → يضبط مصفوفة المايك (بعد ur لأن ur تُفرّغها)
  //   rops   → يحتاج allUsersList[myid].roomid و rcach
  //   power  → الصلاحيات النهائية
  // أدرج DEFAULT_ADMIN_POWER في مصفوفة الصلاحيات لمن صلاحيته الاسمية تطابقها
  // حتى يجدها _0x3e8a07 ويبقى _0x41c3fc.cp=true ولا تُغلق نوافذ CP عبر _0x515435() — بدون أي تحقق بالرنك
  const _joinPowers = user.power === DEFAULT_ADMIN_POWER.name
    ? (globalPowers.some(p => p.name === DEFAULT_ADMIN_POWER.name)
        ? globalPowers : [...globalPowers, DEFAULT_ADMIN_POWER])
    : globalPowers;
  const _powerForUser = buildPower(user, room);
  // ترتيب rcd مهم جداً — ulist يجب أن يأتي قبل powers
  // لأن case "powers" في appraad.js يقرأ _0x123150[myid] الذي تملؤه ulist
  const rcdPayload = [
    ['emos',     room.emos.length ? room.emos : []],
    ['dro3',     room.colors],
    ['sico',     room.sicos],
    ['ulist',    [...users.values()].map(u => u.pub())],  // أولاً: يملأ _0x123150 في appraad.js
    ['powers',   _joinPowers],                            // ثانياً: يقرأ _0x123150[myid].power
    ['settings', room.settings],
    // مسح الحائط القديم قبل تحميل الجديد (ev يُنفَّذ داخل rcd queue)
    ['ev',       { data: '$("#d2bc").empty();try{bcc=0;$("#bwall").text("").parent().css("color","");}catch(e){}' }],
    ['bclist',   globalWall],
    ['ur',       [user.id, room.id]],   // يضبط myroom في appraad.js
    ['mic',      room.mic],             // بعد ur لأن ur تُفرّغ mic=[]
    ['rops',     buildRops(room)],
    ['power',    buildPower(user, room)],
  ];
  send(socket, 'rcd', rcdPayload);

  // ─── ③ إبلاغ جميع المتصلين بالدخول (u+ للقائمة العامة وليس فقط الغرفة) ──
  // ▲ إصلاح جوهري (عدّاد الحضور بالغرفة يتجمد/يتضاعف): appraad2.js يحسب
  //   عدّاد "uco" لكل غرفة تصاعدياً/تنازلياً بنفسه عند كل 'ur' واردة، معتمداً
  //   على roomid *المخزَّن سابقاً* لهذا العضو في ذاكرته المحلية لتحديد الغرفة
  //   القديمة التي يجب خصمها منها. لكن 'u+' يستبدل كامل الكائن المخزَّن لهذا
  //   العضو (بما فيها roomid الجديد أصلاً) — فإذا وصلت u+ *قبل* ur، يقرأ
  //   العميل "الغرفة القديمة" من نفس الكائن الذي استُبدل للتو، فتُصبح مطابقة
  //   للغرفة الجديدة خطأً، فيُصفّر أثر الزيادة على الغرفة الجديدة (+1 ثم -1)
  //   ولا تُخصم الغرفة القديمة الحقيقية إطلاقاً — وهذا يُفسِّر بقاء العدّاد
  //   ثابتاً عند الانتقال، وتضاعفه لاحقاً عند العودة. الحل: إرسال ur أولاً
  //   دائماً (بينما لا يزال roomid القديم الصحيح محفوظاً في ذاكرة العميل)
  //   ثم u+ بعدها لتحديث بقية البيانات (الصورة، التوقيع، الإعجابات...).
  const joinPub = user.pub();
  users.forEach(u => {
    if (u.socketId === socket.id) return;
    const s = io.sockets.sockets.get(u.socketId);
    if (s) { send(s, 'ur', [user.id, room.id]); send(s, 'u+', joinPub); }
  });
  broadcastRoomUpdate(room);

  // ─── ④ رسالة نظام: دخول عضو ───────────────────────────────────────────────
  // ▲ إصلاح: تخطّي الإعلان بالكامل (وكذلك رسالة الترحيب أدناه) لو كان
  //   المستخدم متخفياً (user.s) — دخوله يجب ألا يظهر لأي أحد (ولا حتى له
  //   نفسه كرسالة ترحيب مميزة) طالما وضع التخفي مفعّل.
  if (!user.s) {
    // تُبثّ لأعضاء الغرفة الموجودين باستثناء العضو الداخل نفسه
    // ▲ إصلاح: حُذف حقل mi — appraad2.js يُظهر أزرار اللايك/الرد فقط إذا
    //   وُجد bid أو mi في الرسالة؛ بغيابهما تختفي هذه الأزرار تلقائياً من
    //   تلقاء نفسه (لا حاجة لأي منطق إضافي)، وهو المطلوب لرسائل النظام.
    const joinHtml = `هذا المستخدم قد دخل <div class="fl fa fa-sign-in btn btn-primary dots roomh border corner minix" style="margin-left:-4px;padding:4px;max-width:180px;min-width:60px;" onclick="rjoin('${room.id}')">${room.name}</div>`;
    toRoom(room.id, 'msg', buildSysMsg(user, joinHtml, { 'class': 'hmsg' }), socket.id);

    // رسالة ترحيب اختيارية
    // ▲ إصلاح: حُذف حقلا bid وmi كلاهما — appraad2.js يتحقق من bid أولاً
    //   (يُفعِّل أزرار اللايك/الرد الخاصة بإعدادات الحائط bclikes/bcreply
    //   رغم أن هذه رسالة دردشة عادية وليست منشور حائط)، ثم من mi. إن غاب
    //   الاثنان معاً فقط تختفي أزرار اللايك/الرد/الحذف بالكامل تلقائياً —
    //   وهو المطلوب لرسائل النظام/الترحيب حسب الطلب الصريح.
    if (room.welcome) {
      send(socket, 'msg', buildMsg(
        { id: 'srv', lid: 'srv', pic: 'room.png', ico: '', ucol: '', mcol: '', topic: 'رساله ترحيب' },
        room.welcome,
        {}
      ));
    }

    // ▲ إضافة (البند السابع): مجمع "رسائل الترحيب" العام بلوحة التحكم
    //   (global.siteMessages بـtype:'w'، يُحفَظ فعلاً عبر case 'msgsit' لكن لم
    //   يكن يُرسَل لأي أحد إطلاقاً — بحث كامل لم يجد أي قراءة لـtype==='w' في
    //   كل الملف). منفصل تماماً عن room.welcome أعلاه (حقل غرفة واحد ثابت)؛
    //   هذا مجمع مواقع عام قد يحوي عدة رسائل، فاخترنا واحدة عشوائياً في كل
    //   دخول (لا منطق اختيار محدَّد بالمستند) لتنويع الترحيب. force=true يعني
    //   هذا استدعاء rjoin (تبديل غرفة) لا تسجيل دخول جديد — لا تُرسَل حينها،
    //   طبقاً للطلب الصريح "مرة واحدة فقط عند تسجيل دخول المستخدم".
    if (!force) {
      const welcomePool = (global.siteMessages || []).filter(m => m.type === 'w');
      if (welcomePool.length) {
        const pick = welcomePool[Math.floor(Math.random() * welcomePool.length)];
        send(socket, 'pmsg', {
          uid: 'srv', topic: pick.t || 'رساله ترحيب', pic: 'room.png',
          msg: pick.m, t: Date.now(), bid: makeBid()
        });
      }
    }
  }

  console.log(`[Room] "${user.topic}" → "${room.name}"`);
  return true;
}

// ─── مغادرة الغرفة ────────────────────────────────────────────────────────────
// reason: 'leave' | 'kick' | 'ban' | 'roomkick' | 'logout' | 'disconnect'
function leaveRoom(socket, user, reason = 'leave', targetRoom = null) {
  if (!user.roomid) return;
  const room = rooms.get(user.roomid);
  if (!room) { user.roomid = null; return; }

  // تحرير خانة المايك
  const mi = room.mic.indexOf(user.id);
  if (mi !== -1) {
    room.mic[mi] = 0;
    // إبلاغ أعضاء P2P
    room.mic.forEach(uid => {
      if (typeof uid !== 'string' || uid === user.id) return;
      const peer = byUID(uid);
      if (!peer) return;
      const ps = io.sockets.sockets.get(peer.socketId);
      if (ps) send(ps, 'p2', { t: 'x', id: user.id });
    });
  }

  room.members.delete(socket.id);
  const prevRoomId = user.roomid;
  user.roomid = null;

  // ─── رسالة نظام: سبب المغادرة ──────────────────────────────────────────────
  // ▲ إصلاح: قواعد رسالة النظام (مُحدَّثة بناءً على توضيح صريح):
  //   (١) تُلغى بالكامل لو كان المستخدم متخفياً (user.s) — دخوله/خروجه/
  //       تنقله يجب ألا يظهر لأي أحد إطلاقاً طالما وضع التخفي مفعّل
  //       (يشمل هذا أيضاً رسالة الترحيب في joinRoom أدناه).
  //   (٢) عند المغادرة الكاملة (leave، عبر rleave): تُبث لبقية الغرفة *و*
  //       تُرسل للمغادر نفسه معاً (كلاهما يستقبلانها).
  //   (٣) عند التنقل بين الغرف (move): تُبث لبقية الغرفة القديمة *و* تُرسل
  //       للمنتقل نفسه معاً، وبنفس تنسيق HTML القابل للنقر (رابط الغرفة
  //       الجديدة) المستخدم في رسالة "دخل الغرفة" أدناه في joinRoom — وليس
  //       نصاً عادياً كبقية الحالات.
  const sysTexts = {
    leave:      '( هذا المستخدم غادر الغرفه )',
    kick:       'هذا المستخدم تم طرده',
    ban:        'هذا المستخدم تم حظره',
    roomkick:   'هذا المستخدم تم طرده من الغرفه',
    move:       'هذا المستخدم انتقل إلى غرفة أخرى', // احتياطي إذا تعذّر تمرير targetRoom
    logout:     'هذا المستخدم سجل خروج',
    disconnect: 'هذا المستخدم قطع الاتصال'
  };
  if (!user.s) {
    let sysText;
    if (reason === 'move' && targetRoom) {
      // نفس تنسيق رسالة "دخل الغرفة" في joinRoom (رابط قابل للنقر بنفس الشكل)
      sysText = `هذا المستخدم انتقل إلى <div class="fl fa fa-sign-in btn btn-primary dots roomh border corner minix" style="margin-left:-4px;padding:4px;max-width:180px;min-width:60px;" onclick="rjoin('${targetRoom.id}')">${targetRoom.name}</div>`;
    } else {
      sysText = sysTexts[reason] || sysTexts.leave;
    }
    // ▲ إصلاح: حُذف حقل mi هنا أيضاً لنفس السبب أعلاه (اختفاء تلقائي لأزرار
    //   اللايك/الرد/الحذف من كل رسائل النظام: مغادرة/طرد/حظر/تنقل...).
    const sysMsg = buildSysMsg(user, sysText, { 'class': 'hmsg' });
    // تُبث لبقية أعضاء الغرفة (المستخدم أُزيل من members أعلاه فلن يستقبلها عبر toRoom)
    toRoom(prevRoomId, 'msg', sysMsg);
    // وتُرسل للمغادر/المنتقل نفسه أيضاً (مغادرة كاملة أو تنقل بين الغرف)
    if (reason === 'leave' || reason === 'move') {
      send(socket, 'msg', sysMsg);
    }
  }

  // ─── الإبلاغ بالمغادرة للآخرين (وللمغادر نفسه) ─────────────────────────────
  // appraad.js case 'u-' يحذف المستخدم نهائياً من القائمة العامة (_0x123150/_0x41a1d0)
  // appraad.js case 'ur' ينقص uco للغرفة القديمة ويصفّر roomid — لكنه يتوقف فوراً
  // لو المستخدم محذوف مسبقاً من _0x123150 (أي إذا أُرسلت u- قبلها بالغلط)
  // لذلك: ur يجب أن تُرسل أولاً دائماً، وu- لا تُرسل إلا عند خروج كامل من الموقع
  // (وليس عند مجرد مغادرة/نقل غرفة — حيث يبقى المستخدم متصلاً بالموقع)
  //
  // ▲ إصلاح جوهري: كانت 'ur' الخاصة بالمغادر نفسه (uid==myid) لا تُرسَل له
  //   إطلاقاً (كان يُستثنى صراحة من حلقة البث). لكن appraad2.js (case 'ur')
  //   يشترط بالضبط استقبال هذه الرسالة عن *نفسه* (uid==myid) ليُفرِّغ لون
  //   خلفية #tbox من الرمادي/يُظهره من جديد (راجع الكود حول "_0x48c915 ==
  //   myid" في appraad2.js) — فكان المستخدم المغادر نفسه لا يرى مربع كتابة
  //   الغرفة يتعطل بصرياً (يبقى بلونه الطبيعي رغم عدم قدرته فعلياً على
  //   إرسال رسائل غرفة). الحل: إرسال 'ur' للمغادر نفسه أيضاً كبقية المتصلين.
  const fullyOffline = ['logout', 'disconnect', 'kick', 'ban'].includes(reason);
  const leftId = user.id;
  send(socket, 'ur', [leftId, null]);   // للمغادر نفسه — يُفعِّل تعطيل #tbox بصرياً
  users.forEach(u => {
    if (u.socketId === socket.id) return;
    const s = io.sockets.sockets.get(u.socketId);
    if (!s) return;
    send(s, 'ur', [leftId, null]);     // أولاً: تحديث uco وroomid (يحتاج المستخدم موجود في _0x123150)
    if (fullyOffline) send(s, 'u-', leftId);  // ثانياً: فقط عند خروج فعلي من الموقع
  });
  broadcastRoomUpdate(room);
}

// ─── Socket.IO ────────────────────────────────────────────────────────────────
io.on('connection', socket => {
  const ip   = (socket.handshake.headers['x-forwarded-for'] || '')
                 .split(',')[0].trim() || socket.handshake.address;
  const user = new User(socket.id, { _ip: ip });
  users.set(socket.id, user);

  // الحدث الرئيسي: كل الرسائل تمر هنا
  socket.on('msg', packet => {
    if (!packet || typeof packet.cmd !== 'string') return;
    const cmd  = decodeCmd(packet.cmd);
    const data = packet.data;
    try { dispatch(socket, user, cmd, data); }
    catch (err) { console.error(`[!] "${cmd}":`, err.message); }
  });

  // إعادة الاتصال بالرمز (rc2 يُرسَل مباشرة بدون تشفير)
  // appraad.js: socketClient.emit("rc2", { token: userAuthHash, n: userSessionToken })
  // userAuthHash = commandPayload.ttoken من آخر login ناجح
  socket.on('rc2', ({ token, n } = {}) => {
    let found = null;
    let fromSession = false;

    // ① البحث في المستخدمين المتصلين حالياً
    for (const u of users.values()) {
      if (u.token === token && u.socketId !== socket.id) {
        found = u;
        break;
      }
    }

    // ② إذا لم يُوجَد في المتصلين — ابحث في الجلسات المحفوظة (ما بعد قطع الاتصال)
    if (!found && token && sessions.has(token)) {
      found = sessions.get(token);
      sessions.delete(token); // استُخدمت مرة واحدة فقط
      fromSession = true;
    }

    let savedRoomId = null;

    if (found) {
      savedRoomId = found.roomid;
      const originalSocket = fromSession ? null : io.sockets.sockets.get(found.socketId);

      // ▲ إضافة: عودة من مهلة انتظار قطع الاتصال (stat=3 — راجع
      //   socket.on('disconnect') أعلاه). سوكته القديم ميت فعلياً بالفعل
      //   (لهذا originalSocket سيكون undefined أصلاً)، فلا تُنفَّذ كتلة
      //   "الطرد" التالية. نُلغي مؤقّت الطرد المعلَّق هنا فقط قبل أن يُطرَد
      //   هو نفسه خطأً بعد قليل.
      const wasInGrace = !fromSession && found._discGrace === true;
      if (wasInGrace && found._discTimer) clearTimeout(found._discTimer);

      // ─── إصلاح تكرار المستخدم في users/ulist ──────────────────────────────
      // إذا كان السوكت الأصلي لا يزال متصلاً فعلياً (تبويب/جلسة سابقة لم تُغلق
      // بعد) يجب طرده وحذفه فوراً، وإلا يبقى للمستخدم نفسه مدخلان بنفس id/lid
      // داخل users → يصل ulist للعميل بعنصر مكرر → appraad2.js يتجاهله بصمت
      // عبر _0x133f6d (يحسبه "مُعالَج مسبقاً") فيُدرَج undefined في القائمة
      // ثم ينكسر عند .filter(... _0x4b5d22.dl ...) بخطأ "is undefined"
      if (originalSocket && originalSocket.id !== socket.id) {
        send(originalSocket, 'login', { msg: 'kicked_login' });
        leaveRoom(originalSocket, found, 'kick');
        users.delete(found.socketId);
      } else if (wasInGrace) {
        // ▲ إضافة: لا سوكت حياً لطرده هنا، لكن يجب حذف المدخل القديم اليتيم
        //   من users بعد نسخ بياناته أدناه — وإلا بقي عالقاً للأبد بمعرّف
        //   سوكت ميت (لا شيء آخر في الملف كان يُنظِّفه في هذه الحالة تحديداً).
        users.delete(found.socketId);
      }

      Object.assign(user, {
        id:     found.id,
        lid:    found.lid,
        topic:  found.topic,
        msg:    found.msg   || '',
        pic:    found.pic   || 'pic.png',
        ico:    found.ico   || '',
        co:     found.co    || '--',
        bg:     found.bg    || '',
        ucol:   found.ucol  || '',
        mcol:   found.mcol  || '',
        rep:    found.rep   || 0,
        power:  found.power || '',
        rank:   found.rank  || 0,
        token:  token,
        _fp:    found._fp   || '',
        s:      found.s     || false,
        refr:   found.refr  || '',
        b:      found.b     || '',
        // ▲ إصلاح: nopm/nonot/giftIco لم تكن تُنسَخ هنا إطلاقاً — أي عضو
        //   مفعِّل "قفل الخاص" أو "تعطيل التنبيهات" كان يفقدهما صامتاً عند
        //   أي rc2 (تحديث صفحة/إعادة اتصال)، رغم استعادتهما بشكل صحيح تماماً
        //   عند تسجيل الدخول الكامل (case 'login' أعلاه). يؤثر مباشرة على
        //   دقة stat (قفل الخاص) بعد العودة من مهلة الانتظار الجديدة.
        nopm:    found.nopm    || false,
        nonot:   found.nonot   || false,
        giftIco: found.giftIco || ''
      });
      user.socketId = socket.id;

      // نقل الغرفة دائماً الآن (سواء كان السوكت الأصلي متصلاً وتم طرده أعلاه،
      // أو منقطعاً، أو جلسة محفوظة من sessions)
      if (savedRoomId) {
        const room = rooms.get(savedRoomId);
        if (room) {
          room.members.delete(found.socketId);
          room.members.set(socket.id, user);
          user.roomid = savedRoomId;

          if (wasInGrace) {
            // ▲ إضافة: عودة صامتة من مهلة الانتظار — العضو لم يغادر مرئياً
            //   لأحد أصلاً (لم يُستدعَ leaveRoom إطلاقاً أثناء المهلة، لا
            //   تغيّر بعدّاد الغرفة ولا بقائمة الأعضاء لدى أحد)، فلا داعي
            //   لأي بث ur/u+ كامل هنا كما بالمسار العادي أدناه. المطلوب فقط:
            //   تحديث أيقونة الحضور من stat=3 إلى الحالة الصحيحة الجديدة.
            refreshUserStat(user);
          } else {
            // ▲ إصلاح جوهري: لم يكن يُرسل أي 'ur'/'u+' لبقية المتصلين هنا
            //   إطلاقاً. عند الانقطاع، كانت 'leaveRoom' قد أرسلت بالفعل
            //   'ur:[id,null]' فأنقصت عدّاد هذه الغرفة لدى الجميع (uco--)؛
            //   لكن بما أن appraad2.js لا يقرأ 'online'/'uco' من 'r^' إطلاقاً
            //   (يتجاهله ويُبقي القيمة المخزَّنة محلياً — راجع case 'r^')، فإن
            //   العدّاد لا يعود للزيادة أبداً إلا بحدث 'ur' صريح جديد. وبما
            //   أن إعادة الاتصال (تحديث الصفحة، انقطاع واي‑فاي عابر، تبديل
            //   التطبيق على الجوال) أمر متكرر جداً، كان هذا يُفقد الغرفة عضواً
            //   واحداً من العدّاد المعروض بشكل دائم مع كل إعادة اتصال، رغم أن
            //   العضو لا يزال فعلياً داخلها (room.members الحقيقية صحيحة).
            //   الحل: بث ur ثم u+ لبقية المتصلين تماماً كما في joinRoom.
            const reconPub = user.pub();
            users.forEach(u => {
              if (u.socketId === socket.id) return;
              const s = io.sockets.sockets.get(u.socketId);
              if (s) { send(s, 'ur', [user.id, savedRoomId]); send(s, 'u+', reconPub); }
            });
            broadcastRoomUpdate(room);
          }
        }
      }
    }

    // ─── ① ok و login ────────────────────────────────────────────────────────
    send(socket, 'ok', null);
    send(socket, 'login', {
      msg:    'ok',
      id:     user.id,
      k:      user.token,
      ttoken: user.token,
      r:      user.roomid
    });
    // window.myid مطلوب لكي تعمل نافذة لوحة التحكم (window.opener.myid)
    send(socket, 'ev', { data: 'try{window.myid=myid;}catch(e){}' });

    // ─── ② بيانات الجلسة العامة ──────────────────────────────────────────────
    send(socket, 'server',   { online: io.engine.clientsCount });
    send(socket, 'rlist',    [...rooms.values()].map(roomListItem));
    send(socket, 'emos',     []);
    send(socket, 'dro3',     []);
    send(socket, 'sico',     []);
    const _powersRoom = rooms.get(user.roomid) || [...rooms.values()][0];
    {
      const _bp = globalPowers;
      const _powersForUser = user.power === DEFAULT_ADMIN_POWER.name
        ? (_bp.some(p => p.name === DEFAULT_ADMIN_POWER.name) ? _bp : [..._bp, DEFAULT_ADMIN_POWER])
        : _bp;
      send(socket, 'powers', _powersForUser);
    }
    send(socket, 'settings', liveSettings(_powersRoom?.settings || {
      mlikes: true, bclikes: true, mreply: false, bcreply: false, calls: false
    }));

    // ─── ③ بيانات الغرفة عبر rc / rcd ────────────────────────────────────────
    if (user.roomid) {
      const room = rooms.get(user.roomid);
      if (room) {
        send(socket, 'rc', null);

        const _rcdPowers = user.power === DEFAULT_ADMIN_POWER.name
          ? (globalPowers.some(p => p.name === DEFAULT_ADMIN_POWER.name)
              ? globalPowers
              : [...globalPowers, DEFAULT_ADMIN_POWER])
          : globalPowers;
        const rcdPayload = [
          ['emos',     room.emos.length ? room.emos : []],
          ['dro3',     room.colors],
          ['sico',     room.sicos],
          ['powers',   _rcdPowers],
          ['settings', room.settings],
          ['ev',       { data: '$("#d2bc").empty();try{bcc=0;$("#bwall").text("").parent().css("color","");}catch(e){}' }],
          // ▲ إصلاح: room.wall غير مُستخدَمة أبداً (فارغة دوماً) — منشورات
          //   الحائط الفعلية تُخزَّن في globalWall (حائط عالمي وليس لكل غرفة
          //   على حدة، كما هو موثّق في case 'bc'). كانت هذه السطر تُرسل حائطاً
          //   فارغاً للعضو عند كل إعادة اتصال (rc2) رغم امتلاء الحائط فعلياً.
          ['bclist',   globalWall],
          ['ulist',    [...users.values()].map(u => u.pub())],  // كل المتصلين
          ['ur',       [user.id, room.id]],
          ['mic',      room.mic],
          ['rops',     buildRops(room)],
          ['power',    buildPower(user, room)],
        ];
        send(socket, 'rcd', rcdPayload);

        const rc2Pub = user.pub();
        // ▲ إصلاح: الترتيب هنا كان معكوساً (u+ قبل ur) بخلاف كل نقاط البث
        // الأخرى بالملف — نفس العطل الموثّق مسبقاً (عدّاد الموجودين بالغرفة
        // القديمة يتجمّد لأن appraad2.js يقرأ "الغرفة القديمة" من الكائن الذي
        // استبدلته u+ للتو). صُحِّح للترتيب الصحيح: ur ثم u+.
        users.forEach(u => {
          if (u.socketId === socket.id) return;
          const s = io.sockets.sockets.get(u.socketId);
          if (s) { send(s, 'ur', [user.id, room.id]); send(s, 'u+', rc2Pub); }
        });
        addRecentLogin(user);
        broadcastRoomUpdate(room);
      }
    }
  });

  socket.on('disconnect', () => {
    // ▲ إضافة: مهلة انتظار قبل الطرد الفعلي (طلب صريح: عرض stat=3 أثناء
    //   الانتظار، وعودة صامتة إلى الحالة الصحيحة دون أي مغادرة/انضمام ظاهرة
    //   لبقية الأعضاء إذا عاد الاتصال خلال DISCONNECT_GRACE_MS — راجع case
    //   'rc2' أدناه). لم يكن يوجد أي نظام انتظار لهذا الغرض في الملف: نظام
    //   sessions/SESSION_TTL الحالي (5 دقائق) مخصَّص فقط لاستعادة البروفايل
    //   بعد إزالة العضو فعلياً بالكامل من الغرفة/القائمة، وليس لإبقائه
    //   ظاهراً بالغرفة أثناء الانتظار. الآن: أولاً مهلة قصيرة (تُبقيه حاضراً
    //   بمقعده/غرفته كاملة مع أيقونة انتظار فقط)، ثم — إن لم يعد — تُنفَّذ
    //   المغادرة الفعلية القديمة دون أي تغيير (يليها sessions كما كانت).
    user._discGrace = true;
    refreshUserStat(user); // يبث stat=3 فوراً فقط — لا تأثير آخر على العضوية/المايك/العدّاد

    user._discTimer = setTimeout(() => {
      // انتهت المهلة ولم يُعاود الاتصال — نفس سلوك الطرد الفوري السابق دون أي تغيير
      if (user.lid && user.token) {
        const sess = {
          id: user.id, lid: user.lid, topic: user.topic, msg: user.msg,
          pic: user.pic, ico: user.ico, co: user.co, bg: user.bg,
          ucol: user.ucol, mcol: user.mcol, rep: user.rep,
          power: user.power, rank: user.rank, s: user.s,
          _fp: user._fp, refr: user.refr, b: user.b || '',
          roomid: user.roomid  // نحتفظ بـ roomid لإعادة الانضمام عند rc2
        };
        sessions.set(user.token, sess);
        setTimeout(() => sessions.delete(user.token), SESSION_TTL);
      }
      leaveRoom(socket, user, 'disconnect');
      removeRecentLogin(user.id);
      users.delete(socket.id);
      console.log(`[-] ${user.topic} (${socket.id})`);
    }, DISCONNECT_GRACE_MS);
  });
});

// ─── الموزع الرئيسي للأوامر ──────────────────────────────────────────────────
function dispatch(socket, user, cmd, data) {
  // ▲ إضافة: أي أمر وارد من العميل داخل الشات = نشاط. يُحدِّث آخر نشاط
  //   ويُعيد الحالة لنشطة (stat=0) فوراً عبر u^ إن كانت خاملة — نفس مصدر
  //   computeStat() المستخدم في pub() وبالفحص الدوري أدناه، بدون Socket جديد.
  user.last = Date.now();
  refreshUserStat(user);

  // الغرفة الحالية (اختصار)
  const room = user.roomid ? rooms.get(user.roomid) : null;
  const adminOk = isAdmin(user, room);
  const modOk   = isMod(user, room);

  switch (cmd) {

    // ════════════════════════════════════════════════════════════════════════
    // الاتصال الأولي
    // appraad.js: send("online", {}) عند الاتصال لأول مرة
    // ════════════════════════════════════════════════════════════════════════
    case 'online': {
      user.token = genId();
      // appraad.js case 'server' → isStreamActive=true, عرض عداد المتصلين
      send(socket, 'server',   { online: io.engine.clientsCount });
      // appraad.js case 'rlist' → بناء قائمة الغرف
      send(socket, 'rlist',    [...rooms.values()].map(roomListItem));
      send(socket, 'emos',     []);
      send(socket, 'dro3',     []);
      send(socket, 'sico',     []);
      send(socket, 'powers',   []);
      // appraad.js case 'settings' → chatInteractionsConfig
      // ▲ إصلاح جذري: كانت هذه القيم مكتوبة يدوياً وثابتة دائماً (mlikes/
      //   bclikes=true, mreply/bcreply=false) بغض النظر عمّا حُفظ فعلياً في
      //   إعدادات الموقع — تُرسَل عند كل اتصال أول بالصفحة (قبل حتى تسجيل
      //   الدخول)، فتطغى على أي حفظ من لوحة التحكم في كل مرة تُفتح/تُحدَّث
      //   الصفحة. الآن تستخدم liveSettings (المصدر الموحَّد أعلى الملف).
      send(socket, 'settings', liveSettings({ mlikes: true, bclikes: true, mreply: false, bcreply: false, calls: false }));
      // القائمة قبل تسجيل الدخول (#lonline) — آخر MAX_RECENT مستخدم سجّلوا دخولاً
      send(socket, 'online', recentLogins.slice());
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // دخول كزائر  { username, fp, refr, r }
    // appraad.js: send('g', { username, fp, refr, r })
    // الترتيب الصحيح: ok → login{msg:ok} → joinRoom
    // appraad.js يبدأ معالجة الغرفة فقط بعد استقبال case 'login' msg:'ok'
    // ════════════════════════════════════════════════════════════════════════
    case 'g': {
      // ▲ إضافة: شرط allowg (السماح بدخول الزوار) — كان محفوظاً بإعدادات
      //   الموقع بلا أي تطبيق فعلي.
      if (!siteSetting('allowg', true)) {
        send(socket, 'login', { msg: 'wrong' });
        send(socket, 'not', { user: 'srv', msg: 'دخول الزوار معطّل حالياً' });
        return;
      }
      const { username, fp, refr, r } = data || {};
      const name = (username || '').trim();
      if (!name || name.length < 2) {
        send(socket, 'login', { msg: 'badname' }); return;
      }

      // تعيين بيانات الزائر
      user.topic = sanitize(name, 60);
      user.lid   = user.id;   // الزائر: lid = id (لا حساب مسجل)
      user._fp   = fp ? (typeof fp === 'object' ? JSON.stringify(fp).slice(0, 300) : String(fp)) : '';
      user.refr  = refr || '';
      user.last  = Date.now();

      // ▲ إضافة: شرط maxIP (الحد الأقصى لعدد الحسابات المتصلة من نفس
      //   الآي بي في آنٍ واحد) — كان محفوظاً بإعدادات الموقع بلا أي تطبيق.
      const maxIP = parseInt(siteSetting('maxIP', 0)) || 0;
      if (maxIP > 0 && user._ip) {
        let countSameIP = 0;
        users.forEach(u => { if (u._ip === user._ip) countSameIP++; });
        if (countSameIP >= maxIP) {
          send(socket, 'login', { msg: 'wrong' });
          send(socket, 'not', { user: 'srv', msg: 'تم الوصول للحد الأقصى من الحسابات المسموح بها لهذا الآي بي' });
          return;
        }
      }

      // تحديد الغرفة المستهدفة
      // ▲ إصلاح: كانت تُختار الغرفة المطلوبة/الأولى دون أي تحقق من كلمة
      //   المرور أو الحظر، فيُرسل 'ok'+'login:ok' ثم تفشل joinRoom بصمت.
      const targetRoom = pickJoinableRoom(user, r);
      if (!targetRoom) {
        send(socket, 'login', { msg: 'banned' });
        send(socket, 'not', { user: 'srv', msg: 'أنت محظور من كل الغرف المتاحة حالياً' });
        logLogin(user.topic, 'مستخدم محظور', user._ip);
        return;
      }

      // ① أرسل ok أولاً — appraad.js: isLoginApproved = true
      send(socket, 'ok', null);

      // ② أرسل login{msg:'ok'} — يُطلق myid و userAuthHash في appraad.js
      send(socket, 'login', {
        msg:    'ok',
        id:     user.id,
        k:      user.token,
        ttoken: user.token,
        r:      targetRoom ? targetRoom.id : null
      });
      // window.myid مطلوب لكي تعمل نافذة لوحة التحكم (window.opener.myid)
      send(socket, 'ev', { data: 'try{window.myid=myid;}catch(e){}' });

      // ③ بعد الإعلام بالنجاح نضيف المستخدم للغرفة
      if (targetRoom) joinRoom(socket, user, targetRoom, '');
      addRecentLogin(user);
      logLogin(user.topic, 'زائر', user._ip);
      console.log(`[+] زائر: "${user.topic}" | ${user._ip}`);
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // تسجيل دخول عضو  { username, password, stealth, fp, refr, r }
    // appraad.js: send("login", { username, stealth, password, fp, refr, r })
    // الترتيب: ok → login{msg:ok} → joinRoom
    // ════════════════════════════════════════════════════════════════════════
    case 'login': {
      const { username, password, stealth, fp, refr, r } = data || {};
      const name = (username || '').trim();
      if (!name) { send(socket, 'login', { msg: 'badname' }); return; }

      const nameKey = name.toLowerCase();
      const acc     = accounts.get(nameKey);
      if (!acc)                                          { send(socket, 'login', { msg: 'noname' }); return; }
      if (!bcrypt.compareSync(password || '', acc.pass)) {
        send(socket, 'login', { msg: 'wrong' });
        logLogin(name, 'كلمة سر خاطئة', user._ip);
        return;
      }

      // منع تسجيل دخول مزدوج: إذا كان العضو متصلاً بسوكت آخر نقطع القديم
      const existingUser = byLID(acc.lid);
      if (existingUser && existingUser.socketId !== socket.id) {
        const oldSocket = io.sockets.sockets.get(existingUser.socketId);
        if (oldSocket) {
          send(oldSocket, 'login', { msg: 'kicked_login' });
          leaveRoom(oldSocket, existingUser, 'kick');
        } else if (existingUser._discGrace) {
          // ▲ إضافة: نفس الحساب كان بمهلة انتظار قطع اتصال (stat=3، سوكته
          //   القديم ميت فعلياً فلا يوجد oldSocket لطرده أعلاه). تسجيل دخول
          //   كامل جديد (وليس rc2) يعني تجاوزاً صريحاً لتلك المهلة، فيجب
          //   تحرير مقعده/عضويته الفعلية بالغرفة القديمة الآن (وإلا بقي
          //   مدخل عالق دائماً في room.members بمعرّف سوكت ميت لا يُنظِّفه
          //   أي مؤقّت لاحقاً، لأن مؤقّت الطرد سيُلغى بالسطر التالي).
          if (existingUser._discTimer) clearTimeout(existingUser._discTimer);
          const oldRoom = existingUser.roomid ? rooms.get(existingUser.roomid) : null;
          if (oldRoom) {
            oldRoom.members.delete(existingUser.socketId);
            const mi = oldRoom.mic.indexOf(existingUser.id);
            if (mi !== -1) oldRoom.mic[mi] = 0;
            toRoom(oldRoom.id, 'ur', [existingUser.id, null]);
            toRoom(oldRoom.id, 'u-', existingUser.id);
            broadcastRoomUpdate(oldRoom);
          }
        }
        users.delete(existingUser.socketId);
      }

      // استعادة بيانات الحساب
      user.lid   = acc.lid;
      user.topic = sanitize(acc.name || name, 60);
      user.pic   = acc.pic   || 'pic.png';
      user.ico     = acc.ico     || '';
      user.giftIco = acc.giftIco || '';
      user.rep     = acc.rep     || 0;
      user.power   = acc.power   || '';
      user.rank    = acc.rank    || 0;
      // ▲ إضافة: استعادة حالتي تعطيل الخاص/التنبيهات المحفوظتين (طلب صريح).
      user.nopm    = acc.nopm    || false;
      user.nonot   = acc.nonot   || false;
      // ▲ إضافة: إعادة حساب ico تلقائياً هنا تصحّح ذاتياً أي حساب قديم كانت
      //   أيقونة رتبته غير متزامنة معه قبل هذا الإصلاح (لا يبث لأنه لا يوجد
      //   roomid بعد في هذه اللحظة بالضبط — البث الفعلي يحصل عند دخول الغرفة).
      syncIco(user);
      user.co    = acc.co    || '--';
      user.bg    = acc.bg    || '';
      user.ucol  = acc.ucol  || '';
      user.mcol  = acc.mcol  || '';
      user.msg   = acc.msg   || '';
      user.accCreated = acc.created || Date.now();
      // ▲ إصلاح: أي عضو كان يستطيع إرسال stealth:true من العميل مباشرة
      //   ليصبح متخفياً، دون أي تحقق من صلاحية "stealth" المُعرَّفة أصلاً في
      //   نظام الصلاحيات (buildPower().stealth) — ثغرة تجاوز صلاحيات.
      user.s     = stealth === true && hasPower(user, null, 'stealth');
      user._fp   = fp ? (typeof fp === 'object' ? JSON.stringify(fp).slice(0, 300) : String(fp)) : '';
      user.refr  = refr || '';
      user.last  = Date.now();
      acc.last   = Date.now();

      // ▲ إصلاح: نفس مشكلة حالة 'g' أعلاه — استخدام pickJoinableRoom بدل
      //   اختيار الغرفة دون تحقق من كلمة المرور/الحظر.
      const targetRoom = pickJoinableRoom(user, r);
      if (!targetRoom) {
        send(socket, 'login', { msg: 'banned' });
        send(socket, 'not', { user: 'srv', msg: 'أنت محظور من كل الغرف المتاحة حالياً' });
        logLogin(user.topic, 'مستخدم محظور', user._ip);
        return;
      }

      // ① ok ② login ③ joinRoom
      send(socket, 'ok', null);
      send(socket, 'login', {
        msg:    'ok',
        id:     user.id,
        k:      user.token,
        ttoken: user.token,
        r:      targetRoom ? targetRoom.id : null
      });
      // window.myid مطلوب لكي تعمل نافذة لوحة التحكم (window.opener.myid)
      send(socket, 'ev', { data: 'try{window.myid=myid;}catch(e){}' });

      if (targetRoom) joinRoom(socket, user, targetRoom, '');
      addRecentLogin(user);
      logLogin(user.topic, 'تسجيل دخول', user._ip);
      console.log(`[+] عضو: "${user.topic}" rank=${user.rank}`);
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // تسجيل عضوية جديدة  { username, password, fp, refr, r }
    // appraad.js: send("reg", { username, password, fp, refr, r })
    // appraad.js case 'reg' في login → showNotificationToast("success","تم تسجيل العضويه")
    // ════════════════════════════════════════════════════════════════════════
    case 'reg': {
      // ▲ إضافة: شرط allowreg (السماح بتسجيل عضويات جديدة) — كان محفوظاً
      //   بإعدادات الموقع بلا أي تطبيق فعلي.
      if (!siteSetting('allowreg', true)) {
        send(socket, 'login', { msg: 'wrong' });
        send(socket, 'not', { user: 'srv', msg: 'التسجيل معطّل حالياً' });
        return;
      }
      const { username, password, fp } = data || {};
      const name = (username || '').trim();
      if (!name)                             { send(socket, 'login', { msg: 'badname'  }); return; }
      if (!password || password.length < 4)  { send(socket, 'login', { msg: 'badpass'  }); return; }
      const nameKey = name.toLowerCase();
      if (accounts.has(nameKey))             { send(socket, 'login', { msg: 'usedname' }); return; }

      const newLid = genId();
      accounts.set(nameKey, {
        lid: newLid, name: sanitize(name, 60),
        pass: bcrypt.hashSync(password, SALT_ROUNDS),
        pic: 'pic.png', ico: '', rep: 0, power: '',
        rank: 0, co: '--', bg: '', ucol: '', mcol: '', msg: '',
        created: Date.now(), last: Date.now()
      });
      send(socket, 'login', { msg: 'reg' });
      logLogin(name, 'عضو جديد', user._ip);
      console.log(`[+] تسجيل: "${name}"`);
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // تسجيل الخروج
    // appraad.js: send("logout", {})
    // ════════════════════════════════════════════════════════════════════════
    case 'logout': {
      leaveRoom(socket, user, 'logout');
      user.token = genId();
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // الانضمام لغرفة  { id, pwd }
    // appraad.js: send('rjoin', { roomid, pwd })
    // (appraad.js يرسل roomid وليس id أحياناً — ندعم كليهما)
    // ════════════════════════════════════════════════════════════════════════
    case 'rjoin': {
      const id  = data?.id || data?.roomid;
      const pwd = data?.pwd || '';
      const targetRoom = rooms.get(id);
      if (!targetRoom) return;
      if (targetRoom.id === user.roomid) return; // مسبقاً بنفس الغرفة
      // ▲ إصلاح: نتحقق أولاً (checkJoinable) *قبل* مغادرة الغرفة الحالية،
      //   حتى لا يخسر العضو غرفته الحالية إذا فشل الانضمام للغرفة الجديدة
      //   (كلمة مرور خاطئة/محظور)، وحتى الآن كانت النتيجة صمتاً تاماً بلا
      //   أي رسالة بسبب عدم دعم appraad2.js لـ login.msg=needpass/banned.
      const check = checkJoinable(targetRoom, user, pwd, false);
      if (!check.ok) {
        send(socket, 'login', { msg: check.reason });
        send(socket, 'not', { user: 'srv', msg: check.msg });
        return;
      }
      // ▲ إصلاح: 'move' بدل 'leave' — نص أدق لبقية أعضاء الغرفة القديمة
      //   ("انتقل إلى غرفة أخرى" بدل "غادر الغرفة") لأن هذا تنقّل بين
      //   الغرف وليس مغادرة كاملة للموقع.
      leaveRoom(socket, user, 'move', targetRoom);
      joinRoom(socket, user, targetRoom, pwd, true); // force=true لتفادي إعادة التحقق (تم أعلاه)
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // مغادرة الغرفة
    // ════════════════════════════════════════════════════════════════════════
    case 'rleave': {
      leaveRoom(socket, user);
      // leaveRoom يرسل ur[id,null] للجميع تلقائياً — لا حاجة لإرسال rlist
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // رسالة عامة  { msg, mi, link }
    // appraad.js: Tsend() → send('msg', { msg, mi })
    //   mi = ID الرسالة المردود عليها (replyId)
    // appraad.js case 'msg' → injectBroadcastItemToUi('#d2', commandPayload)
    //   الكلاينت يضع كلاس mi{id} على كل رسالة لأغراض الحذف والإعجاب
    // ════════════════════════════════════════════════════════════════════════
    case 'msg': {
      if (!room) return;
      let { msg: text, mi: replyMi, link } = data || {};
      if (!text && !link) return;
      // ▲ إضافة: إنفاذ mreply فعلياً هنا أيضاً (لا يكفي إخفاء الزر بالعميل
      //   فقط) — لو كان معطّلاً نتجاهل خاصية الرد كلياً (لا ربط، لا إشعار)
      //   وتُرسل كرسالة عادية، حتى لو وصل mi من زر قديم لم يُحذف من الشاشة
      //   بعد (appraad2.js لا يعيد رسم الأزرار على الرسائل المعروضة مسبقاً).
      if (replyMi && global.siteSettings?.mreply === false) replyMi = null;
      // ▲ إضافة: توسيع الاختصارات (راجع expandShortcut أعلاه) قبل أي فحص آخر.
      if (text) text = expandShortcut(text);
      // ▲ إضافة: شرط msgst (الحد الأدنى من الإعجابات للكتابة العامة
      //   بالغرفة) — كان محفوظاً في إعدادات الموقع بلا أي تطبيق فعلي.
      if (!adminOk) {
        const minLikes = parseInt(siteSetting('msgst', 0)) || 0;
        if (minLikes > 0 && (user.rep || 0) < minLikes) {
          send(socket, 'not', { user: 'srv', msg: `يجب أن تملك ${minLikes} إعجاب على الأقل للكتابة هنا` });
          return;
        }
      }
      // ▲ إصلاح: الفلتر يعمل على الجميع بلا أي استثناء (حتى المشرفين) كما
      //   طُلب صراحة — سابقاً كان المشرف مُستثنى بالكامل من الفحص. كذلك
      //   "ممنوع" فقط يمنع الإرسال، بينما "مراقبة" تسمح بالإرسال وتُسجِّل فقط.
      const filterHit = checkFilters(text);
      if (filterHit) {
        logFilteredMessage(user, filterHit.v, text, filterHit.action);
        if (filterHit.action === 'ban') {
          send(socket, 'not', { user: 'srv', msg: 'رسالتك تحتوي على كلمة محظورة ولم يتم إرسالها' });
          return;
        }
        // action === 'watch' → يكمل الإرسال بشكل طبيعي بعد التسجيل أعلاه
      }
      const newMi = makeBid();   // ID الرسالة الجديدة دائماً فريد
      // ▲ إصلاح جذري (البند الثاني — سبب حقيقي لعدم استقلال لايكات/ردود
      //   العام عن الحائط، مؤكَّد بلقطتي شاشة فعليتين من المستخدم): كانت
      //   الحمولة تحمل bid وmi معاً. appraad2.js (_0x5b0377، حول السطر 3714)
      //   يفحص `if (bid != null) {...bclikes/bcreply...} else if (mi != null)
      //   {...mlikes/mreply...}` — bid تُفحَص أولاً وتفوز دائماً متى وُجدت،
      //   فكانت كل رسائل الغرف العادية (التي تحمل bid فعلاً) تُعامَل كأنها
      //   منشور حائط: زر الإعجاب يُبنى بـsend('likebc',{bid}) بدل
      //   send('likem',mi) (فيبحث السيرفر عن bid ضمن globalWall فلا يجده —
      //   لا شيء يُسجَّل فعلياً ويُبَث bc^ عالمياً بلا داعٍ)، وظهور/اختفاء
      //   الزرين يتبع bclikes/bcreply حرفياً بدل mlikes/mreply المستقلين
      //   عنهما تماماً. bid لرسائل الغرف لم تكن مُستخدَمة لأي غرض آخر أصلاً
      //   (نظام اللايك الحقيقي لرسائل الغرف مبني على recentMessages
      //   المفهرسة بـmi عبر trackMessage أدناه، لا بid إطلاقاً؛ الحذف/الرد
      //   يعتمدان .mi{id} أيضاً لا .bid{id}) — حذفها فقط يكفي ليأخذ العميل
      //   فرع mi != null الصحيح تلقائياً دون أي تعديل آخر.
      const payload = buildMsg(user, text || '', {
        mi:   newMi,             // appraad.js: يضع كلاس .mi{newMi} على العنصر
        rmi:  replyMi || null    // المردود عليه (عرضه في الواجهة لاحقاً)
      });
      // ▲ إصلاح: buildMsg تُنقّي (sanitize) النص داخلياً — فلو ضُمِّن وسم
      //   a.uplink *قبل* تمريره لها لتم تهريب الوسم HTML مرتين وإفساده.
      //   الإلحاق يحدث هنا بعد بناء الحمولة مباشرة، بدل حقل link منفصل لا
      //   يقرأه العميل إطلاقاً.
      if (link) payload.msg += (payload.msg ? ' ' : '') + wrapUplink(link);
      if (replyMi) payload.rmi  = replyMi;
      trackMessage(newMi, payload, user.roomid);
      // ▲ إضافة: إشعار الرد (طلب صريح) — عند الرد على رسالة عامة، صاحبها
      //   الأصلي يستلم إشعاراً فورياً باسم/معرّف/صورة/وقت الرادّ. لا إشعار
      //   عند الرد على نفس رسالتك. notifyUser تحترم nonot/alert تلقائياً.
      if (replyMi) {
        const original = recentMessages.get(replyMi);
        if (original && original.uid !== user.id) {
          notifyUser(user, byUID(original.uid), `قام <b>${user.topic}</b> بالرد على رسالتك`, { mi: newMi });
        }
      }
      toRoom(user.roomid, 'msg', payload);
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // رسالة الحائط  { msg, link, bid }
    // appraad.js: sendbc() → send('bc', { msg, link, bid })
    //   bid = ID المنشور المردود عليه عند الرد (replyId.indexOf('.bid'))
    // appraad.js case 'bc' → injectBroadcastItemToUi("#d2bc", commandPayload)
    // ════════════════════════════════════════════════════════════════════════
    case 'bc': {
      let { msg: text, link, bid: replyBid } = data || {};
      if (!text && !link) return;
      // ▲ إضافة: إنفاذ bcreply فعلياً هنا أيضاً (نفس منطق mreply بـcase 'msg')
      //   — الحائط عالمي لا يتبع غرفة بعينها، فمصدر الإعداد الحقيقي هنا هو
      //   global.siteSettings مباشرة (نفس ما يقرأه sitesave ويكتبه)، بقيمة
      //   افتراضية true تطابق افتراضي إنشاء الغرفة/cp_owner عند عدم الحفظ بعد.
      if (replyBid && (global.siteSettings?.bcreply === false)) replyBid = null;
      // ▲ إضافة: توسيع الاختصارات قبل أي فحص آخر.
      if (text) text = expandShortcut(text);
      // ▲ إصلاح: حُذف شرط "يجب أن يكون داخل غرفة" — الحائط عالمي (يُخزَّن في
      //   globalWall ويُبث toAll، لا علاقة له بأي غرفة تحديداً كما هو موضّح
      //   أسفل)، وكان هذا الشرط يمنع النشر بالكامل بمجرد خروج العضو من أي
      //   غرفة (مثلاً بعد 'rleave') رغم عدم وجود أي سبب منطقي لذلك.
      //
      // ▲ تصحيح: "wall_minutes" تمثّل فعلياً "مدة الانتظار بين رسائل الحائط"
      //   (طلب صريح) — أي عدد الدقائق الواجب انتظارها بين منشورَين متتاليين
      //   لنفس العضو، وليس عمر الحساب كما كانت مُفسَّرة سابقاً. ينطبق هذا
      //   القيد (ومثله wall_likes) فقط على من لا يملك أي صلاحية إطلاقاً —
      //   أي عضو يحمل أي رتبة (سوبر/إدارة/مراقب/أي صلاحية أخرى) يتجاوزها.
      if (!user.power) {
        const minLikes   = parseInt(siteSetting('wall_likes', 0))   || 0;
        const minMinutes = parseInt(siteSetting('wall_minutes', 0)) || 0;
        if (minLikes > 0 && (user.rep || 0) < minLikes) {
          send(socket, 'not', { user: 'srv', msg: `يجب أن تملك ${minLikes} إعجاب على الأقل للنشر بالحائط` });
          return;
        }
        if (minMinutes > 0 && user.lastWallPostAt) {
          const elapsedMinutes = (Date.now() - user.lastWallPostAt) / 60000;
          if (elapsedMinutes < minMinutes) {
            const remain = Math.ceil(minMinutes - elapsedMinutes);
            send(socket, 'not', { user: 'srv', msg: `يجب الانتظار ${remain} دقيقة قبل نشر رسالة أخرى بالحائط` });
            return;
          }
        }
      }
      user.lastWallPostAt = Date.now();
      const filterHit = checkFilters(text);
      if (filterHit) {
        logFilteredMessage(user, filterHit.v, text, filterHit.action);
        if (filterHit.action === 'ban') {
          send(socket, 'not', { user: 'srv', msg: 'منشورك يحتوي على كلمة محظورة ولم يتم نشره' });
          return;
        }
      }
      const newBid = makeBid();
      const payload = buildMsg(user, text || '', {
        bid:  newBid,
        bmi:  replyBid || null   // appraad2.js يقرأ bmi كـ "بي سي رد عليه"
      });
      // ▲ إصلاح: نفس إصلاح msg أعلاه — تضمين الرابط داخل نص المنشور بعد
      //   بناء الحمولة (لا قبلها، تفادياً لتهريب HTML مزدوج)، بدل حقل link
      //   منفصل لا يقرأه العميل إطلاقاً (وهو سبب ظهور صور الحائط بيضاء/فارغة).
      if (link) payload.msg += (payload.msg ? ' ' : '') + wrapUplink(link);
      if (replyBid) payload.bmi  = replyBid;
      // ▲ إضافة: إشعار الرد لمنشورات الحائط (نفس منطق الرسائل العامة تماماً)
      if (replyBid) {
        const originalPost = globalWall.find(m => m.bid === replyBid);
        if (originalPost && originalPost.uid !== user.id) {
          notifyUser(user, byUID(originalPost.uid), `قام <b>${user.topic}</b> بالرد على منشورك بالحائط`, { bid: newBid });
        }
      }
      // الحائط عالمي: يُحفظ في globalWall ويُبثّ لجميع المتصلين
      globalWall.push(payload);
      if (globalWall.length > MAX_WALL) globalWall.shift();
      toAll('bc', payload);
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // رسالة خاصة  { msg, id }
    // appraad.js: pmsg() → send('pm', { msg, id })
    // appraad.js case 'pm' → openw + injectBroadcastItemToUi
    // ════════════════════════════════════════════════════════════════════════
    case 'pm': {
      let { msg: text, id: toId } = data || {};
      if (!text || !toId) return;
      const target = byUID(toId);
      if (!target) return;
      if (target.nopm && !hasPower(user, room, 'forcepm')) {
        send(socket, 'not', { user: 'srv', msg: 'هذا المستخدم قام بتعطيل استقبال الرسائل الخاصة.' });
        return;
      }
      // ▲ إضافة: توسيع الاختصارات قبل أي فحص آخر.
      text = expandShortcut(text);
      // ▲ إضافة: شرط pmlikes (الحد الأدنى من الإعجابات لإرسال رسالة خاصة) —
      //   كان محفوظاً في إعدادات الموقع بلا أي تطبيق فعلي. المشرفون يتجاوزونه.
      if (!adminOk) {
        const minLikes = parseInt(siteSetting('pmlikes', 0)) || 0;
        if (minLikes > 0 && (user.rep || 0) < minLikes) {
          send(socket, 'not', { user: 'srv', msg: `يجب أن تملك ${minLikes} إعجاب على الأقل لإرسال رسالة خاصة` });
          return;
        }
      }
      const filterHit = checkFilters(text);
      if (filterHit) {
        logFilteredMessage(user, filterHit.v, text, filterHit.action);
        if (filterHit.action === 'ban') {
          send(socket, 'not', { user: 'srv', msg: 'رسالتك تحتوي على كلمة محظورة ولم يتم إرسالها' });
          return;
        }
      }
      // ▲ إصلاح (طلب صريح: "رسائل الخاص لا يوجد فيها تعليق او لايك، احذفها
      //   منها نهائي"): كانت الحمولة تحمل bid رغم عدم استخدامه لأي غرض فعلي
      //   هنا (openw تعتمد على pm لا bid — انظر التعليق أسفله). بوجود bid
      //   فقط (بلا mi)، يأخذ appraad2.js (_0x5b0377) فرع `bid != null` فيبني
      //   زري إعجاب/رد يتبعان bclikes/bcreply — تماماً كما كان يحدث خطأً
      //   لرسائل الغرف قبل إصلاحها. بحذف bid هنا، لا bid ولا mi يصلان معاً
      //   فيسقط في `else` الأخيرة التي تُزيل .blike/.breply نهائياً وبلا أي
      //   شرط (لا تتبع أي إعداد إطلاقاً)، تماماً كالمطلوب. أثر جانبي واحد:
      //   زر الحذف (.bdel) كان يظهر أيضاً على رسالتك الخاصة المُرسلة (صدى)
      //   عبر نفس فرع bid (فحص lid == نفسك)؛ سيختفي الآن أيضاً بلا استثناء.
      //   أخبرني إن كنت تريد إبقاء إمكانية حذف رسالتك الخاصة تحديداً.
      // للمستلم: pm = هوية المرسل → openw(senderId) يفتح/يُحدِّث نافذة
      // المحادثة الصحيحة باسم المرسل (appraad2.js: openw(payload.pm))
      const ts = io.sockets.sockets.get(target.socketId);
      if (ts) send(ts, 'pm', buildMsg(user, text, { pm: user.id, uid: user.id }));
      // ▲ إصلاح: appraad2.js لا يعرض الرسالة المُرسلة في نافذته محلياً
      //   إطلاقاً — دالة الإرسال (sndpm) تكتفي بإفراغ صندوق الكتابة وترسل
      //   للسيرفر فقط، بلا أي عرض محلي، معتمدة كلياً على استقبال 'pm' من
      //   السيرفر لفتح/تحديث نافذة المحادثة. كان السيرفر لا يرسل أي شيء
      //   للمُرسل نفسه، فتبقى رسالته غير ظاهرة له إطلاقاً حتى يردّ الطرف
      //   الآخر — وهذا سبب ظهور "محادثة جديدة" في كل مرة بدل استمرار نفس
      //   المحادثة. الحل: إرسال نسخة "صدى" للمُرسل أيضاً، مع pm = هوية
      //   *المستلم* (وليس هويته هو) حتى تفتح/تُحدِّث openw نفس نافذة
      //   المحادثة الصحيحة على جهازه (المفتاح #c<id> يُبنى من pm)، مع إبقاء
      //   uid = هوية الكاتب الفعلي (المُرسل) لعرض اسمه الصحيح على الفقاعة.
      send(socket, 'pm', buildMsg(user, text, { pm: target.id, uid: user.id }));
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // إعجاب على منشور الحائط  { bid }
    // appraad.js: send('likebc', { bid })
    // appraad.js case 'bc^' → likeHeartIcon.text(+1)
    // ════════════════════════════════════════════════════════════════════════
    case 'likebc': {
      // ▲ توحيد: نفس منطق bcreply أعلاه — الحائط عالمي، والمصدر الحقيقي
      //   لإعداده هو global.siteSettings مباشرة، لا إعداد غرفة بعينها.
      if (global.siteSettings?.bclikes === false) return;
      const { bid } = data || {};
      if (!bid) return;
      // ▲ إضافة: نفس منطق likem تماماً — منع التكرار خلال دقيقة وإشعار فوري.
      const remain = likeCooldownRemaining(user.id, 'bc:' + bid);
      if (remain > 0) {
        send(socket, 'not', { user: 'srv', msg: 'لا يمكنك إرسال إعجاب آخر قبل انتهاء دقيقة واحدة.' });
        return;
      }
      markLiked(user.id, 'bc:' + bid);
      // ▲ إصلاح: room.wall فارغة دوماً (لا شيء يملؤها) — منشورات الحائط
      //   الحقيقية تُخزَّن في globalWall (حائط عالمي وليس محلياً لكل غرفة،
      //   كما هو موثّق في case 'bc' أدناه). كان هذا يمنع تسجيل الإعجاب
      //   فعلياً ويُرسل دائماً likes:1 مهما كان العدد الحقيقي، والبث كان
      //   محصوراً بالغرفة الحالية رغم أن الحائط يظهر لكل المستخدمين.
      const wallMsg = globalWall.find(m => m.bid === bid);
      if (wallMsg) {
        wallMsg.likes = (wallMsg.likes || 0) + 1;
        const sender = byUID(wallMsg.uid);
        if (sender && sender.id !== user.id) {
          sender.rep++;
          saveAccount(sender, { rep: sender.rep });
          toAll('u^', { id: sender.id, rep: sender.rep });
          notifyUser(user, sender, `أعجب <b>${user.topic}</b> بمنشورك بالحائط`, { bid });
        }
      }
      toAll('bc^', { bid, likes: wallMsg ? wallMsg.likes : 1 });
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // إعجاب على رسالة عامة  { bid } أو bid (string)
    // appraad.js: send('likemsg', { bid }) أو send('likem', bid)
    // appraad.js case 'mi+' → messageHeartIcon.text(+1)
    // ════════════════════════════════════════════════════════════════════════
    case 'likemsg':
    case 'likem': {
      if (!room || global.siteSettings?.mlikes === false) return;
      const bid = (data && typeof data === 'object') ? data.bid : data;
      if (!bid) return;
      // ▲ إصلاح: منع تكرار الإعجاب خلال دقيقة واحدة (طلب صريح، برسالة الخطأ
      //   الحرفية المطلوبة)، وإرسال إشعار فوري لصاحب الرسالة — كان likem لا
      //   يفعل شيئاً سوى إخبار العميل بزيادة العدّاد المعروض محلياً فقط، دون
      //   أي تتبع حقيقي لعدد اللايكات أو صاحب الرسالة على الإطلاق.
      const remain = likeCooldownRemaining(user.id, 'mi:' + bid);
      if (remain > 0) {
        send(socket, 'not', { user: 'srv', msg: 'لا يمكنك إرسال إعجاب آخر قبل انتهاء دقيقة واحدة.' });
        return;
      }
      markLiked(user.id, 'mi:' + bid);
      const msgEntry = recentMessages.get(bid);
      if (msgEntry) {
        msgEntry.likes = (msgEntry.likes || 0) + 1;
        if (msgEntry.uid !== user.id) {
          const author = byUID(msgEntry.uid);
          if (author) { author.rep = (author.rep || 0) + 1; saveAccount(author, { rep: author.rep }); toAll('u^', { id: author.id, rep: author.rep }); }
          notifyUser(user, author, `أعجب <b>${user.topic}</b> برسالتك`, { mi: bid });
        }
      }
      toRoom(user.roomid, 'mi+', bid);
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // حذف منشور حائط  { bid }
    // appraad.js case 'delbc' → $(".bid"+bid).remove()
    // ════════════════════════════════════════════════════════════════════════
    case 'delbc': {
      if (!room) return;
      const { bid } = data || {};
      if (!bid) return;
      // ▲ إصلاح: نفس مشكلة likebc أعلاه — room.wall فارغة دوماً، لذا كانت
      //   wallMsg تُعطى undefined دائماً، فيفشل شرط isAuthor حتى لصاحب
      //   المنشور الحقيقي، والحذف (حتى لو مُرَّ عبر صلاحية المشرف) لا يحذف
      //   شيئاً فعلياً من globalWall (المصدر الحقيقي المُرسَل عند bclist)،
      //   فيعود المنشور "المحذوف" للظهور عند أي انضمام/إعادة اتصال لاحقة.
      const wallMsg = globalWall.find(m => m.bid === bid);
      const isAuthor = wallMsg && wallMsg.lid === user.lid;
      if (!adminOk && !hasPower(user, room, 'delbc') && !isAuthor) return;
      if (!isAuthor) logAction(user, 'delbc', wallMsg?.topic || bid);
      const idx = globalWall.findIndex(m => m.bid === bid);
      if (idx !== -1) globalWall.splice(idx, 1);
      toAll('delbc', { bid });
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // حذف رسالة عامة  { mi, topic } أو { bid } أو string
    // appraad.js: send('dmsg', { mi, topic })  ← onclick مباشر في الواجهة
    // appraad.js case 'dmsg' → $(".mi"+commandPayload).remove()
    // ════════════════════════════════════════════════════════════════════════
    case 'delmsg':
    case 'dmsg': {
      // ▲ إصلاح: يوجد صلاحية "dmsg" مُعرَّفة أصلاً في نظام الصلاحيات ولم
      //   تكن تُفحَص إطلاقاً (adminOk فقط).
      if (!room || (!adminOk && !hasPower(user, room, 'dmsg'))) return;
      // appraad.js يرسل { mi, topic } أو string
      const msgId = (typeof data === 'object') ? (data?.mi || data?.bid) : data;
      if (!msgId) return;
      if (!adminOk) logAction(user, 'dmsg', room.name, String(msgId));
      toRoom(user.roomid, 'dmsg', msgId);
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // المايك  slotIndex | -1
    // appraad.js: tmic(index) → send("mic", index)
    //   mic(-1)  → مغادرة المايك
    //   mic(n)   → طلب خانة n أو أول فارغة
    // ════════════════════════════════════════════════════════════════════════
    case 'mic': {
      if (!room || !room.settings.mic) return;
      const slot = data;

      if (slot === -1) {
        // مغادرة المايك
        const i = room.mic.indexOf(user.id);
        if (i !== -1) {
          room.mic[i] = 0;
          // إبلاغ P2P
          room.mic.forEach(uid => {
            if (typeof uid !== 'string' || uid === user.id) return;
            const peer = byUID(uid);
            if (!peer) return;
            const ps = io.sockets.sockets.get(peer.socketId);
            if (ps) send(ps, 'p2', { t: 'x', id: user.id, dir: 0 });
          });
          broadcastRoomUpdate(room);
        }
        return;
      }

      // طلب خانة
      const idx = (typeof slot === 'number' && slot >= 0 && slot < MAX_MIC_SLOTS)
        ? slot
        : room.mic.findIndex(v => v === 0);
      if (idx === -1) return;
      if (room.mic[idx] !== 0) return; // الخانة مشغولة أو مقفولة

      // إزالة من خانة سابقة إن وُجدت
      const prev = room.mic.indexOf(user.id);
      if (prev !== -1) room.mic[prev] = 0;

      room.mic[idx] = user.id;
      broadcastRoomUpdate(room);

      // إبلاغ المايكات الأخرى لبدء WebRTC
      room.mic.forEach((uid, i) => {
        if (i === idx) return;
        if (typeof uid !== 'string') return;
        const peer = byUID(uid);
        if (!peer) return;
        const ps = io.sockets.sockets.get(peer.socketId);
        if (ps) send(ps, 'p2', { t: 'start', id: user.id, dir: 0 });
      });
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // سحب المايك من مستخدم (مشرف)  userId (string)
    // appraad.js: send("uml", currentMicUser)
    // ════════════════════════════════════════════════════════════════════════
    case 'uml': {
      // ▲ إصلاح: صلاحية "mic" في نظام الصلاحيات تعني تحديداً "التحكم بمايك
      //   الغير" (appraad2.js يُظهر أزرار uml/umm/uma بناءً عليها لا adminOk).
      if (!room || (!adminOk && !hasPower(user, room, 'mic'))) return;
      const targetId = typeof data === 'string' ? data : data?.id;
      const i = room.mic.indexOf(targetId);
      if (i !== -1) {
        room.mic[i] = 0;
        const t = byUID(targetId);
        logAction(user, 'uml', t || targetId, room.name);
        broadcastRoomUpdate(room);
        // إبلاغ المستخدم المسحوب منه
        if (t) {
          const ts = io.sockets.sockets.get(t.socketId);
          if (ts) {
            send(ts, 'p2', { t: 'x', id: user.id, dir: 0 });
          }
        }
      }
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // قفل مايك مستخدم بالقوة  userId (string)  [مشرف]
    // appraad.js: send("umm", targetUserId)
    // يقفل خانة المايك (false) دون إخراج المستخدم منها
    // ════════════════════════════════════════════════════════════════════════
    case 'umm': {
      if (!room || (!adminOk && !hasPower(user, room, 'mic'))) return;
      const targetId = typeof data === 'string' ? data : (data?.id || '');
      const mi = room.mic.indexOf(targetId);
      if (mi !== -1) {
        room.mic[mi] = false; // false = خانة مقفولة
        const t = byUID(targetId);
        logAction(user, 'umm', t || targetId, room.name);
        broadcastRoomUpdate(room);
        // إبلاغ المستخدم بإيقاف p2p
        if (t) {
          const ts = io.sockets.sockets.get(t.socketId);
          if (ts) send(ts, 'p2', { t: 'x', id: user.id, dir: 0 });
        }
      }
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // تفعيل مايك لمستخدم قسرياً  userId (string)  [مشرف]
    // appraad.js: send("uma", targetUserId)
    // يضع المستخدم في أول خانة فارغة أو مقفولة
    // ════════════════════════════════════════════════════════════════════════
    case 'uma': {
      if (!room || (!adminOk && !hasPower(user, room, 'mic'))) return;
      const targetId = typeof data === 'string' ? data : (data?.id || '');
      // لا تضع إذا كان موجوداً مسبقاً
      if (room.mic.indexOf(targetId) !== -1) return;
      const idx = room.mic.findIndex(v => v === 0 || v === false);
      if (idx === -1) return;
      room.mic[idx] = targetId;
      logAction(user, 'uma', byUID(targetId) || targetId, room.name);
      broadcastRoomUpdate(room);
      // إبلاغ المايكات الأخرى ببدء WebRTC مع هذا المستخدم
      room.mic.forEach((uid, i) => {
        if (i === idx || typeof uid !== 'string') return;
        const peer = byUID(uid);
        if (!peer) return;
        const ps = io.sockets.sockets.get(peer.socketId);
        if (ps) send(ps, 'p2', { t: 'start', id: targetId, dir: 0 });
      });
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // أوامر الإجراءات على الأعضاء  { cmd, id, ... }
    // appraad.js: send("action", { cmd, id, ... })
    //   cmd: like | report | kick | delpic | roomkick | ban | not | gift
    // يُعيد التوجيه لنفس dispatchCP مع بناء data صحيح
    // ════════════════════════════════════════════════════════════════════════
    case 'action': {
      const { cmd: actionCmd, ...actionRest } = data || {};
      if (!actionCmd) return;
      dispatchCP(socket, user, room, { cmd: actionCmd, ...actionRest }, adminOk, modOk);
      break;
    }
    // ════════════════════════════════════════════════════════════════════════
    case 'micstat': {
      if (!room || (!adminOk && !hasPower(user, room, 'mic'))) return;
      const { i: mi, v: mv } = data || {};
      if (typeof mi !== 'number' || mi < 0 || mi >= MAX_MIC_SLOTS) return;
      room.mic[mi] = mv ? 0 : false; // false = مقفول
      logAction(user, 'micstat', room.name, `مقعد ${mi}: ${mv ? 'فتح' : 'قفل'}`);
      broadcastRoomUpdate(room);
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // WebRTC P2P  { t, id, dir, data }
    // appraad.js: send('p2', { t, id, dir, data })
    // appraad.js case 'p2' → switch(commandPayload.t)
    // ════════════════════════════════════════════════════════════════════════
    case 'p2': {
      const { id: toId, t: sigT, data: sigD, dir } = data || {};
      const target = byUID(toId);
      if (!target) return;
      const ts = io.sockets.sockets.get(target.socketId);
      if (!ts) return;
      send(ts, 'p2', {
        t:   sigT,
        id:  user.id,
        data: sigD,
        dir: dir === 1 ? 0 : 1
      });
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // مكالمة صوتية  { t, id, data }
    // appraad.js: send("call", { t, id, data })
    // appraad.js case 'call' → switch(commandPayload.t)
    // ════════════════════════════════════════════════════════════════════════
    case 'call': {
      const { t: callT, id: callTo, data: callData } = data || {};
      if (!callTo) return;
      const target = byUID(callTo);
      if (!target) return;
      // ▲ إضافة: شرطا calls (تفعيل ميزة المكالمات) وcallsLike (الحد الأدنى
      //   من الإعجابات) — كانا محفوظين بإعدادات الموقع بلا أي تطبيق فعلي.
      //   يُطبَّقان فقط عند بدء مكالمة جديدة (t='call')، وليس على بقية
      //   إشارات نفس المكالمة القائمة أصلاً (answer/reject/signal/x) حتى لا
      //   تنكسر مكالمة بدأت بشكل صحيح بسبب تغيّر لاحق بالإعدادات.
      if (callT === 'call' && !adminOk) {
        if (!siteSetting('calls', true)) {
          send(socket, 'not', { user: 'srv', msg: 'ميزة المكالمات معطّلة حالياً' });
          return;
        }
        const minLikes = parseInt(siteSetting('callsLike', 0)) || 0;
        if (minLikes > 0 && (user.rep || 0) < minLikes) {
          send(socket, 'not', { user: 'srv', msg: `يجب أن تملك ${minLikes} إعجاب على الأقل لاستخدام المكالمات` });
          return;
        }
      }
      const ts = io.sockets.sockets.get(target.socketId);
      if (!ts) return;
      send(ts, 'call', { t: callT, id: user.id, data: callData });
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // مؤشر الكتابة  [targetId, 0|1]
    // appraad.js: send('ty', [currentPrivateUser, 1|0])
    // appraad.js case 'ty' → typingIndicator.show()/hide()
    // ════════════════════════════════════════════════════════════════════════
    case 'ty': {
      if (!Array.isArray(data) || data.length < 2) return;
      const [toId, val] = data;
      const target = byUID(toId);
      if (!target) return;
      const ts = io.sockets.sockets.get(target.socketId);
      if (ts) send(ts, 'ty', [user.id, val]);
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // رفض الرسائل الخاصة  { id }
    // appraad.js: send("nopm", { id: targetUserId })
    // ════════════════════════════════════════════════════════════════════════
    case 'nopm': {
      user.nopm = true;
      const target = byUID(data?.id);
      if (!target) return;
      const ts = io.sockets.sockets.get(target.socketId);
      if (ts) send(ts, 'nopm', { id: user.id });
      break;
    }

    // ▲ إصلاح: كانت case 'nonot' مكرَّرة حرفياً مرتين بنفس switch — هذه
    //   النسخة القديمة (قيمة ثابتة true دائماً، بلا حفظ) كانت تُظلِّل النسخة
    //   الصحيحة الأحدث بالأسفل بالكامل (JS ينفّذ أول case مطابق فقط)، فتبقى
    //   الثانية كوداً ميتاً لا يُنفَّذ أبداً رغم صحتها. حُذفت هذه النسخة
    //   القديمة، والنسخة الصحيحة الوحيدة المتبقية بالأسفل تقرأ data.nonot
    //   فعلياً وتحفظها بـsaveAccount.

    // ════════════════════════════════════════════════════════════════════════
    // DND / مشغول  { busy }
    // ════════════════════════════════════════════════════════════════════════
    case 'busy': {
      // ▲ إصلاح: لم تكن تُحفَظ إطلاقاً (تُفقد فوراً عند أي إعادة اتصال) —
      //   طلب صريح: "استعادتها بعد تسجيل الدخول".
      user.nopm = data?.busy === true || data?.busy === 1;
      saveAccount(user, { nopm: user.nopm });
      user._stat = computeStat(user); // مزامنة الذاكرة المؤقتة مع stat الجديد (قفل/فتح الخاص)
      // ▲ إضافة: لم يكن يُبَث لأحد — أيقونة الحالة (.ustat) لدى بقية أعضاء
      //   الغرفة لا تتحدّث إلا بعد إعادة انضمام كاملة. نفس نمط setprofile.
      if (user.roomid) toRoom(user.roomid, 'u^', user.pub());
      break;
    }

    // ▲ إضافة: appraad2.js لا يملك أي إرسال فعلي لهذا الأمر (زر "تعطيل
    //   التنبيهات" يبدّل متغيّراً محلياً فقط بلا أي send() — راجع البند
    //   الثاني عشر بالمستند) — أضفنا سكربتاً إضافياً في index.html (حقن
    //   ديناميكي من السيرفر، دون تعديل appraad2.js أو الملف على القرص) يرسل
    //   هذا الأمر فعلياً عند نفس الضغطة. نفس نمط busy تماماً.
    case 'nonot': {
      user.nonot = data?.nonot === true || data?.nonot === 1;
      saveAccount(user, { nonot: user.nonot });
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // طلب ملف مستخدم  uid (string)
    // appraad.js: send('upro', uid)  → فتح البروفايل محلياً
    // appraad.js window.upro = upro
    // ════════════════════════════════════════════════════════════════════════
    case 'upro': {
      const uid = typeof data === 'string' ? data : data?.id;
      const target = byUID(uid);
      if (!target) return;
      // إرسال بيانات المستخدم للعرض في البروفايل
      send(socket, 'upro', target.pub());
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // تحديث الملف الشخصي  { topic, msg, ucol, mcol, bg }
    // appraad.js: setprofile() → send("setprofile", { topic, msg, ucol, mcol, bg })
    // appraad.js case 'online+' → يحدث واجهة العضو
    // ════════════════════════════════════════════════════════════════════════
    case 'setprofile': {
      // ▲ إصلاح: حُذف شرط "يجب أن يكون داخل غرفة" — تعديل البروفايل الشخصي
      //   (الاسم/التوقيع/الألوان) لا علاقة له بوجود العضو في غرفة من عدمه
      //   (نفس علة bc السابقة).
      // ▲ إضافة: شرط proflikes (الحد الأدنى من الإعجابات لتعديل البروفايل)
      //   — كان محفوظاً بإعدادات الموقع بلا أي تطبيق فعلي. المشرفون يتجاوزونه.
      if (!adminOk) {
        const minLikes = parseInt(siteSetting('proflikes', 0)) || 0;
        if (minLikes > 0 && (user.rep || 0) < minLikes) {
          send(socket, 'not', { user: 'srv', msg: `يجب أن تملك ${minLikes} إعجاب على الأقل لتعديل البروفايل` });
          return;
        }
      }
      const { topic, msg: statusMsg, ucol, mcol, bg } = data || {};
      if (topic     !== undefined) user.topic = sanitize(topic, 60);
      if (statusMsg !== undefined) user.msg   = sanitize(statusMsg, 200);
      if (ucol      !== undefined) user.ucol  = sanitize(ucol, 30);
      if (mcol      !== undefined) user.mcol  = sanitize(mcol, 30);
      if (bg        !== undefined) user.bg    = sanitize(bg, 30);
      saveAccount(user, {
        topic: user.topic, msg: user.msg,
        ucol:  user.ucol,  mcol: user.mcol, bg: user.bg
      });
      // appraad.js case 'online+' actionType==0 → rebuild أو actionType==1 → prepend
      // نرسل u^ (تحديث عضو) وليس online+ كامل لتجنب إعادة البناء
      if (user.roomid) toRoom(user.roomid, 'u^', user.pub());
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // تغيير الصورة الشخصية  { pic }
    // appraad.js: sendpic() → send('setpic', { pic })
    // ════════════════════════════════════════════════════════════════════════
    case 'setpic': {
      // ▲ إصلاح: حُذف شرط "يجب أن يكون داخل غرفة" (نفس علة bc/setprofile).
      // ▲ إضافة: شرط piclikes (الحد الأدنى من الإعجابات لتغيير الصورة).
      if (!adminOk) {
        const minLikes = parseInt(siteSetting('piclikes', 0)) || 0;
        if (minLikes > 0 && (user.rep || 0) < minLikes) {
          send(socket, 'not', { user: 'srv', msg: `يجب أن تملك ${minLikes} إعجاب على الأقل لتغيير الصورة` });
          return;
        }
      }
      const { pic } = data || {};
      if (!pic) return;
      user.pic = sanitize(pic, 200);
      saveAccount(user, { pic: user.pic });
      if (user.roomid) toRoom(user.roomid, 'u^', user.pub());
      break;
    }

// ▲ إصلاح (كشف بصمة الجهاز يعرض JSON خام): كان يُخزَّن navigator.n الخام
//   (fp) كنص JSON مباشرة (user._fp = JSON.stringify(fp)) فيظهر للمشرف حرفياً
//   {"a":"...","pri":...} بدل بصمة مختصرة مقروءة. الدالة هنا حتمية (نفس
//   الجهاز ⇐ نفس الناتج دائماً، ضروري لمطابقة الحظر بالبصمة اللاحقة) بلا أي
//   مكتبة خارجية: نظام التشغيل من الـUser-Agent (مصدر أوثق من محاولة تخمينه
//   من fp نفسها)، ثم عدة أجزاء قصيرة (هاش بسيط) من مجموعات مختلفة من بيانات
//   الجهاز (الشاشة/المنطقة الزمنية/الإضافات/الخط..)، مطابقة لشكل المثال
//   المطلوب: "Linux | x00 | vr.07n.n9.cy | ...".
    // ════════════════════════════════════════════════════════════════════════
    // بصمة الجهاز  { ...fp }
    // appraad.js: navigator.n → send('fp', navigator.n) عند تسجيل الدخول
    // ════════════════════════════════════════════════════════════════════════
    case 'fp': {
      // ▲ إصلاح: كان يُخزَّن navigator.n الخام كنص JSON مباشرة، فيظهر لأي
      //   مشرف يفتح "كشف النكات" بصمة خام غير مقروءة بدل ملخص مختصر. الدالة
      //   shortFingerprint (معرَّفة أعلى buildPower) حتمية بالكامل — نفس
      //   الجهاز يُنتج نفس البصمة المختصرة دائماً، فتبقى صلاحة المطابقة
      //   بالحظر بالبصمة قائمة تماماً كالسابق، فقط الشكل المعروض تغيَّر.
      user._fp = shortFingerprint(data, socket.handshake?.headers?.['user-agent'] || '');
      saveAccount(user, { fp: user._fp });
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // إعلان عام لجميع المتصلين  { msg }  [مشرف فقط]
    // appraad.js: pmsg() → send('pmsg', { msg })
    // appraad.js case 'pmsg' → إظهار لافتة إعلانية
    // ملاحظة: يُرسَل لكل المتصلين (داخل وخارج الغرف) لا للغرفة فقط
    // ════════════════════════════════════════════════════════════════════════
    case 'pmsg': {
      if (!adminOk && !hasPower(user, room, 'publicmsg')) return;
      const { msg: text } = data || {};
      if (!text) return;
      const pmsgPayload = {
        uid:   user.id,
        topic: user.topic,
        pic:   user.pic,
        msg:   sanitize(text, 500),
        t:     Date.now(),
        bid:   makeBid()
      };
      toAll('pmsg', pmsgPayload);
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // خاص جماعي لجميع المتصلين  { msg }  [مشرف فقط]
    // appraad.js case 'ppmsg' → يعرضها كرسالة في #d2
    // ════════════════════════════════════════════════════════════════════════
    case 'ppmsg': {
      if (!adminOk && !hasPower(user, room, 'ppmsg')) return;
      const { msg: text } = data || {};
      if (!text) return;
      const payload = {
        uid:   user.id, topic: user.topic, pic: user.pic,
        msg:   sanitize(text, 500), t: Date.now(), bid: makeBid()
      };
      users.forEach(u => {
        const ts = io.sockets.sockets.get(u.socketId);
        if (ts) send(ts, 'ppmsg', payload);
      });
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // هدية  { uid, gift }
    // appraad.js: gift(uid, giftFile) → send('gift', { uid, gift })
    // appraad.js case 'gift' → عرض نافذة الهدية
    // ════════════════════════════════════════════════════════════════════════
    case 'gift': {
      const { uid: toId, gift } = data || {};
      if (!toId || !gift) return;
      const target = byUID(toId);
      if (!target) return;
      const ts = io.sockets.sockets.get(target.socketId);
      if (ts) send(ts, 'gift', {
        gift:  sanitize(gift, 100),
        uid:   user.id,
        topic: user.topic,
        pic:   user.pic
      });
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // إشعار  { id, msg }
    // appraad.js case 'not' → عرض نافذة تنبيه
    // ════════════════════════════════════════════════════════════════════════
    case 'not': {
      if (!modOk) return;
      const { id: toId, msg: notMsg } = data || {};
      const target = byUID(toId);
      if (!target) return;
      // ▲ إصلاح: نفس إصلاح نسخة dispatchCP أدناه — كان يرسل خاماً بلا فحص
      //   nonot، بخلاف item 12 الصريح: حتى المشرف يحتاج صلاحية alert
      //   تحديداً لتجاوز تعطيل التنبيهات، لا مجرد modOk.
      // ▲ إضافة: طلب صريح بالبند 12 — "يصل للمرسل: هذا المستخدم قام بتعطيل
      //   استقبال التنبيهات." عند الحجب تحديداً (وليس بكل نقاط notifyUser،
      //   راجع تعليق الدالة أعلاه).
      if (!notifyUser(user, target, sanitize(notMsg || '', 300))) {
        send(socket, 'not', { user: 'srv', msg: 'هذا المستخدم قام بتعطيل استقبال التنبيهات.' });
      }
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // حظر مستخدم  { id }
    // appraad.js: ubnr(id) → send('ubnr', { id })
    // ════════════════════════════════════════════════════════════════════════
    case 'ubnr': {
      // تجاهل في البث (حماية محلية)
      const { id: toId } = data || {};
      const target = byUID(toId);
      if (!target) return;
      const ts = io.sockets.sockets.get(target.socketId);
      if (ts) send(ts, 'ubnr', { id: user.id });
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // بحث تاريخ مستخدم  userId (string)  [مشرف فقط]
    // appraad.js: send('uh', targetUserId)  ← يرسل user.id وليس lid
    // appraad.js case 'uh' → جدول: العضو / الزخرفة / IP / الوقت / FP
    // ════════════════════════════════════════════════════════════════════════
    case 'uh': {
      if (!adminOk && !hasPower(user, room, 'history')) return;
      // data هو userId (string) من appraad.js — send('uh', targetUserId)
      const targetId  = typeof data === 'string' ? data : (data?.id || '');
      const foundUser = byUID(targetId);
      const searchLid = foundUser ? foundUser.lid : targetId;
      const history   = [];
      const now       = Date.now();
      // ▲ إصلاح: كان يعرض u.lid (معرّف تقني/بصمة، أرقام وحروف غير مقروءة —
      //   كما في الصورة المرفقة) في عمود "العضو" بدل اسم المستخدم الفعلي
      //   الذي سجّل به الدخول. اسم المستخدم الحقيقي مخزَّن في سجل الحساب
      //   (accounts) بالحقل name، وليس في lid (وهو معرّف ربط داخلي فقط).
      const findAccName = (lid) => {
        for (const [, acc] of accounts) { if (acc.lid === lid) return acc.name || ''; }
        return '';
      };
      users.forEach(u => {
        if (u.lid === searchLid || u.id === targetId) {
          history.push({
            u:   findAccName(u.lid) || u.topic || u.lid,  // appraad: العضو (اسم تسجيل الدخول الفعلي)
            t:   u.topic,                        // appraad: الزخرفه (decoration)
            _ip: u._ip  || '',
            _fp: u._fp  || '',
            c:   now - (u.created || now)        // appraad: الوقت (session age in ms → .time())
          });
        }
      });
      // البحث في الحسابات المسجّلة أيضاً (مستخدم أوفلاين)
      if (history.length === 0 && searchLid) {
        for (const [, acc] of accounts) {
          if (acc.lid === searchLid) {
            history.push({
              u:   acc.name || searchLid,
              t:   acc.name || searchLid,
              _ip: '',
              _fp: '',
              c:   now - (acc.last || now)
            });
            break;
          }
        }
      }
      send(socket, 'uh', history);
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // تحديث إعدادات الغرفة  { mic, calls, ... }  [مشرف]
    // appraad.js: sett_save() → send('settings', { ... })
    // appraad.js case 'settings' → chatInteractionsConfig = commandPayload
    // ════════════════════════════════════════════════════════════════════════
    case 'settings': {
      if (!room || !adminOk) return;
      const allowed = ['mic','setpower','ban','owner','calls','mlikes','bclikes','mreply','bcreply'];
      allowed.forEach(k => { if (k in (data || {})) room.settings[k] = !!data[k]; });
      toRoom(user.roomid, 'settings', liveSettings(room.settings));
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // طلب قائمة مشرفي الغرفة  { roomid }
    // appraad.js: openw → send('ops', { roomid })
    // appraad.js case 'ops' → عرض قائمة المشرفين
    // ════════════════════════════════════════════════════════════════════════
    case 'ops': {
      const { roomid } = data || {};
      const targetRoom = rooms.get(roomid || user.roomid);
      if (!targetRoom) return;
      send(socket, 'ops', buildRops(targetRoom));
      // ▲ إضافة: تُبث قائمة محظوري الغرفة مع قائمة المشرفين معاً دائماً —
      //   بناءً على الوصف الصريح لعرضهما معاً في نفس نافذة إعدادات الغرفة
      //   (تبويب الترقية لمراقب، والقائمة الجديدة أسفلها مباشرة).
      send(socket, 'rbans', buildRoomBans(targetRoom));
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // طلب قائمة محظوري غرفة معينة صراحة  { roomid }  (بنفس نمط 'ops')
    // ════════════════════════════════════════════════════════════════════════
    case 'rbans': {
      const { roomid } = data || {};
      const targetRoom = rooms.get(roomid || user.roomid);
      if (!targetRoom) return;
      send(socket, 'rbans', buildRoomBans(targetRoom));
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // ترفيع مشرف  { lid }
    // appraad.js: send('op+', { lid })
    // ════════════════════════════════════════════════════════════════════════
    case 'op+': {
      if (!room || !adminOk) return;
      const { lid } = data || {};
      if (!lid || room.ops.includes(lid)) return;
      room.ops.push(lid);
      const opTarget = byLID(lid);
      logAction(user, 'op+', opTarget || lid, room.name);
      toRoom(room.id, 'rops', buildRops(room));
      if (opTarget) {
        const ts = io.sockets.sockets.get(opTarget.socketId);
        if (ts) send(ts, 'power', buildPower(opTarget, room));
      }
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // إزالة مشرف  { lid }
    // appraad.js: send('op-', { lid })
    // ════════════════════════════════════════════════════════════════════════
    case 'op-': {
      if (!room || !adminOk) return;
      const { lid } = data || {};
      if (!lid) return;
      room.ops = room.ops.filter(l => l !== lid);
      const opTarget2 = byLID(lid);
      logAction(user, 'op-', opTarget2 || lid, room.name);
      toRoom(room.id, 'rops', buildRops(room));
      if (opTarget2) {
        const ts = io.sockets.sockets.get(opTarget2.socketId);
        if (ts) send(ts, 'power', buildPower(opTarget2, room));
      }
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // إزالة حظر الغرفة المؤقت مبكراً (السماح بالعودة قبل انتهاء الـ٢٠ دقيقة)
    // { lid, roomid? }  — بنفس نمط 'op-' تماماً (زر X في قائمة المحظورين)
    // ════════════════════════════════════════════════════════════════════════
    case 'rban-': {
      if ((!adminOk && !hasPower(user, room, 'kick')) || !room) return;
      const { lid, roomid } = data || {};
      if (!lid) return;
      const targetRoom = roomid ? rooms.get(roomid) : room;
      if (!targetRoom) return;
      targetRoom.roomBans.delete(lid);
      const rTarget = byLID(lid);
      logAction(user, 'rban-', rTarget || lid, targetRoom.name);
      toRoom(targetRoom.id, 'rbans', buildRoomBans(targetRoom));
      pushRoomBans(targetRoom); // بث SSE فوري (بنفس اللحظة) لأي مستمع مفتوح
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // إنشاء غرفة جديدة  { topic/name, pass, max, l, vl, about, welcome, pic, c }
    // appraad.js: mkr() → send('r+', { ... })
    // appraad.js case 'r+' → بناء عنصر الغرفة في #rooms
    // ════════════════════════════════════════════════════════════════════════
    case 'r+': {
      if (!adminOk) return;
      const rName = sanitize(data?.topic || data?.name || '', 80);
      if (!rName) return;
      const newRoom = new Room('r_' + Date.now(), rName, data?.pass || '');
      newRoom.owner   = user.lid;
      newRoom.pic     = data?.pic     || 'room.png';
      newRoom.about   = sanitize(data?.about   || '', 300);
      newRoom.welcome = sanitize(data?.welcome || '', 300);
      newRoom.max     = parseInt(data?.max)    || 20;
      newRoom.l       = parseInt(data?.l)      || 0;
      newRoom.vl      = parseInt(data?.vl)     || 0;
      newRoom.c       = data?.c       || '#000000';
      rooms.set(newRoom.id, newRoom);
      logAction(user, 'r+', rName);
      toAll('r+', roomListItem(newRoom));
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // تعديل غرفة  { id, topic, pass, max, l, vl, about, welcome, pic, c }
    // appraad.js: redit() → send('r^', { ... })
    // appraad.js case 'r^' → تحديث بيانات الغرفة
    // ════════════════════════════════════════════════════════════════════════
    case 'r^': {
      const editId = data?.id || user.roomid;
      const targetRoom = rooms.get(editId);
      if (!targetRoom) return;
      // ▲ إصلاح جوهري: adminOk تُحسب من الغرفة *الحالية* للمستخدم (أعلى
      //   دالة dispatch)، وليس من الغرفة *المستهدفة* بالتعديل — فكان مشرف/
      //   مالك غرفة معينة (عبر room.ops أو room.owner) يُرفض تعديله لغرفته
      //   هو نفسها إن كان جالساً وقتها في غرفة أخرى أو خارج أي غرفة، وهو
      //   تحديداً سيناريو التعديل من قائمة "الغرف" بلوحة التحكم (حيث يُعدِّل
      //   المشرف أي غرفة من القائمة بصرف النظر عن مكان جلوسه الفعلي) — وهذا
      //   سبب "إعدادات الغرفة من لوحة التحكم لا تُحفَظ".
      if (!adminOk && !isAdmin(user, targetRoom)) return;
      if (data?.topic)   targetRoom.name    = sanitize(data.topic, 80);
      if (data?.name)    targetRoom.name    = sanitize(data.name, 80);
      if (data?.pic)     targetRoom.pic     = data.pic;
      if (data?.c)       targetRoom.c       = data.c;
      if (data?.about    !== undefined) targetRoom.about   = sanitize(data.about, 300);
      if (data?.welcome  !== undefined) targetRoom.welcome = sanitize(data.welcome, 300);
      if (data?.max)     targetRoom.max     = parseInt(data.max) || 20;
      if (data?.l        !== undefined) targetRoom.l  = parseInt(data.l)  || 0;
      if (data?.vl       !== undefined) targetRoom.vl = parseInt(data.vl) || 0;
      if ('pass' in (data || {})) {
        targetRoom.pass     = data.pass ? bcrypt.hashSync(data.pass, SALT_ROUNDS) : '';
        targetRoom.needpass = !!data.pass;
      }
      logAction(user, 'r^', targetRoom.name);
      broadcastRoomUpdate(targetRoom);
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // حذف غرفة  { id }
    // appraad.js: send('r-', { id })
    // appraad.js case 'r-' → إزالة عنصر الغرفة
    // ════════════════════════════════════════════════════════════════════════
    case 'r-': {
      const delId   = data?.id;
      const delRoom = rooms.get(delId);
      if (!delRoom) return;
      // ▲ إصلاح: نفس علة r^ أعلاه — التحقق يجب أن يكون على الغرفة
      //   المستهدفة بالحذف وليس الغرفة الحالية للمستخدم.
      if (!adminOk && !isAdmin(user, delRoom)) return;
      logAction(user, 'r-', delRoom.name);
      // ▲ إصلاح: كان يرسل 'kick' الذي لا يملك appraad2.js أي معالج له
      //   إطلاقاً، ولا يُعيد نقل أعضاء الغرفة المحذوفة لأي مكان — فيبقون
      //   بواجهة تُشير لغرفة لم تعد موجودة على السيرفر (حالة غير متسقة).
      //   الحل: نقلهم فوراً لأول غرفة متاحة (نفس أسلوب rinvite) مع إشعار.
      const affected = [...delRoom.members.values()];
      rooms.delete(delId);
      toAll('r-', { id: delId });
      const fallback = [...rooms.values()][0] || null;
      affected.forEach(m => {
        const s = io.sockets.sockets.get(m.socketId);
        if (!s) return;
        m.roomid = null; // الغرفة القديمة محذوفة أصلاً، لا حاجة لمعالجة مغادرة كاملة
        if (fallback) {
          joinRoom(s, m, fallback, '', true);
          send(s, 'not', { user: 'srv', msg: 'تم حذف الغرفة، تم نقلك لغرفة أخرى' });
        } else {
          send(s, 'not', { user: 'srv', msg: 'تم حذف الغرفة' });
        }
      });
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // تحكم مايك الغرفة  { id, v }  [مشرف]
    // appraad.js: send("v", { id, v })  لتفعيل/تعطيل المايك في غرفة
    // ════════════════════════════════════════════════════════════════════════
    case 'v': {
      const targetRoom = data?.id ? rooms.get(data.id) : room;
      if (!targetRoom) return;
      // ▲ إصلاح: صلاحية "cmic" مُعرَّفة تحديداً لهذا الإجراء (تفعيل/تعطيل
      //   مايك الغرفة بالكامل) ولم تكن تُفحَص إطلاقاً. كذلك نفس علة r^/r-
      //   أعلاه: التحقق يجب أن يكون على الغرفة المستهدفة (targetRoom) وليس
      //   الغرفة الحالية للمستخدم فقط عند التعديل من قائمة الغرف بلوحة التحكم.
      if (!adminOk && !hasPower(user, targetRoom, 'cmic') && !isAdmin(user, targetRoom)) return;
      targetRoom.settings.mic = !!data?.v;
      logAction(user, 'v', targetRoom.name, targetRoom.settings.mic ? 'تفعيل' : 'تعطيل');
      toRoom(targetRoom.id, 'settings', liveSettings(targetRoom.settings));
      broadcastRoomUpdate(targetRoom);
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // بيانات لوحة التحكم  [windowCpi, [cmd, data]]
    // appraad.js: send("cpi", [senderWindow.cpi, [originalCmd, originalData]])
    // الفكرة: نافذة cp ترسل أوامرها عبر window.opener.postMessage → opener يعيد
    // إرسالها للسيرفر كـ cpi → السيرفر يعالجها ويرد بـ { cpi: id, data: ... }
    // → opener يوجّه الرد للنافذة المناسبة عبر _0x5d8244[cpiId].postMessage
    // ════════════════════════════════════════════════════════════════════════
    case 'cpi': {
      if (!adminOk) return;
      if (!Array.isArray(data) || data.length < 2) return;
      const [cpiId, innerMsg] = data;
      if (!Array.isArray(innerMsg) || !cpiId) return;
      const [innerCmd, innerData] = innerMsg;
      if (!innerCmd) return;
      // الـ cp popup يرسل [cmdName, cmdData] مباشرةً (مثل 'bans','kick','ban'...)
      // نبني كائن data صحيح لـ dispatchCP: { cmd: innerCmd, ...innerData }
      const cpiData = typeof innerData === 'object' && innerData !== null
        ? { cmd: innerCmd, ...innerData }
        : { cmd: innerCmd };
      // تعيين السياق: كل send(socket,...) داخل dispatchCP سيُغلَّف بـ {cpi, data}
      _cpiContext = { socketId: socket.id, cpiId };
      try { dispatchCP(socket, user, room, cpiData, adminOk, modOk); }
      finally { _cpiContext = null; }
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // أوامر لوحة التحكم  { cmd, ...data }
    // appraad.js: send('cp', { cmd, ... })
    // ════════════════════════════════════════════════════════════════════════
    case 'cp': {
      dispatchCP(socket, user, room, data, adminOk, modOk);
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // ملف / ميديا في الخاص  { pm, link }
    // appraad.js: sendfilea() → send('file', { pm, link })
    // appraad.js case 'file' → عرض رابط الملف في صندوق الخاص
    // ════════════════════════════════════════════════════════════════════════
    case 'file': {
      const { pm: toId, link } = data || {};
      if (!toId || !link) return;
      const target = byUID(toId);
      if (!target) return;
      if (target.nopm && !hasPower(user, room, 'forcepm')) {
        send(socket, 'not', { user: 'srv', msg: 'هذا المستخدم قام بتعطيل استقبال الرسائل الخاصة.' });
        return;
      }
      // ▲ إضافة: شرط fileslikes (الحد الأدنى من الإعجابات لإرسال ملف/صورة).
      if (!adminOk) {
        const minLikes = parseInt(siteSetting('fileslikes', 0)) || 0;
        if (minLikes > 0 && (user.rep || 0) < minLikes) {
          send(socket, 'not', { user: 'srv', msg: `يجب أن تملك ${minLikes} إعجاب على الأقل لإرسال ملف` });
          return;
        }
      }
      // ▲ إصلاح جوهري: appraad2.js لا يملك أي "case 'file'" في مُستقبِل
      //   الأوامر إطلاقاً — كان الملف/الصورة يختفي بصمت تماماً عند المستلم
      //   دائماً. appraad2.js يستخدم نفس معرّف المحادثة (pm) لكل من النصوص
      //   والملفات (نفس حاوية #d2<id>)، فالتسليم الصحيح هو عبر حدث 'pm'
      //   نفسه بدل حدث 'file' منفصل غير مفهوم — تماماً كإصلاح PM السابق:
      //   صدى للمرسل بـ pm=هوية المستلم، ونسخة للمستلم بـ pm=هوية المرسل.
      // ▲ إصلاح إضافي: appraad2.js لا يقرأ أي حقل link منفصل إطلاقاً (راجع
      //   wrapUplink أعلاه) — هذا وحده كان يجعل الملف/الصورة يظهر فارغاً
      //   حتى لو استقبل العميل الرسالة بنجاح. الرابط يُضمَّن الآن داخل نص
      //   الرسالة نفسه بوسم a.uplink الذي يفهمه العميل ويحوّله لصورة فعلية.
      // ▲ تصحيح: buildMsg تُنقّي النص داخلياً، فتمرير وسم HTML كنص أولي لها
      //   يُهرِّبه ويُفسده — نبني الحمولة بنص فارغ ثم نُلحق الوسم بعدها.
      // ▲ إصلاح (نفس طلب حذف تعليق/لايك من الخاص أعلاه — ينطبق على رسائل
      //   الملف/الصورة الخاصة أيضاً بنفس الآلية بالضبط): حذف bid فقط.
      const ts  = io.sockets.sockets.get(target.socketId);
      const uplinkHtml = wrapUplink(link);
      const payloadToRecipient = buildMsg(user, '', { pm: user.id,   uid: user.id });
      const payloadToSender    = buildMsg(user, '', { pm: target.id, uid: user.id });
      payloadToRecipient.msg = uplinkHtml;
      payloadToSender.msg    = uplinkHtml;
      if (ts) send(ts, 'pm', payloadToRecipient);
      send(socket, 'pm', payloadToSender);
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // تغيير النك نيم  { id, nick }  [مشرف أو صاحبه]
    // appraad.js: send("unick", { id, nick })
    // appraad.js case 'u^' → يحدث الواجهة
    // ════════════════════════════════════════════════════════════════════════
    case 'unick': {
      const { id: unickId, nick } = data || {};
      const target = byUID(unickId);
      if (!target) return;
      // ▲ إصلاح: كان يسمح فقط لصاحب الاسم نفسه أو للمشرف الكامل (adminOk)،
      //   متجاهلاً صلاحيتي "mynick" (تعديل اسمي) و"unick" (تعديل اسم الغير)
      //   المُعرَّفتين أصلاً في نظام الصلاحيات.
      const isSelf = target.id === user.id;
      if (isSelf) {
        if (!adminOk && !hasPower(user, room, 'mynick')) return;
      } else {
        if (!adminOk && !hasPower(user, room, 'unick')) return;
        logAction(user, 'unick', target, nick);
      }
      target.topic = sanitize(nick || '', 60);
      saveAccount(target, { topic: target.topic });
      if (target.roomid) toRoom(target.roomid, 'u^', target.pub());
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // دعوة انتقال لغرفة  { id, rid, pwd }  [مشرف]
    // appraad.js: send("rinvite", { id, rid, pwd })
    // appraad.js case 'rinvite' في الكلاينت المدعو → rjoin تلقائي
    // ════════════════════════════════════════════════════════════════════════
    case 'rinvite': {
      // ▲ إصلاح: يوجد صلاحية "rinvite" مُعرَّفة أصلاً في نظام الصلاحيات
      //   ولم تكن تُفحَص إطلاقاً (adminOk فقط).
      if (!adminOk && !hasPower(user, room, 'rinvite')) return;
      const { id: invId, rid, pwd } = data || {};
      const target = byUID(invId) || byLID(invId);
      if (!target) return;
      const targetRoom = rooms.get(rid);
      if (!targetRoom) return;
      const ts = io.sockets.sockets.get(target.socketId);
      if (!ts) return;
      logAction(user, 'rinvite', target, targetRoom.name);
      // نقل قسري: رسالة الغرفة القديمة تأتي من leaveRoom، رسالة الدخول للغرفة الجديدة من joinRoom
      leaveRoom(ts, target, 'move', targetRoom);
      joinRoom(ts, target, targetRoom, pwd || '', true);
      // تنبيه الشخص المنقول بفورمات not الصحيح (appraad2.js: not.user → allUsersList)
      send(ts, 'not', { user: user.id, msg: 'تم نقلك' });
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // بنر ترحيبي  { u2, bnr }
    // appraad.js: send('bnr', { u2, bnr })
    // ════════════════════════════════════════════════════════════════════════
    case 'bnr': {
      if (!adminOk) return;
      const { u2, bnr: bnrFile } = data || {};
      const target = byUID(u2);
      const cleanBnr = cleanAssetName(bnrFile);
      if (!target || !cleanBnr) return;
      target.bnr = cleanBnr;
      saveAccount(target, { bnr: cleanBnr });
      logAction(user, 'bnr', target, cleanBnr);
      const bannerUrl = /^sico\//i.test(cleanBnr) ? cleanBnr : `sico/${cleanBnr}`;
      const ts = io.sockets.sockets.get(target.socketId);
      if (ts) send(ts, 'bnr', { bnr: sanitize(bannerUrl, 200) });
      if (target.roomid) toRoom(target.roomid, 'u^', target.pub());
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // إزالة بنر  { u2 }
    // appraad.js: send('bnr-', { u2 })
    // ════════════════════════════════════════════════════════════════════════
    case 'bnr-': {
      if (!adminOk) return;
      const { u2: u2id } = data || {};
      const target = byUID(u2id);
      if (!target) return;
      target.bnr = '';
      saveAccount(target, { bnr: '' });
      logAction(user, 'bnr-', target);
      const ts = io.sockets.sockets.get(target.socketId);
      if (ts) send(ts, 'bnr-', {});
      if (target.roomid) toRoom(target.roomid, 'u^', target.pub());
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // تعديل لايكات مستخدم  { id, likes }
    // appraad.js: send("setLikes", { id, likes })
    // ════════════════════════════════════════════════════════════════════════
    case 'setLikes': {
      if (!adminOk) return;
      const target = byUID(data?.id);
      if (!target) return;
      logAction(user, 'setLikes', target, String(parseInt(data.likes) || 0));
      target.rep = parseInt(data.likes) || 0;
      saveAccount(target, { rep: target.rep });
      if (target.roomid) toRoom(target.roomid, 'u^', { id: target.id, rep: target.rep });
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // حذف صورة مستخدم  { id }  [مشرف]
    // appraad.js: send('udelpic', { id })
    // ════════════════════════════════════════════════════════════════════════
    case 'udelpic': {
      if (!adminOk) return;
      const target = byUID(data?.id);
      if (!target) return;
      target.pic = 'pic.png';
      saveAccount(target, { pic: 'pic.png' });
      if (target.roomid) toRoom(target.roomid, 'u^', target.pub());
      break;
    }

    // ════════════════════════════════════════════════════════════════════════
    // تنفيذ كود JS عن بُعد  { data }  [owner فقط]
    // appraad.js case 'ev' → eval(commandPayload.data)
    // ════════════════════════════════════════════════════════════════════════
    case 'ev': {
      if (!buildPower(user, room).owner) return;
      const { id: evTarget, data: evCode } = data || {};
      if (!evCode) return;
      if (evTarget) {
        const target = byUID(evTarget);
        if (!target) return;
        const ts = io.sockets.sockets.get(target.socketId);
        if (ts) send(ts, 'ev', { data: evCode });
      } else {
        users.forEach(u => {
          const ts = io.sockets.sockets.get(u.socketId);
          if (ts) send(ts, 'ev', { data: evCode });
        });
      }
      break;
    }

    default:
      if (process.env.DEBUG) console.log(`[?] أمر غير معروف: "${cmd}"`);
  }
}

// ─── أوامر لوحة التحكم CP ─────────────────────────────────────────────────────
function dispatchCP(socket, user, room, data, adminOk, modOk) {
  const cmd = data?.cmd;
  if (!cmd) return;

  switch (cmd) {

    // ── طرد مستخدم  { id }
    case 'kick': {
      // ▲ إصلاح: modOk فضفاضة جداً — تصدق على أي صاحب صلاحية مسماة (حتى لو
      //   كانت صلاحيته "إعجاب فقط" مثلاً)! الصلاحية الصحيحة المخصصة لهذا
      //   الإجراء هي "kick" تحديداً (appraad2.js يُظهر زر الطرد بناءً عليها).
      if ((!adminOk && !hasPower(user, room, 'kick')) || !room) return;
      const target = byUID(data.id);
      if (!target) return;
      // ▲ إضافة: منع طرد عضو برتبة أعلى أو مساوية (تسلسل الرتب)
      if (!canActOnRank(user, target, room)) return;
      logAction(user, 'kick', target);
      const ts = io.sockets.sockets.get(target.socketId);
      if (ts) {
        leaveRoom(ts, target, 'kick');
        removeRecentLogin(target.id);
        send(ts, 'not', { user: user.id, msg: 'تم طردك' });
        send(ts, 'close', {});
        setTimeout(() => { try { ts.disconnect(true); } catch (_) {} }, 1200);
      }
      break;
    }

    // ── حظر مستخدم  { id?, type?, expires, reason }
    // appraad2.js يستخدم هذا الأمر بثلاث طرق مختلفة، لكل منها سلوك مختلف
    // بناءً على توضيح صريح:
    //   1) من نافذة الملف الشخصي upro → action.cmd=ban → dispatchCP({cmd:'ban', id})
    //      حظر عضو بعينه من دخول *كل* الموقع (وليس غرفة واحدة)، لمدة ٢٠
    //      دقيقة فقط (مؤقت)، عبر الآي بي ومعرّف الجهاز معاً.
    //   2) من جداول "كشف النكات/بصمات الزوار" (uh/cp_fps) عبر
    //      cp_fps_do → send('cp', { cmd:'ban', type: '<بادئة>=<fp>' })
    //      حيث type = قيمة البصمة fp نفسها، مع بادئة اختيارية من نجوم متبوعة
    //      بـ '=' تمثّل "عمق" الحظر (حظر عميق 1‑4)، مثال: "**=abcdef123".
    //      دائم (بلا وقت انتهاء) حتى يُحذف يدوياً من قائمة الحظر.
    //   3) من تبويب "الحظر" اليدوي بلوحة التحكم (مربع نص واحد فقط، بلا أي
    //      نوع محدَّد سلفاً — يكتب المشرف رقم جهاز/دولة/آيبي بحرية) عبر
    //      send('cp',{cmd:'ban', type: <نص حر>}) — دائم أيضاً. يجب اكتشاف
    //      نوع القيمة المكتوبة تلقائياً (آيبي/دولة/جهاز) وتخزينها في الحقل
    //      الصحيح المطابق حصراً، وترك بقية الحقول فارغة.
    // ▲ إصلاح: سابقاً كان type يُخزَّن كما هو في حقل غير مُستخدَم في isBanned
    //   إطلاقاً (لا fp ولا ip)، فكانت هذه الحظورات لا تمنع أحداً أبداً.
    // ▲ إصلاح معماري: الحظر أصبح عالمياً (globalBans) بدل مقتصر على غرفة
    //   واحدة (room.bans) — يمنع الدخول لكل الموقع فعلياً كما هو مطلوب.
    case 'ban': {
      // ▲ إصلاح: نفس ملاحظة kick أعلاه — الصلاحية الصحيحة هي "ban" تحديداً.
      if (!adminOk && !hasPower(user, room, 'ban')) return;
      const target = data.id ? byUID(data.id) : null;
      // ▲ إضافة: منع حظر عضو برتبة أعلى أو مساوية (تسلسل الرتب) — لا ينطبق
      //   على حظر البصمة/الآيبي/الدولة المباشر (لا يوجد target في تلك الحالة).
      if (target && !canActOnRank(user, target, room)) return;

      const entry = {
        id: data.id || '', lid: '', name: '',
        type: data.type || '', fp: '', ip: '', country: '', depth: 0,
        expires: null, reason: data.reason || '',
        count: 0, last: Date.now(), active: true
      };

      if (target) {
        // ── المسار 1: حظر عضو بعينه (زر upro) — مؤقت ٢٠ دقيقة، آيبي+جهاز معاً
        entry.lid     = target.lid;
        entry.name    = target.topic;
        entry.fp      = target._fp || '';
        entry.ip      = target._ip || '';
        entry.expires = Date.now() + 20 * 60 * 1000; // ٢٠ دقيقة
        const ts = io.sockets.sockets.get(target.socketId);
        if (ts) {
          leaveRoom(ts, target, 'ban');
          removeRecentLogin(target.id);
          send(ts, 'not', { user: user.id, msg: `تم حظرك لمدة 20 دقيقة` });
          send(ts, 'close', {});
          setTimeout(() => { try { ts.disconnect(true); } catch (_) {} }, 1200);
        }
      } else if (typeof data.type === 'string' && data.type) {
        // فكّ بادئة الحظر العميق: '*='..'****=' → depth 1..4 (المسار 2، من جداول كشف النكات)
        const deepMatch = data.type.match(/^(\*{1,4})=(.+)$/);
        if (deepMatch) {
          entry.depth = deepMatch[1].length;
          entry.fp    = deepMatch[2];
        } else {
          // ── المسار 3: إدخال يدوي حر من تبويب "الحظر" — كشف تلقائي للنوع
          const raw = data.type.trim();
          const isIPv4 = /^(\d{1,3}\.){3}\d{1,3}$/.test(raw);
          const isIPv6 = raw.includes(':') && /^[0-9a-fA-F:]+$/.test(raw);
          const isCountry = !isIPv4 && !isIPv6 && /^[a-zA-Z\u0600-\u06FF\s]{2,20}$/.test(raw) && raw.length <= 20 && !/[0-9]/.test(raw) && raw.replace(/\s/g, '').length <= 15;
          if (isIPv4 || isIPv6) {
            entry.ip = raw;
          } else if (isCountry && raw.length <= 3) {
            // رمز دولة قصير (SA, US...) — أولوية على الاسم الكامل لتفادي التباس مع رقم جهاز قصير
            entry.country = raw;
          } else if (isCountry) {
            entry.country = raw;
          } else {
            // افتراضي: معرّف جهاز (بصمة) — أطول/أعقد من أن يكون رمز دولة
            entry.fp = raw;
          }
        }
        // اطرد فوراً أي متصلين حالياً تُطابق القيمة (بصمة/آيبي/دولة)
        const len = [Infinity, 24, 16, 10, 6][Math.min(entry.depth, 4)];
        const bfp = entry.fp ? (len === Infinity ? entry.fp : entry.fp.slice(0, len)) : '';
        users.forEach(u => {
          let match = false;
          if (bfp) {
            const ufp = len === Infinity ? u._fp : (u._fp || '').slice(0, len);
            if (ufp && bfp === ufp) match = true;
          }
          if (entry.ip && u._ip === entry.ip) match = true;
          if (entry.country && u.co === entry.country && u.co !== '--') match = true;
          if (!match) return;
          const ts = io.sockets.sockets.get(u.socketId);
          if (!ts) return;
          leaveRoom(ts, u, 'ban');
          removeRecentLogin(u.id);
          send(ts, 'not', { user: user.id, msg: 'تم حظرك' });
          send(ts, 'close', {});
          setTimeout(() => { try { ts.disconnect(true); } catch (_) {} }, 1200);
        });
      }

      globalBans.push(entry);
      logAction(user, 'ban', target || (entry.ip || entry.country || `بصمة: ${entry.fp}`));
      send(socket, 'cp_bans', buildBanList());
      break;
    }

    // ── رفع حظر  { id? , type? }
    // appraad2.js يرسل type (كما أُرسل وقت الحظر) للمسارين 2 و3، أو id للمسار 1.
    case 'aban': {
      if (!adminOk && !hasPower(user, room, 'ban')) return;
      const key = data.id || data.type || '';
      if (!key) return;
      logAction(user, 'aban', key);
      globalBans.forEach(b => {
        if ((b.id && b.id === key) || (b.type && b.type === key)) b.active = false;
      });
      send(socket, 'cp_bans', buildBanList());
      break;
    }

    // ── قائمة الحظر (عالمية الآن، بصرف النظر عن الغرفة الحالية للمشرف)
    case 'bans': {
      if (!modOk) return;
      send(socket, 'cp_bans', buildBanList());
      break;
    }

    // ── تغيير كلمة مرور عضو  { id, pwd }
    case 'pwd': {
      if (!adminOk) return;
      const target = byUID(data.id);
      if (!target) return;
      // ▲ إضافة: منع تعديل كلمة مرور عضو برتبة أعلى أو مساوية
      if (!canActOnRank(user, target, room)) return;
      logAction(user, 'pwd', target);
      for (const [, acc] of accounts) {
        if (acc.lid === target.lid) {
          acc.pass = bcrypt.hashSync(data.pwd || '', SALT_ROUNDS);
          break;
        }
      }
      break;
    }

    // ── تعديل لايكات  { id, likes }
    case 'likes': {
      // ▲ إصلاح: يوجد صلاحية "setLikes" مُعرَّفة أصلاً في نظام الصلاحيات
      //   لهذا الإجراء تحديداً ولم تكن تُفحَص إطلاقاً (adminOk فقط).
      if (!adminOk && !hasPower(user, room, 'setLikes')) return;
      const target = byUID(data.id);
      if (!target) return;
      logAction(user, 'likes', target, String(parseInt(data.likes) || 0));
      target.rep = parseInt(data.likes) || 0;
      saveAccount(target, { rep: target.rep });
      if (target.roomid) toRoom(target.roomid, 'u^', { id: target.id, rep: target.rep });
      break;
    }

    // ── منح صلاحية  { id, power, days }
    // appraad2.js يُرسل id = user.lid (من لوحة المستخدمين والاشتراكات)
    // أو id = user.id الديناميكي (من قائمة الأعضاء المتصلين في cp_logins)
    // → نحاول byUID أولاً (id الديناميكي) ثم byLID (lid الحساب)
    case 'setpower': {
      if (!adminOk) return;
      let target = byUID(data.id) || byLID(data.id);

      // ▲ إضافة: فرض تسلسل الرتب على تعديل الصلاحيات — لم يكن هناك أي تحقق
      //   من قبل، فكان أي صاحب صلاحية "setpower" يستطيع: (أ) تعديل صلاحية
      //   عضو رتبته أعلى منه أو حتى إزالتها، (ب) ترقية أي عضو لرتبة أعلى من
      //   رتبته هو نفسه (بما فيها رتبة المالك). المالك الحقيقي فقط يتجاوز
      //   هذا القيد بالكامل.
      const actorIsOwner = buildPower(user, room).owner;
      const newRank = rankOfPowerName(data.power || '');
      let currentTargetRank = 0;
      if (target) {
        currentTargetRank = target.rank || 0;
      } else {
        for (const [, acc] of accounts) { if (acc.lid === data.id) { currentTargetRank = acc.rank || 0; break; } }
      }
      if (!actorIsOwner) {
        if (currentTargetRank >= (user.rank || 0)) return;   // الهدف رتبته أعلى/مساوية بالفعل
        if (newRank >= (user.rank || 0)) return;              // الترقية المطلوبة تساوي/تتجاوز رتبة الفاعل
      }

      logAction(user, 'setpower', data.id, data.power || '(بلا صلاحية)');
      if (!target) {
        // مستخدم غير متصل حالياً → تحديث الحساب مباشرة بالـ lid
        for (const [, acc] of accounts) {
          if (acc.lid === data.id) {
            acc.power = data.power || '';
            acc.rank  = newRank;
            // ▲ إضافة: مزامنة أيقونة الحساب المخزَّن فوراً حتى تظهر صحيحة
            //   مباشرة عند دخوله لاحقاً، دون انتظار تعديل يدوي آخر.
            syncIcoOffline(acc);
            break;
          }
        }
        return;
      }

      target.power = data.power || '';
      target.rank  = newRank;

      saveAccount(target, { power: target.power, rank: target.rank });
      // ▲ إضافة: مزامنة أيقونة الرتبة الجديدة فوراً (أو إخفاؤها إن أُزيلت
      //   الرتبة، مع إظهار هدية محفوظة سابقاً تلقائياً إن وُجدت) — يبث
      //   'u^' بنفسه إن تغيّرت فعلاً، فلا داعي لبث toRoom يدوي مكرر بعدها.
      const icoChanged = syncIco(target);
      const ts = io.sockets.sockets.get(target.socketId);
      if (ts) {
        const targetRoom = target.roomid ? rooms.get(target.roomid) : null;
        send(ts, 'power', buildPower(target, targetRoom));
      }
      if (target.roomid && !icoChanged) toRoom(target.roomid, 'u^', target.pub());
      break;
    }

    // ── حذف عضوية  { id }
    // ▲ إصلاح: appraad2.js لا يملك أي "case 'kick'" في مُستقبِل الأوامر
    //   (_0x25b5a7)، فإرسال حدث 'kick' لا معنى له للعميل ولا يظهر أي رسالة؛
    //   والقطع الفوري (بدون أي تأخير) لا يترك وقتاً لوصول الحزمة أصلاً، فيرى
    //   العضو المحذوف فقط "انقطع الاتصال" ثم تُحاول الواجهة إعادة الاتصال
    //   تلقائياً (loop لا نهائي) بدل إعلامه بأن حسابه حُذف نهائياً.
    //   الحل: نفس نمط kick/ban الصحيح أعلاه → send('not') ثم send('close')
    //   قبل قطع الاتصال الفعلي بعد مهلة قصيرة.
    case 'delu': {
      if (!adminOk) return;
      const target = byUID(data.id);
      if (!target) return;
      // ▲ إضافة: منع حذف عضوية عضو برتبة أعلى أو مساوية
      if (!canActOnRank(user, target, room)) return;
      logAction(user, 'delu', target);
      // حذف من الحسابات
      for (const [key, acc] of accounts) {
        if (acc.lid === target.lid) { accounts.delete(key); break; }
      }
      const ts = io.sockets.sockets.get(target.socketId);
      if (ts) {
        if (room) leaveRoom(ts, target, 'deleted');
        removeRecentLogin(target.id);
        send(ts, 'not', { user: user.id, msg: 'تم حذف عضويتك' });
        send(ts, 'close', {});
        setTimeout(() => { try { ts.disconnect(true); } catch (_) {} }, 1200);
      }
      break;
    }

    // ── تاب "السجل"  { q, i }
    // appraad2.js يقرأ: isreg, username, topic, ip, co, fp, refr, r, created
    // المعادلة: new Date(_0x45820f.d - _0x2163d9.created).time()
    // حيث _0x45820f.d هو d في العنصر الأخير → created يجب أن يكون timestamp مطلق
    // العمود الأول (isreg) يُعرَض بالواجهة تحت اسم "الحاله" — appraad2.js
    // يطبعه كنص كما هو مهما كانت قيمته (لا يشترط true/false).
    // ▲ إصلاح (البند الثالث — سجل تسجيل الدخول): تاب "السجل" هو التاب
    //   الصحيح المقصود فعلاً (وليس "الحالات"/case actions — ذاك سجل عمليات
    //   لوحة تحكم عام منفصل تماماً، ولا "الأعضاء"/case logins — ذاك قائمة
    //   حسابات لحظية). "السجل" وحده يحمل هذا الاسم حرفياً في index.html.
    //   كان يعرض فقط الجلسات المتصلة حالياً (fingerprint/بلد/جهاز) — مفيد
    //   ويبقى كما هو دون أي حذف. الآن يُدمَج معه سجل loginLog (الخمس حالات
    //   المطلوبة: عضو جديد/تسجيل دخول/زائر/كلمة سر خاطئة/مستخدم محظور)
    //   كصفوف إضافية بنفس القائمة، مُرتَّبة زمنياً معاً (loginLog يحتفظ بكل
    //   الأحداث دون حذف أي سابق منها — لا علاقة لهذا العرض بذلك، هو قراءة
    //   فقط). لا fp/co/refr/r لصفوف loginLog (غير مُتتبَّعة بـlogLogin) —
    //   تُترَك فارغة، طبيعي لعمود لا يخصها.
    case 'fps': {
      if (!adminOk) return;
      const query  = data?.q || '';
      const offset = parseInt(data?.i) || 0;
      const now    = Date.now();
      const list   = [];
      loginLog.forEach(e => {
        if (query && !e.u.includes(query) && !e.ip.includes(query)) return;
        list.push({
          username: e.u, topic: e.u, ip: e.ip || '',
          co: '', fp: '', refr: '', r: '',
          created: e.created,
          isreg:   e.status   // نص الحالة المختصر (عضو جديد/تسجيل دخول/...)
        });
      });
      users.forEach(u => {
        if (query && !u._fp.includes(query) && !u.topic.includes(query) &&
            !u.lid.includes(query) && !u._ip.includes(query)) return;
        list.push({
          username: u.lid,
          topic:    u.topic,
          ip:       u._ip   || '',
          co:       u.co    || '--',
          fp:       u._fp   || '',
          refr:     u.refr  || '',
          r:        u.roomid || '',
          created:  u.created,         // timestamp مطلق (وليس مدة)
          isreg:    ([...accounts.values()].find(a => a.lid === u.lid)) ? 'متصل الآن' : 'زائر متصل'
        });
      });
      list.sort((a, b) => b.created - a.created);
      const chunk = list.slice(offset, offset + 200);
      chunk.push({ d: now, i: offset });
      send(socket, 'cp_fps', chunk);
      break;
    }

    // ── بحث FPS بالبصمة  { q }
    case 'fp_search':
    case 'fps_do': {
      if (!adminOk) return;
      const fp  = data.q || data.fp || '';
      const res = [];
      users.forEach(u => {
        if (u._fp === fp || u._fp.includes(fp)) {
          res.push({ username: u.lid, topic: u.topic, ip: u._ip, co: u.co, fp: u._fp });
        }
      });
      send(socket, 'cp_fps', res.concat([{ d: Date.now(), i: 0 }]));
      break;
    }

    // ── سجل العمليات { q, i }
    // ▲ إصلاح: كان stub يُرجع قائمة فارغة دائماً — الآن يُرجع actionsLog
    //   الفعلي مع دعم البحث (بالاسم/الإجراء) والترقيم، بنفس نمط 'fps'.
    case 'actions': {
      if (!adminOk) return;
      const query  = data?.q || '';
      const offset = parseInt(data?.i) || 0;
      const list = actionsLog
        .filter(a => !query || a.u1.includes(query) || a.u2.includes(query) || a.type.includes(query) || a.room.includes(query))
        .slice()
        .reverse() // الأحدث أولاً
        // ▲ إصلاح: عمود "الحاله" كان يعرض اسم الأمر البرمجي الخام (مثل
        //   sitesave) بدل وصف عربي مفهوم — الترجمة تحدث هنا فقط عند العرض،
        //   بينما البحث (أعلاه) يبقى يعمل على الاسم الخام الأصلي للدقة.
        .map(a => ({ ...a, type: actionTypeLabel(a.type) }));
      const chunk = list.slice(offset, offset + 200);
      chunk.push({ d: Date.now(), i: offset });
      send(socket, 'cp_actions', chunk);
      break;
    }

    // ── قائمة الدروع / الهدايا / الفيسات
    case 'sico': {
      if (!adminOk || !room) return;
      send(socket, 'cp_sico', room.sicos);
      break;
    }

    // ── ترتيب الفيسات  { d: [] }
    case 'emo_order': {
      if (!adminOk || !room) return;
      if (Array.isArray(data.d)) {
        room.emos = data.d;
        logAction(user, 'emo_order', room.name);
        toRoom(room.id, 'emos', room.emos);
      }
      break;
    }

    // ── حفظ صلاحية  { power: { name, rank, ... } }
    case 'powers_save': {
      if (!adminOk || !room) return;
      const pw = data.power;
      if (!pw || !pw.name) return;
      const idx = globalPowers.findIndex(p => p.name === pw.name);
      logAction(user, 'powers_save', pw.name, `رتبة: ${pw.rank ?? 0}`);
      if (idx !== -1) globalPowers[idx] = pw;
      else globalPowers.push(pw);
      // ▲ إضافة: لو تغيّرت أيقونة هذه الرتبة (أو أي حقل غيرها)، كل عضو متصل
      //   حالياً يحمل هذه الرتبة يجب أن تتحدث أيقونته المعروضة فوراً بلا أي
      //   إعادة اتصال — وإلا تبقى الأيقونة القديمة ظاهرة رغم حفظ الجديدة.
      for (const u of users.values()) {
        if (u.power === pw.name) syncIco(u);
      }
      // 1) أرسل powers لكل أعضاء الغرفة (يُحدِّث _0x5a3802 في appraad2.js)
      broadcastPowers();
      // 2) أرسل cp_rooms محدَّثة لنافذة CP حتى تتحدث قائمة الصلاحيات فورًا
      send(socket, 'cp_rooms', [...rooms.values()].map(r => ({
        id: r.id, name: r.name, topic: r.name,
        user: r.owner || '', pic: r.pic || 'room.png',
        online: r.members.size, uco: r.members.size,
        needpass: r.needpass, about: r.about || '',
        welcome: r.welcome || '', bg: r.bg || '',
        c: r.c || '#000000', max: r.max || 20,
        l: r.l || 0, vl: r.vl || 0,
        owner: r.owner || '', powers: globalPowers || []
      })));
      break;
    }

    // ── حذف صلاحية  { name }
    case 'powers_del': {
      if (!adminOk || !room) return;
      logAction(user, 'powers_del', data.name || '');
      const _filtered = globalPowers.filter(p => p.name !== data.name);
      globalPowers.length = 0;
      globalPowers.push(..._filtered);
      // ▲ إضافة: نفس منطق powers_save — من يحمل الرتبة المحذوفة تُعاد مزامنة
      //   أيقونته فوراً (تختفي أيقونة الرتبة، وتظهر هديته المحفوظة تلقائياً
      //   إن كانت لديه واحدة، بدل بقاء أيقونة رتبة لم تعد موجودة أصلاً).
      for (const u of users.values()) {
        if (u.power === data.name) syncIco(u);
      }
      broadcastPowers();
      send(socket, 'cp_rooms', [...rooms.values()].map(r => ({
        id: r.id, name: r.name, topic: r.name,
        user: r.owner || '', pic: r.pic || 'room.png',
        online: r.members.size, uco: r.members.size,
        needpass: r.needpass, about: r.about || '',
        welcome: r.welcome || '', bg: r.bg || '',
        c: r.c || '#000000', max: r.max || 20,
        l: r.l || 0, vl: r.vl || 0,
        owner: r.owner || '', powers: globalPowers || []
      })));
      break;
    }

    // ── إضافة أيقونة  { pid, tar }
    case 'addico': {
      if (!adminOk || !room) return;
      // ▲ تأكيد من index.html: tar القادمة من زر "أيقونات الهدايا" في
      //   إعدادات الموقع هي 'dro3' حرفياً (نفس مصفوفة room.colors) — أي أن
      //   الهدايا والزخارف يتشاركان نفس مجمع الأيقونات فعلياً في هذا النظام،
      //   وليستا قائمتين منفصلتين. tar الفعلية الثلاث: sico (السوابر),
      //   dro3 (الهدايا/الزخارف), emo (الابتسامات) — مطابقة لما هو مُنفَّذ.
      const tar = data.tar || 'sico';
      // ▲ إصلاح جذري: نقطة الرفع (/upload) تُعيد دوماً "uploads/اسم_الملف"،
      //   وappraad2.js يمرر هذه القيمة كاملة كما وصلته إلى pid دون تنظيف —
      //   فتُخزَّن "uploads/xxx.gif" بدل اسم الملف المجرد، ويصبح رابط العرض
      //   لاحقاً "sico/uploads/xxx.gif" (مسار غير موجود). ننظّفها هنا فوراً
      //   عند الحفظ حتى تبقى المصفوفات نظيفة (اسم ملف مجرد فقط) لكل رفع جديد.
      const pid = String(data.pid || '').replace(/^(uploads\/)+/, '');
      if (tar === 'sico' && !room.sicos.includes(pid)) room.sicos.push(pid);
      else if (tar === 'emo' && !room.emos.includes(pid)) room.emos.push(pid);
      else if (tar === 'dro3' && !room.colors.includes(pid)) room.colors.push(pid);
      saveRoomAssets();
      logAction(user, 'addico', room.name, `${tar}: ${pid}`);
      // ▲ إصلاح: appraad2.js (case "ico+") يعمل _0x3340bc.split('/') ليعرف
      //   الشبكة المستهدفة (.p-sico/.p-dro3/.p-emo) من الجزء الأول قبل '/' —
      //   فيتطلب المسار كاملاً بادئة المجلد ("sico/xxx.png") لا اسم الملف
      //   المجرد فقط. إرسال data.pid وحده يجعل split('/') يُعيد مصفوفة من
      //   عنصر واحد هو اسم الملف نفسه، فيبحث عن كلاس ".p-" + اسم_الملف
      //   بالكامل (غير موجود أبداً) ولا يُضاف العنصر لأي شبكة مرئياً.
      toRoom(room.id, 'ico+', tar + '/' + pid);
      break;
    }

    // ── حذف أيقونة  { pid }
    case 'delico': {
      if (!adminOk || !room) return;
      // ▲ إصلاح: appraad2.js يرسل pid بمسار كامل دائماً ("sico/xxx.png" أو
      //   "dro3/xxx.png" أو "emo/xxx.png" — راجع .attr("pid", tar+"/"+file)
      //   بمولّد الشبكة)، بينما room.sicos/colors/emos تخزّن اسم الملف
      //   المجرد فقط بلا أي بادئة مجلد — فالمقارنة القديمة (x !== pid) لا
      //   تتطابق أبداً ولا يُحذف شيء فعلياً رغم اختفاء العنصر بصرياً من
      //   الشبكة فور استقبال ico- (حذف واجهة فقط، والملف/السجل يبقيان للأبد).
      const pid = (data.pid || '').replace(/^(sico|dro3|emo)\//, '');
      room.sicos  = room.sicos.filter(x => x !== pid);
      room.emos   = room.emos.filter(x => x !== pid);
      room.colors = room.colors.filter(x => x !== pid);
      logAction(user, 'delico', room.name, data.pid || '');
      toRoom(room.id, 'ico-', data.pid || '');
      break;
    }

    // ── طرد من الغرفة فقط  { id }
    case 'roomkick': {
      if ((!adminOk && !hasPower(user, room, 'kick')) || !room) return;
      const target = byUID(data.id);
      if (!target) return;
      // ▲ إضافة: منع طرد عضو برتبة أعلى أو مساوية من الغرفة
      if (!canActOnRank(user, target, room)) return;
      logAction(user, 'roomkick', target);
      // ▲ إضافة: حظر مؤقت خاص بهذه الغرفة فقط لمدة ٢٠ دقيقة — منفصل تماماً
      //   عن الحظر العام (globalBans) ولا يُضاف لقائمة الحظر بلوحة التحكم،
      //   بناءً على طلب صريح. يُخزَّن في room.roomBans (راجع تعريفها بصنف
      //   Room وفحصها في checkJoinable/pickJoinableRoom).
      room.roomBans.set(target.lid, {
        until: Date.now() + 20 * 60 * 1000,
        byLid: user.lid, byName: user.topic, reason: data.reason || ''
      });
      const ts = io.sockets.sockets.get(target.socketId);
      if (ts) {
        leaveRoom(ts, target, 'roomkick');
        send(ts, 'not', { user: user.id, msg: 'تم طردك من الغرفة لمدة 20 دقيقة' });
        // طرد من الغرفة فقط — لا قطع اتصال كلي
      }
      // إرسال القائمة المُحدَّثة لمن يشاهد إعدادات هذه الغرفة حالياً
      toRoom(room.id, 'rbans', buildRoomBans(room));
      pushRoomBans(room); // بث SSE فوري (بنفس اللحظة) لأي مستمع مفتوح
      break;
    }

    // ── إرسال هدية لعضو  { id, gift }
    // appraad.js: gift(id, giftName) → send("action", { cmd:'gift', id, gift })
    // ▲ إصلاح: الصلاحية الصحيحة هي "upgrades" (الهدايا) المُعرّفة في نظام
    //   الصلاحيات (buildPower().upgrades) — وليست adminOk. زر الهدية بالواجهة
    //   يظهر لأي عضو لديه upgrades>=1 وليس للمشرفين فقط (راجع appraad2.js:4173).
    // ▲ إصلاح: appraad2.js لا يملك أي "case 'gift'" في مُستقبِل الأوامر
    //   (_0x25b5a7)، فإرسال حدث 'gift' للعميل المُستهدف لا يُنتج أي أثر مرئي
    //   إطلاقاً (الهدية تختفي بصمت). الحل: تمرير الهدية عبر حدث 'not'
    //   (الإشعار العائم) الذي يملك العميل معالجاً فعلياً له، مع تضمين صورة
    //   الهدية داخل نص الرسالة (msg يُدرَج كـ HTML مباشرة في الواجهة).
    case 'gift': {
      if (!hasPower(user, room, 'upgrades')) return;
      const target = byUID(data.id);
      if (!target) return;
      const giftName = cleanAssetName(sanitize(data.gift || '', 100));
      // ▲ إضافة: لا يجوز إهداء أي عضو يملك أي صلاحية من قائمة الصلاحيات
      //   إطلاقاً (طلب صريح) — الهدية زخرفة بصرية بحتة لا تمنح أي صلاحية،
      //   فلا معنى لمنحها لمن يملك صلاحية أصلاً. يُسمح بإزالة هدية دوماً.
      if (giftName && target.power) {
        send(socket, 'not', { user: 'srv', msg: 'لا يمكن إضافة هدية لمستخدم يمتلك صلاحية.' });
        return;
      }
      logAction(user, 'gift', target, giftName || '(إزالة)');
      // ▲ إضافة: تخزين الهدية بشكل دائم (giftIco) ومزامنة user.ico فوراً عبر
      //   syncIco — تظهر الأيقونة بجانب اسمه في كل مكان بالموقع تلقائياً
      //   (العام/الخاص/الحائط/القوائم) بنفس آلية أيقونة الصلاحيات تماماً
      //   ودون أي تعديل على appraad2.js، بدل الاكتفاء بإشعار عابر يختفي فوراً.
      target.giftIco = giftName;
      syncIco(target);
      const ts = io.sockets.sockets.get(target.socketId);
      if (ts) {
        send(ts, 'not', {
          user: user.id,
          uid:  user.id,
          topic: user.topic,
          pic:   user.pic,
          msg:  giftName
            ? `أهداك <b>${user.topic}</b> هديه: <img src="dro3/${giftName}" style="max-height:32px;vertical-align:middle;">`
            : `قام <b>${user.topic}</b> بإزالة الهديه عنك`
        });
      }
      break;
    }

    // ── إشعار من لوحة التحكم  { id, msg }
    case 'not': {
      // ▲ إصلاح: زر "تنبيه" (.unot) في appraad2.js متاح لكل المستخدمين بلا
      //   أي تحقق صلاحية بالواجهة إطلاقاً (بخلاف .uban/.ukick المُقيَّدة
      //   بوضوح بشرط power.ban/power.kick) — فهو ميزة اجتماعية عامة مثل
      //   "poke" وليس إجراءً إدارياً. الشرط الصحيح المقصود هنا هو notlikes
      //   (الحد الأدنى من الإعجابات)، لا modOk. المشرفون يتجاوزون الشرط.
      const target = byUID(data.id);
      if (!target) return;
      if (!adminOk) {
        const minLikes = parseInt(siteSetting('notlikes', 0)) || 0;
        if (minLikes > 0 && (user.rep || 0) < minLikes) {
          send(socket, 'not', { user: 'srv', msg: `يجب أن تملك ${minLikes} إعجاب على الأقل لإرسال تنبيه` });
          return;
        }
      }
      // ▲ إصلاح إضافي (اكتُشف عبر اختبار فعلي): كان يرسل 'not' خاماً بلا أي
      //   فحص لـtarget.nonot إطلاقاً — بالضبط الحالة "شخص لشخص ثاني" التي
      //   يفترض البند الثاني عشر حجبها. مررناها عبر notifyUser() بدل send()
      //   المباشرة لتحترم nonot + استثناء صلاحية alert تلقائياً، بنفس نمط
      //   إشعارات الرد/الإعجاب الخمسة الأخرى.
      // ▲ إضافة: نفس طلب البند 12 الصريح — إخبار المُرسِل تحديداً عند الحجب.
      if (!notifyUser(user, target, sanitize(data.msg || '', 300))) {
        send(socket, 'not', { user: 'srv', msg: 'هذا المستخدم قام بتعطيل استقبال التنبيهات.' });
      }
      break;
    }

    // ── حفظ إعدادات الموقع العامة  { data }
    // appraad.js: sitesave() → send('cp', { cmd:'sitesave', data })
    case 'sitesave': {
      if (!adminOk) return;
      if (!global.siteSettings) global.siteSettings = {};
      logAction(user, 'sitesave', 'إعدادات الموقع');
      Object.assign(global.siteSettings, data?.data || {});
      // ▲ إصلاح: خيارات (بلايكات الحائط/العام وردودهما، تفعيل المكالمات)
      //   كانت تُحفظ في global.siteSettings فقط، بلا أي انعكاس فعلي على
      //   room.settings — وهي التي يعتمد عليها appraad2.js فعلياً لإظهار/
      //   إخفاء أزرار اللايك والرد تلقائياً (راجع _0x5b0377: يتحقق من
      //   _0x104f82.bclikes/mlikes/mreply/bcreply القادمة ضمن room.settings،
      //   وليس من إعدادات الموقع العامة إطلاقاً). الحل: مزامنة هذه الحقول
      //   المشتركة إلى كل الغرف الحالية فعلياً، مع بث التحديث لكل غرفة.
      const d = data?.data || {};
      const sharedToggleKeys = ['bclikes', 'mlikes', 'mreply', 'bcreply', 'calls', 'mic'];
      const hasSharedToggle = sharedToggleKeys.some(k => k in d);
      if (hasSharedToggle) {
        rooms.forEach(r => {
          sharedToggleKeys.forEach(k => { if (k in d) r.settings[k] = !!d[k]; });
          toRoom(r.id, 'settings', liveSettings(r.settings));
        });
      }
      // ▲ إضافة (البند الثاني — "تطبيق الإعداد على الرسائل الجديدة والحالية"):
      //   بث 'settings' أعلاه يُصحّح الرسائل الجديدة فقط (appraad2.js يقرأ
      //   bclikes/bcreply عند رسم كل رسالة، لا يُعيد فحصها لاحقاً — case
      //   'settings' بـappraad2.js لا يُعيد تطبيقها إلا على .callx تحديداً،
      //   وليس .blike/.breply). الحائط (#d2bc) حاوية حصرية لمنشورات bc فقط
      //   (لا رسائل غرف ولا إعلانات pmsg/ppmsg تشاركها إطلاقاً — تلك تُرسَم
      //   داخل #d2)، فيمكن استهدافها بدقة كاملة بلا أي تأثير جانبي. نستخدم
      //   'ev' (الموجودة فعلاً بappraad2.js: eval(data) — لا Socket جديد)
      //   لحقن/تحديث وسم <style> واحد ثابت المعرّف، فتختفي/تظهر أزرار كل
      //   منشورات الحائط المعروضة حالياً فوراً دون أي تحديث للصفحة.
      //   ملاحظة: لم أُطبّق نفس الأسلوب على mlikes/mreply (رسائل الغرف) لأن
      //   .blike/.breply هناك تشارك نفس الحاوية #d2 مع إعلانات pmsg/ppmsg
      //   (تُحكَم بـbclikes/bcreply لا mlikes/mreply) بلا أي كلاس مميّز على
      //   الزر نفسه يفرّق بينهما بأمان — يحتاج قراراً صريحاً قبل تنفيذه.
      if ('bclikes' in d || 'bcreply' in d) {
        const bclikesOn = global.siteSettings.bclikes !== false;
        const bcreplyOn = global.siteSettings.bcreply !== false;
        let css = '';
        if (!bclikesOn) css += '#d2bc .blike{display:none!important}';
        if (!bcreplyOn) css += '#d2bc .breply{display:none!important}';
        const js = `(function(){var s=document.getElementById('bcToggleCss');if(!s){s=document.createElement('style');s.id='bcToggleCss';document.head.appendChild(s);}s.textContent=${JSON.stringify(css)};})();`;
        toAll('ev', { data: js });
      }
      send(socket, 'ok', null);
      break;
    }

    // ── رسائل الترحيب التلقائية
    case 'msgs': {
      if (!adminOk) return;
      if (!global.siteMessages) global.siteMessages = [];
      send(socket, 'cp_msgs', global.siteMessages);
      break;
    }

    // ── حفظ رسالة جاهزة جديدة (ترحيب/رسائل تلقائية دورية)  { type, t, m }
    // ▲ إصلاح: تحققتُ من index.html — الاسم الصحيح للأمر هو 'msgsit' (كان
    //   مُخمَّناً سابقاً بلا يقين باسم 'msgsave' لعدم توفر index.html وقتها).
    //   القيم الفعلية لـ type: 'w' = رسائل الترحيب، 'd' = الرسائل التلقائية
    //   الدورية (المُرسلة كل مدة زمنية مُحدَّدة عبر msgstt بإعدادات الموقع).
    case 'msgsit': {
      if (!adminOk) return;
      if (!global.siteMessages) global.siteMessages = [];
      const type = data?.type === 'w' ? 'w' : 'd';
      const t    = sanitize(String(data?.t ?? ''), 100);
      const m    = sanitize(String(data?.m ?? ''), 1000);
      if (!m) return;
      global.siteMessages.push({ id: makeBid(), type, t, m });
      logAction(user, 'msgsit', type === 'w' ? 'ترحيب' : 'تلقائية', t);
      send(socket, 'cp_msgs', global.siteMessages);
      break;
    }

    // ── حذف رسالة ترحيب/تلقائية  { id }
    // appraad2.js: send('cp',{cmd:'msgsdel',id:'...'})
    case 'msgsdel': {
      if (!adminOk) return;
      if (!global.siteMessages) global.siteMessages = [];
      logAction(user, 'msgsdel', data?.id || '');
      global.siteMessages = global.siteMessages.filter(m => m.id !== data?.id);
      send(socket, 'cp_msgs', global.siteMessages);
      break;
    }

    // ── قائمة المشتركين / الصلاحيات الممنوحة
    // appraad2.js case 'cp_subs' → يقرأ: id, user, power, topic, days, end, ls
    case 'subs': {
      if (!adminOk) return;
      const now    = Date.now();
      const subList = [];
      accounts.forEach((acc, key) => {
        if (!acc.power && !acc.rank) return;
        subList.push({
          id:    acc.lid,
          user:  acc.name || key,
          power: acc.power || '',
          topic: acc.name  || key,
          days:  0,
          end:   acc.powerEnd || 0,
          ls:    acc.last   || now,
          rank:  acc.rank   || 0
        });
      });
      send(socket, 'cp_subs', subList);
      break;
    }

    // ── قائمة الاختصارات
    // appraad2.js case 'cp_shrt' → يقرأ: name, value
    case 'shrt': {
      if (!adminOk) return;
      if (!global.shortcuts) global.shortcuts = {};
      const shrtList = Object.entries(global.shortcuts).map(([name, value]) => ({ name, value }));
      send(socket, 'cp_shrt', shrtList);
      break;
    }

    // ── حفظ اختصار  { name, value }
    case 'shrtadd': {
      if (!adminOk) return;
      if (!global.shortcuts) global.shortcuts = {};
      const shName = (data?.name || '').trim().slice(0, 50);
      const shVal  = (data?.value || '').slice(0, 500);
      if (!shName) return;
      global.shortcuts[shName] = shVal;
      send(socket, 'cp_shrt', Object.entries(global.shortcuts).map(([n, v]) => ({ name: n, value: v })));
      break;
    }

    // ── قائمة الفلاتر
    // appraad2.js case 'cp_fltr' → يقرأ: a (مصفوفة) و b (مصفوفة الحظر المؤقت)
    case 'fltr': {
      if (!adminOk) return;
      const arr = getFiltersArr();
      if (!global.filtersTemp) global.filtersTemp = [];
      // path يبقى للتوافق مع أي زر حذف قديم بالواجهة يعتمد عليه (path=type/id)
      const fList = buildFilterList();
      send(socket, 'cp_fltr', { a: fList, b: global.filtersTemp });
      break;
    }

    // ── قائمة الغرف (اسم الأمر القديم cp_rooms)
    case 'cp_rooms': {
      if (!adminOk) return;
      send(socket, 'cp_rooms', [...rooms.values()].map(r => ({
        id:       r.id,
        name:     r.name,
        topic:    r.name,
        user:     r.owner    || '',
        pic:      r.pic      || 'room.png',
        online:   r.members.size,
        uco:      r.members.size,
        needpass: r.needpass,
        about:    r.about    || '',
        welcome:  r.welcome  || '',
        bg:       r.bg       || '',
        c:        r.c        || '#000000',
        max:      r.max      || 20,
        l:        r.l        || 0,
        vl:       r.vl       || 0,
        owner:    r.owner    || '',
        powers:   globalPowers   || []    // ← مصفوفة الصلاحيات كاملة
      })));
      break;
    }

    // ── إعدادات البوتات
    // استثناء: يبقى التحقق بالرنك هنا فقط (مطابقةً لـ appraad2.js: rank > 0x2326 && owner)
    case 'bot_save': {
      if (!room || !(user.rank > 0x2326 && buildPower(user, room).owner)) return;
      room.botsConfig = {
        active:   data.bots_active  === true,
        minStay:  parseInt(data.bots_minStay)  || 0,
        maxStay:  parseInt(data.bots_maxStay)  || 0,
        minLeave: parseInt(data.bots_minLeave) || 0,
        maxLeave: parseInt(data.bots_maxLeave) || 0
      };
      logAction(user, 'bot_save', room.name);
      send(socket, 'cp_bots', [...(room.bots || new Map()).values()]);
      break;
    }

    case 'bots': {
      if (!room || !(user.rank > 0x2326 && buildPower(user, room).owner)) return;
      // ▲ إصلاح: كان stub يُرجع مصفوفة فارغة دائماً رغم أن room.bots تحتوي
      //   فعلياً بيانات حقيقية (تُملأ عبر case 'bot' أسفل)، فكانت تبويبة
      //   "البوتات" في لوحة التحكم تظهر فارغة دوماً حتى مع وجود بوتات فعّالة.
      send(socket, 'cp_bots', [...(room.bots || new Map()).values()]);
      break;
    }

    // ── تعديل بوت فردي  { id, or, ucol, bg, topic, msg, online, co, pic, del }
    // appraad.js: editBot() → send('cp', { cmd:'bot', id, ...fields })
    case 'bot': {
      if (!room || !(user.rank > 0x2326 && buildPower(user, room).owner)) return;
      if (!room.bots) room.bots = new Map();
      const { id: botId, del, ...botFields } = data || {};
      if (!botId) return;
      if (del) {
        logAction(user, 'bot-del', botId, room.name);
        room.bots.delete(botId);
        toRoom(room.id, 'u-', botId);
        botStates.delete(botId); // ▲ إضافة: تنظيف حالة المحرّك الآلي (البند الثامن) لهذا البوت المحذوف
      } else {
        // ▲ إصلاح جوهري: appraad2.js (case 'u^') يتجاهل التحديث بالكامل إذا
        //   لم يكن الـ id موجوداً مسبقاً في عناصر الواجهة (_0x3ab28f) — أي
        //   id لم يصله له 'u+' من قبل يبقى بلا أي أثر مرئي إطلاقاً. كان
        //   إنشاء بوت جديد يُرسل 'u^' مباشرة (كأنه "تحديث" لعنصر غير موجود
        //   أصلاً) فلا يظهر البوت أبداً في الواجهة رغم حفظه في room.bots.
        //   الحل: 'u+' (إضافة حقيقية تُنشئ العنصر) عند أول إنشاء للبوت،
        //   و'u^' فقط عند تعديل بوت موجود مسبقاً. كما أُضيفت حقول افتراضية
        //   كاملة مطابقة لشكل pub() الذي يتوقعه العميل حتى لا تفشل دوال
        //   العرض (topic/pic/ico/co/bg/ucol/mcol/rep/power/rank/roomid/s).
        const existing = room.bots.get(botId);
        const isNew = !existing;
        const updated = Object.assign(
          {
            id: botId, lid: botId, username: botId, topic: 'بوت', msg: '',
            pic: 'pic.png', ico: '', co: '--', bg: '', ucol: '', mcol: '',
            rep: 0, power: '', rank: 0, roomid: room.id, b: null, s: null
          },
          existing || {}, botFields, { id: botId, roomid: room.id }
        );
        room.bots.set(botId, updated);
        logAction(user, isNew ? 'bot-new' : 'bot-edit', botId, room.name);
        toRoom(room.id, isNew ? 'u+' : 'u^', updated);
      }
      send(socket, 'cp_bots', [...room.bots.values()]);
      break;
    }

    // ── تغيير نك نيم عضو  { id, nick }
    case 'unick': {
      if (!adminOk) return;
      const target = byUID(data.id);
      if (!target) return;
      target.topic = sanitize(data.nick || '', 60);
      saveAccount(target, { topic: target.topic });
      if (target.roomid) toRoom(target.roomid, 'u^', target.pub());
      break;
    }

    // ▲ ملاحظة: كان هنا أمر منفصل 'loginlog' يبث 'cp_loginlog' — حُذف لأنه
    //   بلا أي معالج فعلي بappraad2.js لحدث 'cp_loginlog' (تحقَّقت بالبحث
    //   الشامل: لا وجود له إطلاقاً)، فكان غير قابل للوصول عملياً من أي واجهة.
    //   سجل تسجيل الدخول (loginLog) أصبح يظهر الآن عبر تاب "السجل" الفعلي
    //   (case 'fps' أعلاه) بعد التأكد أنه الوجهة الصحيحة المقصودة.

    case 'logins': {
      if (!adminOk) return;
      const query  = data?.q || '';
      const offset = parseInt(data?.i) || 0;
      const now    = Date.now();
      const list   = [];
      users.forEach(u => {
        if (query && !u.lid.includes(query) && !u.topic.includes(query) &&
            !u._ip.includes(query) && !u._fp.includes(query)) return;
        // ابحث عن حساب مسجل للحصول على regdate
        let acc = null;
        for (const [, a] of accounts) {
          if (a.lid === u.lid) { acc = a; break; }
        }
        list.push({
          id:       u.id,
          u:        u.lid,                          // username / lid
          t:        u.topic,                        // decoration
          ip:       u._ip    || '',
          fp:       u._fp    || '',
          power:    u.power  || '',
          rep:      u.rep    || 0,
          lastseen: u.last   || now,                // absolute timestamp
          regdate:  acc?.created ? new Date(acc.created).toISOString() : null
        });
      });
      // إضافة الأعضاء المسجلين غير المتصلين حالياً
      for (const [, acc] of accounts) {
        if (list.some(x => x.u === acc.lid)) continue; // متصل بالفعل
        if (query && !acc.lid.includes(query) && !(acc.name||'').includes(query)) continue;
        list.push({
          id:       acc.lid,
          u:        acc.lid,
          t:        acc.name || acc.lid,
          ip:       '',  fp: '',
          power:    acc.power || '',
          rep:      acc.rep   || 0,
          lastseen: acc.last  || 0,
          regdate:  acc.created ? new Date(acc.created).toISOString() : null
        });
      }
      const chunk = list.slice(offset, offset + 100);
      chunk.push({ d: now, i: offset });
      send(socket, 'cp_logins', chunk);
      break;
    }

    // ── بيانات مالك الموقع
    // appraad.js case 'cp_owner' → تعبئة حقول إعدادات الموقع
    case 'owner': {
      if (!buildPower(user, room).owner) return;
      const siteSettings = global.siteSettings || {};
      // ▲ إصلاح جوهري: appraad2.js (case "cp_owner") يقرأ data.sico/data.dro3/
      //   data.emo مباشرة على المستوى الأعلى (لبناء شبكات "أيقونات السوابر/
      //   الهدايا/الإبتسامات" في الإعدادات)، بينما كانت الاستجابة القديمة
      //   ترسل site.sico فقط (متداخلة داخل site، لا يقرأها العميل من هناك
      //   إطلاقاً) من global.sicoList (متغيّر غير موجود بالمشروع أصلاً —
      //   يُقيَّم دوماً []) — فتظهر الشبكات الثلاث فارغة دائماً مهما رُفع من
      //   ملفات. المصدر الصحيح: room.sicos / room.colors (dro3) / room.emos
      //   لنفس الغرفة (نفس ما يكتبه إليه addico بالضبط).
      send(socket, 'cp_owner', {
        site: Object.assign({
          name:        'Chat',
          title:       'دردشة',
          description: '',
          keywords:    '',
          script:      '',
          wall_likes:  0,
          wall_minutes: 0,
          pmlikes:     0,
          msgst:       0,
          notlikes:    0,
          fileslikes:  0,
          proflikes:   0,
          piclikes:    0,
          maxIP:       2,
          maxshrt:     1,
          stay:        1,
          allowg:      true,
          allowreg:    true,
          rc:          false,
          bclikes:     true,
          mlikes:      true,
          bcreply:     false,
          mreply:      false,
          calls:       true,
          callsLike:   0,
          bg:          '39536E',          // jscolor.fromString — بدون #
          background:  'fafafa',
          buttons:     '2B3E52'
        }, siteSettings),
        sico: room ? room.sicos  : [],
        dro3: room ? room.colors : [],
        emo:  room ? room.emos   : []
      });
      break;
    }

    // ── فلاتر الكلمات  { path, v }
    // appraad.js: fltrit(path, value) → send('cp', { cmd:'fltrit', path, v })
    // index.html: أزرار الإضافة الثلاثة ترسل path حرفياً كواحدة من:
    //   'amsgs' = الكلمات المسموحة، 'bmsgs' = الكلمات الممنوعة،
    //   'wmsgs' = الكلمات المراقبة (تحققتُ من index.html مباشرة).
    case 'fltrit': {
      if (!adminOk) return;
      const arr = getFiltersArr();
      const word = sanitize(String(data?.v ?? ''), 100).trim();
      if (!word) return;
      // ▲ إصلاح: القيم الحقيقية القادمة من index.html هي amsgs/bmsgs/wmsgs
      //   (وليست allow/watch/ban كما كان مُخمَّناً سابقاً بدون index.html).
      //   المعرّف الفريد (id) يُولَّد هنا دائماً في السيرفر، بصرف النظر عمّا
      //   يرسله العميل في path — هذا وحده يمنع استبدال الإضافات السابقة.
      const PATH_TYPE_MAP = { amsgs: 'allow', bmsgs: 'ban', wmsgs: 'watch' };
      const rawPrefix = String(data?.path || '').split('/')[0];
      const type = PATH_TYPE_MAP[data?.type] || PATH_TYPE_MAP[rawPrefix] || 'ban';
      arr.push({ id: makeBid(), type, v: word });
      logAction(user, 'fltrit', filterTypeLabel(type), word);
      const fList = buildFilterList();
      send(socket, 'cp_fltr', { a: fList, b: global.filtersTemp || [] });
      send(socket, 'ok', null);
      break;
    }

    // ── حفظ إعدادات مالك الموقع  { data }
    case 'owner_save': {
      if (!buildPower(user, room).owner) return;
      if (!global.siteSettings) global.siteSettings = {};
      logAction(user, 'owner_save', 'إعدادات المالك');
      Object.assign(global.siteSettings, data?.data || data || {});
      send(socket, 'ok', null);
      break;
    }

    // ── إعجاب بمستخدم  { id }
    // appraad.js: send("action", { cmd:'like', id }) ← يصل هنا عبر case 'action'
    case 'like': {
      const target = byUID(data?.id);
      if (!target || target.id === user.id) return;
      // ▲ إضافة: منع تكرار الإعجاب الشخصي (UPRO) خلال دقيقة واحدة لكل زوج
      //   مستخدمين (طلب صريح، برسالة الخطأ الحرفية المطلوبة)، وإرسال إشعار
      //   فوري للطرف الآخر — لم يكن أي منهما موجوداً، فقط زيادة السمعة بلا
      //   أي إشعار أو حد.
      const remain = likeCooldownRemaining(user.id, 'u:' + target.id);
      if (remain > 0) {
        send(socket, 'not', { user: 'srv', msg: 'يمكنك إرسال إعجاب مرة واحدة فقط كل دقيقة.' });
        return;
      }
      markLiked(user.id, 'u:' + target.id);
      target.rep = (target.rep || 0) + 1;
      saveAccount(target, { rep: target.rep });
      if (target.roomid) toRoom(target.roomid, 'u^', { id: target.id, rep: target.rep });
      notifyUser(user, target, `قام <b>${user.topic}</b> بالإعجاب بك`);
      break;
    }

    // ── إبلاغ عن مستخدم  { id }
    // appraad.js: send("action", { cmd:'report', id })
    case 'report': {
      const target = byUID(data?.id);
      // ▲ إصلاح: كان يُسجَّل في console.log فقط (غير مرئي لأي مشرف بلوحة
      //   التحكم) — أصبح يُسجَّل في سجل الإجراءات الفعلي (تبويب "الحالات").
      if (target) logAction(user, 'report', target);
      break;
    }

    // ── حذف صورة مستخدم  { id }
    // appraad.js: send("action", { cmd:'delpic', id })
    case 'delpic': {
      if (!adminOk) return;
      const target = byUID(data?.id);
      if (!target) return;
      // ▲ إضافة: منع حذف صورة عضو برتبة أعلى أو مساوية
      if (!canActOnRank(user, target, room)) return;
      logAction(user, 'delpic', target);
      target.pic = 'pic.png';
      saveAccount(target, { pic: 'pic.png' });
      if (target.roomid) toRoom(target.roomid, 'u^', target.pub());
      break;
    }

    // ── رفع حظر — alias لـ aban
    // appraad.js: send('cp', { cmd:'unban', id })
    case 'unban': {
      // ▲ إصلاح مزدوج: (١) الصلاحية الصحيحة هي "ban" بدل modOk الفضفاضة.
      //   (٢) كان يقارن فقط بـ b.id، فيفشل مع حظورات البصمة (fp) القادمة
      //   بحقل type كما في حالة aban أعلاه — نفس منطق المطابقة الآن.
      if (!adminOk && !hasPower(user, room, 'ban')) return;
      const key = data?.id || data?.type || '';
      if (!key) return;
      logAction(user, 'unban', key);
      // ▲ إصلاح معماري: globalBans العالمية بدل room.bans (لم تعد موجودة).
      globalBans.forEach(b => {
        if ((b.id && b.id === key) || (b.type && b.type === key)) b.active = false;
      });
      send(socket, 'cp_bans', buildBanList());
      break;
    }

    // ── حذف جميع منشورات الحائط لمستخدم معين (بـ uid)
    // مختلف عن msgsdel — هذا يمسح كل منشورات bc لمستخدم واحد من الغرفة
    case 'cleanbc': {
      if (!adminOk || !room) return;
      const targetUid = data?.id || data?.uid;
      if (!targetUid) return;
      logAction(user, 'cleanbc', targetUid);
      // ▲ إصلاح: نفس مشكلة likebc/delbc — الحائط الحقيقي هو globalWall
      //   (room.wall فارغة دوماً)، فكانت هذه الميزة لا تحذف شيئاً إطلاقاً.
      const removed = globalWall.filter(m => m.id === targetUid || m.uid === targetUid).map(m => m.bid);
      for (let i = globalWall.length - 1; i >= 0; i--) {
        const m = globalWall[i];
        if (m.id === targetUid || m.uid === targetUid) globalWall.splice(i, 1);
      }
      removed.forEach(bid => toAll('delbc', { bid }));
      break;
    }

    // ── حذف اختصار  { name }
    // appraad.js: send('cp', { cmd:'shrtdel', name })
    case 'shrtdel': {
      if (!adminOk) return;
      if (!global.shortcuts) global.shortcuts = {};
      logAction(user, 'shrtdel', data?.name || '');
      delete global.shortcuts[data?.name || ''];
      break;
    }

    // ── حذف فلتر  { path, id }
    // appraad.js: send('cp', { cmd:'fltrdel', path, id })
    case 'fltrdel': {
      if (!adminOk) return;
      const arr = getFiltersArr();
      // path بالصيغة الجديدة "type/id" — نأخذ الجزء بعد آخر '/' كمعرّف، مع
      // دعم data.id مباشرة أيضاً لأي زر حذف يرسله بشكل منفصل
      const delId = String(data?.id || String(data?.path || '').split('/').pop() || '');
      if (!delId) return;
      const delEntry = arr.find(f => String(f.id) === delId);
      logAction(user, 'fltrdel', delEntry ? filterTypeLabel(delEntry.type) : delId, delEntry?.v || '');
      global.filters = arr.filter(f => String(f.id) !== delId);
      const fList = buildFilterList();
      send(socket, 'cp_fltr', { a: fList, b: global.filtersTemp || [] });
      break;
    }

    // ── حذف فلتر مؤقت  { id }
    // appraad.js: send('cp', { cmd:'fltrdelx', id })
    case 'fltrdelx': {
      if (!adminOk) return;
      // ▲ إصلاح: كان stub فارغاً تماماً (لا يحذف شيئاً)، والقائمة نفسها لم
      //   تكن تُملأ أصلاً من قبل (راجع checkFilters/logFilteredMessage أعلاه).
      if (!global.filtersTemp) global.filtersTemp = [];
      const delId = String(data?.id ?? '');
      global.filtersTemp = global.filtersTemp.filter(e => String(e.id) !== delId);
      const arr = getFiltersArr();
      send(socket, 'cp_fltr', {
        a: buildFilterList(),
        b: global.filtersTemp
      });
      break;
    }

    // ── قائمة الدومينات
    // appraad.js: cp_owner → يُرسَل عند فتح تبويب الدومينات
    case 'domains': {
      if (!buildPower(user, room).owner) return;
      send(socket, 'cp_domains', global.domains || {});
      break;
    }

    // ── حفظ دومين  { data: { domain, name, ... } }
    // appraad.js: domains_save() → send('cp', { cmd:'domainsave', data })
    case 'domainsave': {
      if (!buildPower(user, room).owner) return;
      if (!global.domains) global.domains = {};
      const d = data?.data || {};
      if (d.domain) {
        // تأكد أن جميع حقول jscolor موجودة حتى لا يطلع خطأ fromString(undefined)
        global.domains[d.domain] = Object.assign({
          domain:      d.domain,
          name:        '',
          title:       '',
          description: '',
          keywords:    '',
          script:      '',
          bg:          '39536E',
          background:  'fafafa',
          buttons:     '2B3E52',
          status:      2
        }, d);
        logAction(user, 'domainsave', d.domain);
        send(socket, 'cp_domains', global.domains);
      }
      break;
    }

    // ── تحديث أيقونة/صورة الموقع (favicon.ico و prv1.png)  { fn }
    // ▲ إضافة: لم يكن هناك أي معالج لهما إطلاقاً. appraad2.js:
    //   onclick="sendfilea(this,function(fn){send('cp',{cmd:'favicon',fn});});"
    //   fn = رابط الملف المرفوع حديثاً (عبر /upload، الآن مُفعَّل أعلاه).
    //   index.html يُشير لهذين الملفين بمسار ثابت مباشر (<link rel="icon"
    //   href="favicon.ico">، <img src="prv1.png">)، فنسخ الملف المرفوع فوق
    //   نفس الاسم الثابت في public/ يجعل التغيير ينعكس فوراً بلا أي تعديل
    //   آخر على index.html.
    case 'favicon':
    case 'prv1':
    // ── تحديث الصورة الافتراضية للعضو (pic.png) والغرفة (room.png)  { fn }
    // ▲ إضافة: نفس حالة favicon/prv1 تماماً — لم يكن لهما أي معالج إطلاقاً.
    //   appraad2.js: onclick="sendfilea(this,function(fn){send('cp',{cmd:'pic'/'room',fn});});"
    case 'pic':
    case 'room': {
      if (!buildPower(user, room).owner) return;
      const fn = data?.fn;
      if (!fn) return;
      const DEST_NAMES = { favicon: 'favicon.ico', prv1: 'prv1.png', pic: 'pic.png', room: 'room.png' };
      try {
        const srcPath  = path.join(__dirname, 'public', String(fn).replace(/^\/+/, ''));
        const destName = DEST_NAMES[cmd];
        fs.copyFileSync(srcPath, path.join(__dirname, 'public', destName));
        logAction(user, cmd, destName);
        // إعلام كل المتصلين لتحديث الصورة في المتصفح فوراً (كسر التخزين المؤقت بـ query string)
        if (cmd === 'favicon') {
          toAll('ev', { data: `try{$("link[rel=icon]").attr("href","favicon.ico?"+Date.now());}catch(e){}` });
        } else if (cmd === 'prv1') {
          toAll('ev', { data: `try{$("img[src^='prv1.png']").attr("src","prv1.png?"+Date.now());}catch(e){}` });
        }
        // ملاحظة: pic.png/room.png تُستخدمان كقيم افتراضية عند إنشاء عضو/غرفة
        // جديدة فقط (لا تُطبَّق بأثر رجعي على أعضاء/غرف موجودة مسبقاً بصور
        // مخصصة already-set)، فلا حاجة لبث تحديث فوري لكل المتصلين هنا.
      } catch (e) {
        console.error(`[${cmd}] فشل النسخ:`, e.message);
      }
      break;
    }

    // ── حذف نطاق  { d }
    // ▲ إضافة: لم يكن هناك أي معالج لزر "إزالة" في تبويب النطاقات إطلاقاً
    // appraad2.js: onclick="send('cp',{cmd:'domaindel',d:$('#domain_list').val()});"
    case 'domaindel': {
      if (!buildPower(user, room).owner) return;
      const d = data?.d;
      if (!d || !global.domains || !global.domains[d]) return;
      delete global.domains[d];
      logAction(user, 'domaindel', d);
      send(socket, 'cp_domains', global.domains);
      break;
    }

    // ── قائمة الغرف للكنترول
    // appraad.js: يُرسَل عند فتح تبويب الغرف في لوحة التحكم
    case 'rooms': {
      if (!adminOk) return;
      send(socket, 'cp_rooms', [...rooms.values()].map(r => ({
        id:       r.id,
        name:     r.name,
        topic:    r.name,
        user:     r.owner   || '',
        pic:      r.pic     || 'room.png',
        online:   r.members.size,
        uco:      r.members.size,
        needpass: r.needpass,
        about:    r.about   || '',
        welcome:  r.welcome || '',
        bg:       r.bg      || '',
        c:        r.c       || '#000000',
        max:      r.max     || 20,
        l:        r.l       || 0,
        vl:       r.vl      || 0,
        owner:    r.owner   || '',
        powers:   globalPowers  || []    // ← مصفوفة الصلاحيات كاملة
      })));
      break;
    }

    default:
      if (process.env.DEBUG) console.log(`[CP] أمر مجهول: "${cmd}"`);
  }
}

// ─── REST API ──────────────────────────────────────────────────────────────────

app.get('/api/status', (_, res) => {
  res.json({
    users: users.size,
    rooms: [...rooms.values()].map(r => ({
      id: r.id, name: r.name, online: r.members.size
    }))
  });
});

// ▲ إضافة (البند الثالث): استرجاع سجل تسجيل الدخول — محمي بـADMIN_KEY لأنه
//   يحمل عناوين IP، بخلاف /api/status العام. يُعاد الأحدث أولاً.
app.get('/api/login-log', (req, res) => {
  if (req.query.key !== ADMIN_KEY) return res.status(403).json({ error: 'غير مسموح' });
  res.json(loginLog.slice().reverse());
});

// ▲ إعادة إضافة: هذه النقطة كانت أُضيفت سابقاً لتغذية قائمة "محظوري الغرفة"،
//   لكنها فُقدت بالخطأ أثناء نسخ الملف الأصلي غير المعدَّل فوق نسخة العمل في
//   خطوة سابقة (نسخ احتياطي غير مقصود). هذا بالضبط سبب "القائمة موجودة لكن
//   لا يظهر فيها أحد" — سكربت الاستطلاع كان يستقبل صفحة خطأ 404 بدل JSON،
//   فيفشل التحليل بصمت (catch فارغ) ولا يُعرض شيء أبداً مهما وُجد من محظورين
//   فعلياً بقاعدة البيانات (room.roomBans).
app.get('/api/roombans', (req, res) => {
  const room = rooms.get(req.query.room);
  if (!room) return res.json([]);
  res.json(buildRoomBans(room));
});

// ▲ إضافة: بث لحظي حقيقي (SSE) لقائمة محظوري الغرفة بدل الاستطلاع الدوري كل
//   4 ثوانٍ — طلب صريح: "أريد أن تظهر بنفس اللحظة". Server-Sent Events خيار
//   قياسي وبسيط جداً (EventSource مدمومة بكل متصفح، تُعيد الاتصال تلقائياً
//   عند الانقطاع دون أي كود إضافي)، ومستقل تماماً عن appraad2.js واتصال
//   socket.io الخاص به — لا حاجة لأي اتصال socket موازٍ هش.
const roomBanSubscribers = new Map(); // roomId -> Set<res>
function pushRoomBans(room) {
  const subs = roomBanSubscribers.get(room.id);
  if (!subs || !subs.size) return;
  const payload = `data: ${JSON.stringify(buildRoomBans(room))}\n\n`;
  for (const res of subs) {
    try { res.write(payload); } catch (e) { subs.delete(res); }
  }
}
app.get('/api/roombans-stream', (req, res) => {
  const room = rooms.get(req.query.room);
  if (!room) return res.status(404).end();
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive'
  });
  if (!roomBanSubscribers.has(room.id)) roomBanSubscribers.set(room.id, new Set());
  const subs = roomBanSubscribers.get(room.id);
  subs.add(res);
  res.write(`data: ${JSON.stringify(buildRoomBans(room))}\n\n`); // إرسال فوري للحالة الحالية عند الاشتراك
  const keepAlive = setInterval(() => { try { res.write(':\n\n'); } catch (e) {} }, 20000); // نبضة كل 20 ثانية تمنع أي وسيط/متصفح من قطع الاتصال بسبب الخمول
  req.on('close', () => { clearInterval(keepAlive); subs.delete(res); });
});

app.post('/api/rooms', (req, res) => {
  const { key, name, pass } = req.body || {};
  if (key !== ADMIN_KEY) return res.status(403).json({ error: 'غير مسموح' });
  if (!name)             return res.status(400).json({ error: 'name مطلوب' });
  const r = new Room('r_' + Date.now(), sanitize(name, 80), pass || '');
  rooms.set(r.id, r);
  toAll('r+', roomListItem(r));
  res.json({ id: r.id, name: r.name });
});

app.delete('/api/rooms/:id', (req, res) => {
  const { key } = req.body || {};
  if (key !== ADMIN_KEY) return res.status(403).json({ error: 'غير مسموح' });
  const r = rooms.get(req.params.id);
  if (!r) return res.status(404).json({ error: 'غير موجودة' });
  r.members.forEach((_, sid) => {
    const s = io.sockets.sockets.get(sid);
    if (s) send(s, 'kick', { reason: 'room_deleted' });
  });
  rooms.delete(req.params.id);
  toAll('r-', { id: req.params.id });
  res.json({ deleted: true });
});

app.post('/api/broadcast', (req, res) => {
  const { key, msg, roomId } = req.body || {};
  if (key !== ADMIN_KEY) return res.status(403).json({ error: 'غير مسموح' });
  const payload = {
    uid: 'srv', pic: 'room.png', ico: '', ucol: '',
    topic: 'النظام', t: Date.now(),
    msg: sanitize(msg || ''), bid: makeBid()
  };
  if (roomId) toRoom(roomId, 'bc', payload);
  else rooms.forEach(r => toRoom(r.id, 'bc', payload));
  res.json({ ok: true });
});

app.post('/api/register', (req, res) => {
  const { key, username, password, rank = 0 } = req.body || {};
  if (key !== ADMIN_KEY) return res.status(403).json({ error: 'غير مسموح' });
  if (!username || !password) return res.status(400).json({ error: 'username & password مطلوبان' });
  const nameKey = username.toLowerCase();
  if (accounts.has(nameKey)) return res.status(409).json({ error: 'الاسم مستخدم' });
  const lid = genId();
  accounts.set(nameKey, {
    lid, name: sanitize(username, 60),
    pass: bcrypt.hashSync(password, SALT_ROUNDS),
    pic: 'pic.png', ico: '', rep: 0, power: '',
    rank: parseInt(rank) || 0, co: '--', bg: '', ucol: '', mcol: '', msg: '',
    created: Date.now(), last: Date.now()
  });
  res.json({ ok: true, lid });
});

// ▲ ملاحظة: فكرة بث rlist دورياً كشبكة أمان لتصحيح أي انحراف تراكمي في
//   عدّاد الحضور تم التراجع عنها عمداً بعد التحقق من appraad2.js: case
//   "rlist" يستخدم $("#rooms").append(...) دون تفريغ الحاوية أولاً، فإعادة
//   إرسالها بشكل متكرر تُراكم عناصر غرف مكررة في واجهة قائمة الغرف — عطل
//   جديد أوضح وأسوأ من مشكلة العدّاد الأصلية. الاعتماد فقط على الإصلاحات
//   الدقيقة والمحدَّدة (ترتيب ur/u+ الصحيح في joinRoom وrc2 أعلاه) بدل أي
//   "إصلاح شامل" عام قد يكسر جزءاً آخر من الواجهة لم يُتحقق منه بدقة.

// ▲ إضافة: الرسائل التلقائية الدورية (type:'d' في global.siteMessages) كانت
//   قابلة للإضافة من لوحة التحكم (بعد إصلاح 'msgsit' أعلاه) وحقل المدة
//   بالدقائق (msgst، من عنصر .msgstt في index.html) قابلاً للحفظ ضمن
//   إعدادات الموقع، لكن لا شيء كان يبثّها فعلياً على فترات — الميزة كانت
//   غير مُفعَّلة بالكامل من طرف السيرفر. نتحقق كل دقيقة هل حان وقت إرسال
//   رسالة تلقائية جديدة (بالتناوب بين الرسائل المُضافة)، ونبثّها بنفس صيغة
//   إعلان pmsg (toAll) التي يعرضها العميل بالفعل.
let _lastAutoMsgAt = Date.now();
let _autoMsgIndex  = 0;
setInterval(() => {
  const intervalMin = parseInt(siteSetting('msgst', 0)) || 0;
  if (intervalMin <= 0) return; // معطّلة (0 أو غير مضبوطة)
  if (Date.now() - _lastAutoMsgAt < intervalMin * 60000) return;
  const list = (global.siteMessages || []).filter(m => m.type === 'd');
  if (list.length === 0) return;
  _lastAutoMsgAt = Date.now();
  const msg = list[_autoMsgIndex % list.length];
  _autoMsgIndex++;
  toAll('pmsg', {
    uid: 'srv', topic: msg.t || 'رسالة تلقائية', pic: 'room.png',
    msg: msg.m, t: Date.now(), bid: makeBid()
  });
}, 60000);

// ▲ إضافة (البند الثامن — الجزء الوحيد الناقص فعلياً، الإدارة اليدوية للبوتات
//   أعلاه [case 'bot'/'bots'/'bot_save'] كانت مُصلَحة سلفاً): محرّك التشغيل
//   الآلي المُوقَّت. room.bots/room.botsConfig يُحفَظان فقط بلا أي شيء يقرأهما
//   دورياً — بحث كامل عن أي setInterval متعلق بالبوتات = صفر نتائج. بوتات
//   room.bots هي تعريفات ثابتة (شكل/اسم/صورة) لا حالة "ظاهر الآن أم لا"،
//   فهذا المحرّك يحتفظ بحالة الظهور والموعد التالي لكل بوت منفصلة تماماً
//   (botStates) حتى لا تتداخل مع شكل استجابة cp_bots الحالي العامل فعلياً.
//   القاعدة عند عدم ضبط min/max لاتجاه معيّن (لا تزالان 0 الافتراضية): لا
//   نخترع رقماً افتراضياً — البوت يبقى بحالته الحالية دون تبديل لذلك الاتجاه
//   حتى يضبط المشرف قيماً حقيقية عبر bot_save.
const botStates = new Map(); // botId -> { visible, nextAt }
function randMinutesMs(min, max) {
  if (!(max > 0)) return null; // غير مُهيّأ فعلياً — لا نجدول انتقالاً
  const lo = Math.min(min, max), hi = Math.max(min, max);
  return (lo + Math.random() * (hi - lo)) * 60000;
}
setInterval(() => {
  const now = Date.now();
  rooms.forEach(room => {
    if (!room.botsConfig?.active || !room.bots?.size) return;
    room.bots.forEach((bot, botId) => {
      let st = botStates.get(botId);
      if (!st) {
        // أول ظهور لهذا البوت للمحرّك: يبدأ خارج الغرفة (لا نُظهره فجأة قبل
        // أي جدولة)، وموعد دخوله الأول يُحسب فوراً أدناه بنفس منطق الخروج.
        st = { visible: false, nextAt: now };
        botStates.set(botId, st);
      }
      if (st.nextAt === null || now < st.nextAt) return;
      if (st.visible) {
        toRoom(room.id, 'u-', botId);
        st.visible = false;
        st.nextAt  = randMinutesMs(room.botsConfig.minLeave, room.botsConfig.maxLeave);
        if (st.nextAt !== null) st.nextAt += now;
      } else {
        toRoom(room.id, 'u+', bot);
        st.visible = true;
        st.nextAt  = randMinutesMs(room.botsConfig.minStay, room.botsConfig.maxStay);
        if (st.nextAt !== null) st.nextAt += now;
      }
    });
  });
}, 15000);

// ▲ إضافة: فحص دوري لحالة الخمول (.ustat) — يحوّل أي متصل تجاوز خموله
//   IDLE_MS إلى stat=1 عبر u^. العودة الفورية لـstat=0 عند أي نشاط جديد
//   مضمونة بالفعل بأعلى dispatch() (لا تنتظر هذا الفحص). نتخطّى من هم
//   بمهلة انتظار قطع اتصال (_discGrace=true) — حالتهم (stat=3) لا علاقة
//   لها بخمول الكتابة، وتُدار بمؤقّتها الخاص بالكامل.
setInterval(() => {
  users.forEach(u => { if (!u._discGrace) refreshUserStat(u); });
}, 15000);

// ─── تشغيل السيرفر ────────────────────────────────────────────────────────────
seedRooms();
seedAdmin();

server.listen(PORT, HOST, () => {
  const protocol = HTTPS_OPTIONS ? 'https' : 'http';
  console.log(`\n✅  السيرفر يعمل على المنفذ ${PORT}`);
  console.log(`    ${protocol}://localhost:${PORT}\n`);
  if (HOST !== '0.0.0.0') console.log(`    ${protocol}://${HOST}:${PORT}`);
  console.log('  ═══ جدول الأحداث المتوافق مع appraad2.js ═══');
  console.log('  Client → Server │ Server → Client');
  console.log('  ─────────────────┼──────────────────');
  console.log('  online           │ server, rlist, emos, dro3, sico, powers, settings');
  console.log('  g / login / reg  │ ok, login{msg,id,k,ttoken,r}');
  console.log('  rjoin            │ rc, ulist, rlist, emos, dro3, sico, powers,');
  console.log('                   │ settings, power, mic, bclist, rops, rcd, online+, r^');
  console.log('  msg              │ msg → toRoom');
  console.log('  bc               │ bc → toRoom');
  console.log('  pm               │ pm → target');
  console.log('  mic (slot/-1)    │ r^ (m,ops) → toRoom');
  console.log('  uml              │ r^ + p2{t:x} → target');
  console.log('  p2               │ p2 → target');
  console.log('  call             │ call → target');
  console.log('  ty               │ ty → target');
  console.log('  setprofile       │ u^ → toRoom');
  console.log('  cp{cmd}          │ cp_* → socket\n');
});
